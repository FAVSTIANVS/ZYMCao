﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HW5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("by typing '1' a random number is generated from normal distribution using an inefficient way");
            Console.WriteLine("by typing '2' using Box-Muller method");
            Console.WriteLine("by typing '3' using Polar Rejection method");
            Console.WriteLine("by typing '4' stop");
            int a = Convert.ToInt16(Console.ReadLine());
            while (a!=4)
            {
                if (a == 1)
                {
                    Console.WriteLine(uniform1());
                    a = Convert.ToInt16(Console.ReadLine());
                }
                else if (a == 2)
                {
                    Console.WriteLine(uniformBoxMuller());
                    a = Convert.ToInt16(Console.ReadLine());
                }
                else if (a == 3)
                {
                    Console.WriteLine(uniformPolarReject());
                    a = Convert.ToInt16(Console.ReadLine());
                }
            }
        }
        static double uniform1() 
        {
            double x = 0;
            for(int a=0; a<11; a++)
            {
                double randn;
                Random rnd = new Random();
                randn = rnd.NextDouble();
                x = x + randn;
            }
            x = x - 6;
            return x;
        }
        static double uniformBoxMuller()
        {
            double x1;
            double x2;
            Random rnd = new Random();
            x1 = rnd.NextDouble();
            x2 = rnd.NextDouble();
            double z1 = Math.Sqrt(-2 * Math.Log(x1)) * Math.Cos(2 * Math.PI * x2);
            double z2 = Math.Sqrt(-2 * Math.Log(x1)) * Math.Sin(2 * Math.PI * x2);
            return z1;
        }
        static double uniformPolarReject()
        {
            double x1;
            double x2;
            double w;
            do
            {
                Random rnd = new Random();
                x1 = rnd.NextDouble();
                x2 = rnd.NextDouble();
                w = x1 * x1 + x2 * x2;
            }
            while (w > 1);
            double c = Math.Sqrt(-2 * Math.Log(w) / w);
            double z1 = c * x1;
            double z2 = c * x2;
            return z1;
        }
    }
}


