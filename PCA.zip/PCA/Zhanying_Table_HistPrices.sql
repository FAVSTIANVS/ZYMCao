USE [MFM_Financial]
GO

/****** Object:  Table [FinData].[HistPrices]    Script Date: 11/4/2019 3:17:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FinData].[HistPrices](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[InstID] [int] NOT NULL,
	[Date] [date] NULL,
	[ClosePrice] [float] NULL,
 CONSTRAINT [PK_HistPrices] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [FinData].[HistPrices]  WITH CHECK ADD  CONSTRAINT [FK_Instrument_HistPrices] FOREIGN KEY([InstID])
REFERENCES [FinData].[Instrument] ([ID])
GO

ALTER TABLE [FinData].[HistPrices] CHECK CONSTRAINT [FK_Instrument_HistPrices]
GO


