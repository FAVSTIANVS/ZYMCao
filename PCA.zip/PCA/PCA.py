import pandas as pd
import numpy as np
import pyodbc

def get_px(ticker):
    # get all closeprices of a particular financial instrument based on input ticket; output is a list
    conn = pyodbc.connect('Driver={SQL Server};' 'Server=ZHANYINGCAO2384\FM5091;''Database=MFM_Financial;''Trusted_Connection=yes;')
    cursor = conn.cursor()
    cursor.execute("select ClosePrice from [MFM_Financial].[FinData].[HistPrices] as a join [MFM_Financial].[FinData].[Instrument] as b on b.ID = a.InstID where b.StockTicker='" + ticker + "'")
    f = cursor.fetchall()
    for i in range(len(f)):
        f[i] = f[i][0]
    return f

tickers = ['GOOG','MSFT','AAPL','AMZN','FB','GE','CAT','HON','MMM','UTX','KO','PG','PEP','CL','REV','VLO','XOM','BP','TOT','RDS/A']
sectors = ['Technology', 'Industrial Goods', 'Consumer Goods', 'Basic Materials']
data1 = [] # this will be four stocks from Basic Materials sector, 'VLO','XOM','BP','TOT'
data2 = [] # this will be stocks from different sectors

for i in (15, 16, 17, 18):
    x = tickers[i]
    data1.append(get_px(x))

for i in (0, 5, 10, 15):
    x = tickers[i]
    data2.append(get_px(x))

def p2r(data):
    # this function transforms the price data to the rate of return data
    returns = []
    for i in range(len(data)):
        returns.append([])
        for j in range(len(data[i]) - 1):
            y = (data[i][j+1] - data[i][j]) / data[i][j]
            returns[i].append(y)
    return returns
    
returns1 = p2r(data1)
returns2 = p2r(data2)

cov1 = np.cov(returns1, rowvar=False) # covariance matrix
eigenvalues1  = np.linalg.eigh(cov1)[0]
eigenvectors1 = np.linalg.eigh(cov1)[1]
inverse_eigenvectors1 = np.linalg.inv(eigenvectors1)

cov2 = np.cov(returns2, rowvar=False) # covariance matrix
eigenvalues2  = np.linalg.eigh(cov2)[0]
eigenvectors2 = np.linalg.eigh(cov2)[1]
inverse_eigenvectors2 = np.linalg.inv(eigenvectors2)

# dimensional reduction, drop an eigenvector 
# eigenvectors1_reduce = np.rot90(eigenvectors1)
# eigenvectors1_reduce = eigenvectors1_reduce[:,0:1409]
# returns1_reduce = np.array(returns1)
# for i in range(len(returns1_reduce)):   
#     returns1_reduce[i] = returns1_reduce[i] - np.mean(returns1_reduce[i])
# approx1_reduce = np.dot(returns1_reduce, eigenvectors1_reduce)


# dimensional reduction, drop an eigenvector 
# eigenvectors2_reduce = np.rot90(eigenvectors2)
# eigenvectors2_reduce = eigenvectors2_reduce[:,0:1409]
# returns2_reduce = np.array(returns2)
# for i in range(len(returns2_reduce)):   
#     returns2_reduce[i] = returns2_reduce[i] - np.mean(returns2_reduce[i])
# approx2_reduce = np.dot(returns2_reduce, eigenvectors2_reduce)

print("for the first data set, the tickers are:")
for i in (15, 16, 17, 18):
    x = tickers[i]
    print(x)

print("for the second data set, the tickers are:")
for i in (0, 5, 10, 15):
    x = tickers[i]
    print(x)

print("the eigenvalues for the first data set are", eigenvalues1)
print("the eigenvalues for the second data set are", eigenvalues2)
print("the proportion of variation accounted for by the largest eigenvalue in the first data set:", np.max(eigenvalues1)/np.sum(eigenvalues1))
print("the proportion of variation accounted for by the largest eigenvalue in the second data set:", np.max(eigenvalues2)/np.sum(eigenvalues2))