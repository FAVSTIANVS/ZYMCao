import pandas as pd
from pandas import ExcelWriter
from pandas import ExcelFile
import numpy as np
import pyodbc

def add_instr(ticker, sector):
    # this function populates the instrument table
    conn = pyodbc.connect('Driver={SQL Server};' 'Server=ZHANYINGCAO2384\FM5091;''Database=MFM_Financial;''Trusted_Connection=yes;')
    cursor = conn.cursor()
    cursor.execute("insert into [MFM_Financial].[FinData].[Instrument] values ('','','" + ticker + "','" + sector + "')")
    conn.commit()

tickers = ['GOOG','MSFT','AAPL','AMZN','FB','GE','CAT','HON','MMM','UTX','KO','PG','PEP','CL','REV','VLO','XOM','BP','TOT','RDS/A']
sectors = ['Technology', 'Industrial Goods', 'Consumer Goods', 'Basic Materials']

def get_name_id(ticker):
    conn = pyodbc.connect('Driver={SQL Server};' 'Server=ZHANYINGCAO2384\FM5091;''Database=MFM_Financial;''Trusted_Connection=yes;')
    cursor = conn.cursor()
    cursor.execute("select ID from [MFM_Financial].[FinData].[Instrument] where StockTicker='" + ticker + "'")
    return cursor.fetchone()[0]

def add_timeseries_from_excel(ticker, filepath, st): 
    # this function populates the histprices table
    tickerid = get_name_id(ticker)
    conn = pyodbc.connect('Driver={SQL Server};' 'Server=ZHANYINGCAO2384\FM5091;''Database=MFM_Financial;''Trusted_Connection=yes;')
    cursor = conn.cursor()
    df = pd.read_excel(filepath, sheet_name=st)
    for i in range(len(df)):
        cursor.execute("insert into [MFM_Financial].[FinData].[HistPrices] values ('" + str(tickerid) + "',CONVERT(DATETIME,'" + str(df.iloc[i]['Date']) + "', 102),'" + str(df.iloc[i][ticker]) + "')")
    conn.commit()

def get_px(ticker):
    conn = pyodbc.connect('Driver={SQL Server};' 'Server=ZHANYINGCAO2384\FM5091;''Database=MFM_Financial;''Trusted_Connection=yes;')
    cursor = conn.cursor()
    cursor.execute("select ClosePrice from [MFM_Financial].[FinData].[HistPrices] as a join [MFM_Financial].[FinData].[Instrument] as b on b.ID = a.InstID where b.StockTicker='" + ticker + "'")
    return cursor.fetchone()

# this loop populates the Instrument table
for i in range(4):
    for j in range(5):
        k = j + i*5
        a = tickers[k]
        b = sectors[i]
        add_instr(a , b)

# this loop populates the HistPrices table
for i in range(20):
    z = tickers[i]
    add_timeseries_from_excel(z, 'data.xlsx', 'HistPrices')
