﻿using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace HW3
{
    public partial class Form1 : Form
    {
        Stopwatch watch1 = new Stopwatch();
        Stopwatch watch2 = new Stopwatch();
        public Form1()
        {
            InitializeComponent();
            errorProvider1.SetIconAlignment(SI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(SI, 3);
            errorProvider1.SetIconAlignment(KI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(KI, 3);
            errorProvider1.SetIconAlignment(VolI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(VolI, 3);
            errorProvider1.SetIconAlignment(TI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(TI, 3);
            errorProvider1.SetIconAlignment(TrialsI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(TrialsI, 3);
            errorProvider1.SetIconAlignment(StepsI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(StepsI, 3);
        }
        private void Form1_Load(object sender, EventArgs e){}
        private void SI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(SI.Text, out _) || Convert.ToDouble(SI.Text) < 0)
                errorProvider1.SetError(SI, "Please enter a positive number!");
            else
                errorProvider1.SetError(SI, string.Empty);
        }

        private void KI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(KI.Text, out _) || Convert.ToDouble(KI.Text) < 0)
                errorProvider1.SetError(KI, "Please enter a positive number!");
            else
                errorProvider1.SetError(KI, string.Empty);
        }

        private void RI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(RI.Text, out _) || Convert.ToDouble(RI.Text) < 0)
                errorProvider1.SetError(RI, "Please enter a positive number!");
            else
                errorProvider1.SetError(RI, string.Empty);
        }

        private void TI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(TI.Text, out _) || Convert.ToDouble(TI.Text) < 0)
                errorProvider1.SetError(TI, "Please enter a positive number!");
            else
                errorProvider1.SetError(TI, string.Empty);
        }

        private void VolI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(VolI.Text, out _) || Convert.ToDouble(VolI.Text) < 0)
                errorProvider1.SetError(VolI, "Please enter a positive number!");
            else
                errorProvider1.SetError(VolI, string.Empty);
        }

        private void TrialsI_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(TrialsI.Text, out _) || Convert.ToInt32(TrialsI.Text) < 0)
                errorProvider1.SetError(TrialsI, "Please enter a positive integer!");
            else
                errorProvider1.SetError(TrialsI, string.Empty);
        }

        private void StepsI_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(StepsI.Text, out _) || Convert.ToInt32(StepsI.Text) < 0)
                errorProvider1.SetError(StepsI, "Please enter a positive integer!");
            else
                errorProvider1.SetError(StepsI, string.Empty);
        }

        private void Outcome_Click(object sender, EventArgs e)
        {
            watch1.Reset();
            watch2.Reset();
            Equity U = new Equity(Convert.ToDouble(SI.Text), Convert.ToDouble(VolI.Text));
            // constructing an instance of equity U, "U" stands for underlying; 
            // SI.Text gives its price; 
            // VolI.Text gives its volatility.

            EuropeanOption O = new EuropeanOption(U, Convert.ToDouble(KI.Text), Convert.ToDouble(TI.Text), Call.Checked);
            // constructing an instance of European option; 
            // KI.Text gives K, strike;
            // TI.Text gives T, tenor;
            // Call.Checked gives whether or not it is a call.

            //sTimerO.Text = "00:00:00";
            //cTimerO.Text = "00:00:00";
            watch1.Start();
            Double[,] D = Helping.DefaultMatrixBoxMuller(Convert.ToInt32(TrialsI.Text), Convert.ToInt32(StepsI.Text), Antithetic.Checked);
            // gives a matrix of random numbers, whose #rows = #steps and #columns = #trials.

            watch1.Stop();
            sTimerO.Text = watch1.Elapsed.Minutes.ToString() + ":" + watch1.Elapsed.Seconds.ToString() + ":" + watch1.Elapsed.Milliseconds.ToString();

            watch2.Start();
            PO.Text = O.MCPrice(Convert.ToDouble(RI.Text), D, CVDelta.Checked, CVGamma.Checked).ToString(); // price
            DO.Text = O.MCDelta(Convert.ToDouble(RI.Text), D, CVDelta.Checked, CVGamma.Checked).ToString(); // delta
            GO.Text = O.MCGamma(Convert.ToDouble(RI.Text), D, CVDelta.Checked, CVGamma.Checked).ToString(); // gamma
            VO.Text = O.MCVega(Convert.ToDouble(RI.Text), D, CVDelta.Checked, CVGamma.Checked).ToString(); // vega
            ThO.Text = O.MCTheta(Convert.ToDouble(RI.Text), D, CVDelta.Checked, CVGamma.Checked).ToString(); // theta
            RhO.Text = O.MCRho(Convert.ToDouble(RI.Text), D, CVDelta.Checked, CVGamma.Checked).ToString(); // rho
            SEO.Text = O.MCStdError(Convert.ToDouble(RI.Text), D, CVDelta.Checked, CVGamma.Checked).ToString(); // std error
            watch2.Stop();
            cTimerO.Text = watch2.Elapsed.Minutes.ToString() + ":" + watch2.Elapsed.Seconds.ToString() + ":" + watch2.Elapsed.Milliseconds.ToString();
        }
    }
    abstract class Instrument
    {
        protected double price;
        protected double volatility;
        //protected string name;
        //protected string marketTraded;
        //protected string jurisdiction;
        //protected string currency;
        //protected DateTime issuance;
        //protected DateTime expiration;
        public double Price { get { return price; } set { price = value; } }
        public double Volatility { get { return volatility; } set { volatility = value; } }
        //public string Name { get { return name; } set { name = value; } }
        //public string MarketTraded { get { return marketTraded; } set { marketTraded = value; } }
        //public string Jurisdiction { get { return jurisdiction; } set { jurisdiction = value; } }
        //public string Currency { get { return currency; } set { currency = value; } }
        //public DateTime Issuance { get { return issuance; } set { issuance = value; } }
        //public DateTime Expiration { get { return expiration; } set { expiration = value; } }
        protected static double dx = 0.0001; // used as infinitesimal in order to calculate partial derivatives
    }
    class Equity : Instrument
    {
        public Equity(double p, double vol)
        {
            price = p;
            volatility = vol;
        }
    }
    abstract class Option : Instrument
    {
        protected bool isCall;
        protected double tenor;
        protected double strike;
        protected Instrument underlying;
        protected double uPrice;
        protected double uVol;
        public bool IsCall { get { return isCall; } set { isCall = value; } }
        public double Tenor { get { return tenor; } set { tenor = value; } }
        public double Strike { get { return strike; } set { strike = value; } }
        public Instrument Underlying { get { return underlying; } set { underlying = value; } }
        public Option(Instrument U, double K, double T, bool Call)
        {
            underlying = U;
            strike = K;
            tenor = T;
            isCall = Call;
            uPrice = U.Price;
            uVol = U.Volatility;
        }
        protected virtual double[] Intrinsic(double R, double[,] Data, double s, double vol, double k, double t, bool c, bool dcv, bool gcv) { return new double[] { 0 }; }
        // return the array of intrinsic values of the option at the last step; the length of the array is the number of trials.
        // "c" stands for if this option is a call; 
        // "dcv" stands for if employing delta-based control variate method;
        // "gcv" stands for if employing gamma-based control variate method.
        public virtual double MCPrice(double R, double[,] Data, bool dCV, bool gCV) { return 0; }
        public virtual double MCDelta(double R, double[,] Data, bool dCV, bool gCV) { return 0; }
        public virtual double MCGamma(double R, double[,] Data, bool dCV, bool gCV) { return 0; }
        public virtual double MCVega(double R, double[,] Data, bool dCV, bool gCV) { return 0; }
        public virtual double MCTheta(double R, double[,] Data, bool dCV, bool gCV) { return 0; }
        public virtual double MCRho(double R, double[,] Data, bool dCV, bool gCV) { return 0; }
        public virtual double MCStdError(double R, double[,] Data, bool dCV, bool gCV) { return 0; }
    }
    class EuropeanOption : Option
    {
        public EuropeanOption(Instrument U, double K, double T, bool Call) : base(U, K, T, Call) { }
        protected override double[] Intrinsic(double R, double[,] Data, double s, double vol, double k, double t, bool c, bool dCV, bool gCV)
        {
            int simTrials = Data.GetLength(0); 
            double[] sim = Brownian.GBMZ(R, vol, s, t, Data);
            double[] Output = new double[simTrials];
            if (dCV) // whether or not delta-based control variate if employed
            {
                double[] cv1 = Brownian.DCV(R, vol, s, k, t, Data, c);
                if (gCV) // whether or not gamma-based control variate if employed
                {
                    double[] cv2 = Brownian.GCV(R, vol, s, k, t, Data);
                    if (c) // whether or not this option is a call
                        for (int i = 0; i < simTrials; i++)
                        {
                            Output[i] = Math.Max(sim[i] - k, 0) - cv1[i] - cv2[i] / 2;
                        }
                    else
                        for (int i = 0; i < simTrials; i++)
                        {
                            Output[i] = Math.Max(k - sim[i], 0) - cv1[i] - cv2[i] / 2;
                        }
                }
                else
                {
                    if (c) // whether or not this option is a call
                        for (int i = 0; i < simTrials; i++)
                        {
                            Output[i] = Math.Max(sim[i] - k, 0) - cv1[i];
                        }
                    else
                        for (int i = 0; i < simTrials; i++)
                        {
                            Output[i] = Math.Max(k - sim[i], 0) - cv1[i];
                        }
                }
            }
            else
            {
                if (gCV)
                {
                    double[] cv2 = Brownian.GCV(R, vol, s, k, t, Data);
                    if (c)
                        for (int i = 0; i < simTrials; i++)
                        {
                            Output[i] = Math.Max(sim[i] - k, 0) - cv2[i] / 2;
                        }
                    else
                        for (int i = 0; i < simTrials; i++)
                        {
                            Output[i] = Math.Max(k - sim[i], 0) - cv2[i] / 2;
                        }
                }
                else
                {
                    if (c)
                        for (int i = 0; i < simTrials; i++)
                        {
                            Output[i] = Math.Max(sim[i] - k, 0);
                        }
                    else
                        for (int i = 0; i < simTrials; i++)
                        {
                            Output[i] = Math.Max(k - sim[i], 0);
                        }
                }
            }
            return Output;
        }
        public override double MCPrice(double R, double[,] Data, bool dCV, bool gCV) // price; "MC" stands for Monte Carlo simulation
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, strike, tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            return y0;
        }
        public override double MCDelta(double R, double[,] Data, bool dCV, bool gCV)
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, strike, tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            double y1 = Intrinsic(R, Data, (1 + dx) * uPrice, uVol, strike, tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            return (y1 - y0) / dx;
        }
        public override double MCGamma(double R, double[,] Data, bool dCV, bool gCV)
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, strike, tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            double y1 = Intrinsic(R, Data, (1 + dx) * uPrice, uVol, strike, tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            double y2 = Intrinsic(R, Data, (1 - dx) * uPrice, uVol, strike, tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            return (y1 + y2 - 2 * y0) / (dx * dx);
        }
        public override double MCVega(double R, double[,] Data, bool dCV, bool gCV)
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, strike, tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            double y1 = Intrinsic(R, Data, uPrice, (1 + dx) * uVol, strike, tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            return (y1 - y0) / dx;
        }
        public override double MCTheta(double R, double[,] Data, bool dCV, bool gCV)
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, strike, tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            double y1 = Intrinsic(R, Data, uPrice, uVol, strike, (1 + dx) * tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            return (y1 - y0) / dx;
        }
        public override double MCRho(double R, double[,] Data, bool dCV, bool gCV)
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, strike, tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            double y1 = Intrinsic((1 + dx) * R, Data, uPrice, uVol, strike, tenor, isCall, dCV, gCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            return (y1 - y0) / dx;
        }
        public override double MCStdError(double R, double[,] Data, bool dCV, bool gCV)
        {
            double Output = Helping.SD(Intrinsic(R, Data, uPrice, uVol, strike, tenor, isCall, dCV, gCV)) / Math.Sqrt(Data.GetLength(0));
            return Output;
        }
    }
    class Helping
    {
        static public double DefaultBoxMuller(Random rnd)
        {
            double x1 = rnd.NextDouble();
            double x2 = rnd.NextDouble();
            double z1 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Cos(2 * Math.PI * x2));
            double z2 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Sin(2 * Math.PI * x2));
            return z1;
        }
        static private double erf(double x)
        {
            //credit to www.johndcook.com/blog/csharp_erf
            double a1 = 0.254829592;
            double a2 = -0.284496736;
            double a3 = 1.421413741;
            double a4 = -1.453152027;
            double a5 = 1.061405429;
            double p = 0.3275911;
            int s = 1;
            if (x < 0)
                s = -1;
            x = Math.Abs(x);
            double t = 1.0 / (1.0 + p * x);
            double y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.Exp(-x * x);
            return s * y;
        }
        static public double CDF(double x)
        {
            double y = (1 + erf(x / Math.Sqrt(2))) / 2;
            return y;
        }
        static public double PDF(double x)
        {
            double y = Math.Exp(-(x * x) / 2) / (1 * Math.Sqrt(2 * Math.PI));
            return y;
        }
        //static public double BoxMuller(Random rnd, double mean, double vol)
        //{
        //    double x1 = rnd.NextDouble();
        //    double x2 = rnd.NextDouble();
        //    double z1 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Cos(2 * Math.PI * x2)) * Math.Sqrt(vol) + mean;
        //    double z2 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Sin(2 * Math.PI * x2)) * Math.Sqrt(vol) + mean;
        //    return z2;
        //}

        //static public double DefaultPolarReject(Random rnd)
        //{
        //    double x1;
        //    double x2;
        //    double w;
        //    double c;
        //    do
        //    {
        //        x1 = rnd.NextDouble() * 2 - 1;
        //        x2 = rnd.NextDouble() * 2 - 1;
        //        w = x1 * x1 + x2 * x2;
        //    }
        //    while (w > 1);
        //    c = Math.Sqrt(-2 * Math.Log(w) / w);
        //    double z1 = c * x1;
        //    double z2 = c * x2;
        //    return z1;
        //}
        static public double[,] DefaultMatrixBoxMuller(int Trials, int Steps, Boolean anti)
        {
            double[,] output = new double[Trials, Steps];
            Random Rnd = new Random();
            if (anti)
            {
                for (int a = 0; a < Trials / 2; a++)
                {
                    for (int b = 0; b < Steps; b++)
                    {
                        output[a, b] = DefaultBoxMuller(Rnd);
                        output[a + Trials / 2, b] = -DefaultBoxMuller(Rnd);
                    }
                }
            }
            else
            {
                for (int a = 0; a < Trials; a++)
                {
                    for (int b = 0; b < Steps; b++)
                    {
                        output[a, b] = DefaultBoxMuller(Rnd);
                    }
                }
            }
            return output;
        }

        //static public double[,] DefaultMatrixPolarReject(int Trials, int Steps, bool anti)
        //{
        //    double[,] output = new double[Trials, Steps];
        //    Random Rnd = new Random();
        //    if (anti)
        //    {
        //        for (int a = 0; a < Trials / 2; a++)
        //        {
        //            for (int b = 0; b < Steps; b++)
        //            {
        //                output[a, b] = DefaultPolarReject(Rnd);
        //                output[a + Trials / 2, b] = -DefaultPolarReject(Rnd);
        //            }
        //        }
        //    }
        //    else
        //    {
        //        for (int a = 0; a < Trials; a++)
        //        {
        //            for (int b = 0; b < Steps; b++)
        //            {
        //                output[a, b] = DefaultPolarReject(Rnd);
        //            }
        //        }
        //    }
        //    return output;
        //}

        static public double SD(double[] input)  // gives the standard deviation of an array
        {
            double z1 = 0;
            double z2 = 0;
            foreach (double x in input)
            {
                z1 += x;
                z2 += Math.Pow(x, 2);
            }
            double output = (z2 / input.Length) - Math.Pow(z1 / input.Length, 2);
            return output;
        }
        static public double Cov(double[] X, double[] Y)  // gives the covariance of two arraies
        {
            double meanX = X.Sum() / X.Length;
            double meanY = Y.Sum() / Y.Length;
            double z = 0;
            for (int i = 0; i < X.Length; i++)
            {
                z = z + (X[i] - meanX) * (Y[i] - meanY);
            }
            return (z / X.Length);
        }
        static private double d1(double S, double K, double r, double T, double vol)
        {
            double output = (Math.Log(S / K) + (r + Math.Pow(vol, 2) / 2) * T) / (vol * Math.Sqrt(T));
            return output;
        }

        //static private double d2(double S, double K, double r, double T, double vol)
        //{
        //    double output = d1(S, K, r, T, vol) - vol * Math.Sqrt(T);
        //    return output;
        //}

        static public double BSDelta(double S, double K, double r, double T, double vol, bool Call)
        {
            if(Call)
            {
                return CDF(d1(S, K, r, T, vol));
            }
            else
            {
                return CDF(d1(S, K, r, T, vol)) - 1;
            }
        }
        static public double BSGamma(double S, double K, double r, double T, double vol)
        {
            double output = PDF(d1(S, K, r, T, vol)) / (S * vol * Math.Sqrt(T));
            return output;
        }
    }
    class Brownian
    {
        static public double GBM(double Drift, double Vol, double Pre, double DeltaT, double RndN)
        {
            double Seq = Pre * Math.Exp((Drift - Vol * Vol / 2) * DeltaT + Vol * Math.Sqrt(DeltaT) * RndN);
            return Seq;
        }
        static public double[] GBMZ(double Drift, double Vol, double S0, double Tenor, double[,] RndN)
        // gives the underlying prices of all trials at the LAST step; prices of a trial follow Geometric Brownian Motion.
        {
            int Trials = RndN.GetLength(0);
            int Steps = RndN.GetLength(1); 
            double[] output = new double[Trials];
            double dt = Tenor / Steps;
            for (int a = 0; a < Trials; a++)
            {
                output[a] = S0;
                for (int b = 0; b < Steps; b++)
                {
                    output[a] = GBM(Drift, Vol, output[a], dt, RndN[a, b]);
                }
            }
            return output;
        }
        static public double[] DCV(double Drift, double Vol, double S0, double K, double Tenor, double[,] RndN, bool Call)
        {
            // gives the summations of delta-based control variate of each trials at the LAST step.
            int Trials = RndN.GetLength(0);
            int Steps = RndN.GetLength(1);
            double dt = Tenor / Steps;
            double[] output = new double[Trials];
            for (int j = 0; j < Trials; j++)
            {
                double s = S0;
                double cv = 0;
                for (int i = 0; i < Steps; i++)
                {
                    double tau = Tenor - dt * i;
                    double BCDelta = Helping.BSDelta(s, K, Drift, tau, Vol, Call);
                    double sSeq = GBM(Drift, Vol, s, dt, RndN[j, i]);
                    cv = cv + BCDelta * (sSeq - s * Math.Exp(Drift * dt));
                    s = sSeq; 
                }
                output[j] = cv;
            }
            return output;
        }
        static public double[] GCV(double Drift, double Vol, double S0, double K, double Tenor, double[,] RndN)
        {
            // gives the summations of gamma-based control variate of each trials at the LAST step.
            int Trials = RndN.GetLength(0);
            int Steps = RndN.GetLength(1);
            double dt = Tenor / Steps;
            double[] output = new double[Trials];
            double egamma = Math.Exp((2 * Drift + Vol * Vol) * dt) - 2 * Math.Exp(Drift * dt) + 1;
            for (int j = 0; j < Trials; j++)
            {
                double s = S0;
                double cv = 0;
                for (int i = 0; i < Steps; i++)
                {
                    double tau = Tenor - dt * i;
                    double BCGamma = Helping.BSGamma(s, K, Drift, tau, Vol);
                    double sSeq = GBM(Drift, Vol, s, dt, RndN[j, i]);
                    cv = cv + BCGamma * (Math.Pow((sSeq - s), 2) - Math.Pow(s, 2) * egamma);
                    s = sSeq;
                }
                output[j] = cv;
            }
            return output;
        }
        //static public double[,] MatrixGBM(double Drift, double Vol, double S0, double Tenor, double[,] RndN) 
        //// gives the underlying prices of all trials at EACH step
        //{
        //    int Trials = RndN.GetLength(0);
        //    int Steps = RndN.GetLength(1); 
        //    double[,] output = new double[Trials, Steps+1];
        //    double dt = Tenor / Steps;
        //    for (int a = 0; a < Trials; a++)
        //    {
        //        output[a, 0] = S0;
        //        for (int b = 0; b < Steps; b++)
        //        {
        //            output[a, b+1] = GBM(Drift, Vol, output[a,b], dt, RndN[a, b]);
        //        }
        //    }
        //    return output;
        //}
    }
}