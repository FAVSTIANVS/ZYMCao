﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW1
{
    public partial class Form1 : Form
    {
        public Boolean call;
        public double S;
        public double K;
        public double r;
        public double sigma;
        public double T;
        public int Trials;
        public int Steps;
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            call = true;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
            S = Convert.ToDouble(textBox1.Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            K = Convert.ToDouble(textBox2.Text);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            r = Convert.ToDouble(textBox3.Text);
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            sigma = Convert.ToDouble(textBox4.Text);
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            T = Convert.ToDouble(textBox5.Text);
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            Trials = Convert.ToInt32(textBox6.Text);
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            Steps = Convert.ToInt32(textBox7.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stock x = new Stock(S, sigma);
            EuropeanOption y = new EuropeanOption(x, r, call, T, K);
            label15.Text = Convert.ToString(y.PriceApproaxi(Trials, Steps));
            label16.Text = Convert.ToString(y.delta(Trials, Steps));
            label17.Text = Convert.ToString(y.gamma(Trials, Steps));
            label18.Text = Convert.ToString(y.vega(Trials, Steps));
            label19.Text = Convert.ToString(y.theta(Trials, Steps));
            label20.Text = Convert.ToString(y.rho(Trials, Steps));
            label21.Text = Convert.ToString(y.Error(Trials, Steps));
        }

        private void label15_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
