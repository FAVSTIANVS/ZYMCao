﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW1
{
    class Instrument
    {
        public double Price { get; set; }
        public double Volatility { get; set; }
        public string Name { get; set; }
        public string MarketTraded { get; set; }
        public string Jurisdiction { get; set; }
        public string Currency { get; set; }
        public DateTime Expiration { get; set; }
    }
    class Stock : Instrument
    {
        public Stock(double price, double vol)
        {
            Price = price;
            Volatility = vol;
        }
    }
    class Option : Instrument
    {
        public Instrument Underlying { get; set; }
        public double RiskFreeRate { get; set; }
        public Boolean IsCall { get; set; }
        public static double Tenor { get; set; }
        public static double underlyingprice;
        public static double underlyingvol;
        public double UnderlyingPrice
        {
            get { return underlyingprice; }
        }
        public double UnderlyingVolatility
        {
            get { return underlyingvol; }
        }
    }
    class EuropeanOption : Option
    {
        public double Strike { get; set; }
        public EuropeanOption(Instrument y, double r, Boolean isCall, double tenor, double strike)
        {
            Underlying = y;
            RiskFreeRate = r;
            IsCall = isCall;
            Tenor = tenor;
            underlyingprice = y.Price;
            underlyingvol = y.Volatility;
            Strike = strike;
        }
        public double PriceApproaxi(int trials, int steps)
        {
            double total = 0;
            double[,] simulatio = Brownian.ItoMatrix(0, underlyingvol, underlyingprice, Tenor, trials, steps);
            double R;
            if (IsCall)
            {
                for (int a = 0; a < trials; a++)
                {
                    if (simulatio[a, steps] > Strike)
                    {
                        total = total + simulatio[a, steps];
                    }
                    else
                    {
                        total = total + Strike;
                    }
                }
                R = (total - Strike * trials) / trials * Math.Exp(-RiskFreeRate * Tenor);
            }
            else
            {
                for (int a = 0; a < trials; a++)
                {
                    if (simulatio[a, steps] < Strike)
                    {
                        total = total + simulatio[a, steps];
                    }
                    else
                    {
                        total = total + Strike;
                    }
                }
                R = (-total + Strike * trials) / trials * Math.Exp(-RiskFreeRate * Tenor);
            }
            return R;
        }
        public double delta(int trials, int steps)
        {
            double p1 = PriceApproaxi(trials, steps);
            underlyingprice = 1.001 * underlyingprice;
            double p2 = PriceApproaxi(trials, steps);
            underlyingprice = underlyingprice / 1.001;
            double output = (p2 - p1) / (0.001 * underlyingprice);
            return output;
        }
        public double gamma(int trials, int steps)
        {
            double p1 = PriceApproaxi(trials, steps);
            underlyingprice = 1.001 * underlyingprice;
            double p2 = PriceApproaxi(trials, steps);
            underlyingprice = underlyingprice / 1.001 / 1.001;
            double p3 = PriceApproaxi(trials, steps);
            underlyingprice = underlyingprice * 1.001;
            double output = (p2 + p3 - 2 * p1) / Math.Pow((0.001 * underlyingprice), 2);
            return output;
        }
        public double vega(int trials, int steps)
        {
            double p1 = PriceApproaxi(trials, steps);
            underlyingvol = 1.001 * underlyingvol;
            double p2 = PriceApproaxi(trials, steps);
            underlyingvol = underlyingvol / 1.001;
            double output = (p2 - p1) / (0.001 * underlyingvol);
            return output;
        }
        public double rho(int trials, int steps)
        {
            double p1 = PriceApproaxi(trials, steps);
            RiskFreeRate = 1.001 * RiskFreeRate;
            double p2 = PriceApproaxi(trials, steps);
            RiskFreeRate = RiskFreeRate / 1.001;
            double output = (p2 - p1) / (0.001 * RiskFreeRate);
            return output;
        }
        public double theta(int trials, int steps)
        {
            double p1 = PriceApproaxi(trials, steps);
            Tenor = 1.001 * Tenor;
            double p2 = PriceApproaxi(trials, steps);
            Tenor = Tenor / 1.001;
            double output = (p2 - p1) / (0.001 * Tenor);
            return output;
        }
        public double Error(int trials, int steps)
        {
            double[,] simulatio = Brownian.ItoMatrix(0, underlyingvol, underlyingprice, Tenor, trials, steps);
            double[] v = new double[trials];
            double sum = 0;
            if (IsCall)
            {
                for (int a = 0; a < trials; a++)
                {
                    if (simulatio[a, steps] > Strike)
                    {
                        v[a] = (simulatio[a, steps] - Strike) * Math.Exp(-RiskFreeRate * Tenor);
                        sum = sum + v[a];
                    }
                    else
                    {
                        v[a] = 0;
                        sum = sum + v[a];
                    }
                }
            }
            else
            {
                for (int a = 0; a < trials; a++)
                {
                    if (simulatio[a, steps] < Strike)
                    {
                        v[a] = (-simulatio[a, steps] + Strike) * Math.Exp(-RiskFreeRate * Tenor);
                        sum = sum + v[a];
                    }
                    else
                    {
                        v[a] = 0;
                        sum = sum + v[a];
                    }
                }
            }
            double u = 0;
            for (int a = 0; a < trials; a++)
            {
                u = Math.Pow((v[a] - sum / trials), 2) + u;
            }
            double output = Math.Sqrt( u / trials / (trials - 1));
            return output;
        }
    }
    class NormDist
    {
        static public double BoxMuller(double mean, double vol)
        {
            Random rnd = new Random();
            double x1 = rnd.NextDouble();
            double x2 = rnd.NextDouble();
            double z1 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Cos(2 * Math.PI * x2)) * Math.Sqrt(vol) + mean;
            double z2 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Sin(2 * Math.PI * x2)) * Math.Sqrt(vol) + mean;
            double[] z = { z1, z2 };
            return z1;
        }
        static public double[,] MatrixBoxMuller(double mean, double vol, int rows, int cols)
        {
            double[,] output = new double[rows, cols];
            for (int a = 0; a < rows; a++)
            {
                for (int b = 0; b < cols; b++)
                {
                    output[a, b] = BoxMuller(mean, vol);
                }
            }
            return output;
        }
    }
    class Brownian
    {
        static public double Ito(double Drift, double Vol, double Pre, double DeltaT, double RndN)
        {
            double Seq = Pre * Math.Exp((Drift - Math.Pow(Vol, 2) / 2) * DeltaT + Vol * Math.Sqrt(DeltaT) * RndN);
            return Seq;
        }
        static public double[,] ItoMatrix(double Drift, double Vol, double S0, double Tenor, int Trials, int Steps)
        {
            double[,] RndN = NormDist.MatrixBoxMuller(Drift, Vol, Trials, Steps);
            double[,] output = new double[Trials, Steps + 1];
            double DeltaT = Tenor / Steps;
            for (int a = 0; a < Trials; a++)
            {
                output[a, 0] = S0;
                for (int b = 0; b < Steps; b++)
                {
                    output[a, b + 1] = Ito(Drift, Vol, output[a, b], DeltaT, RndN[a, b]);
                }
            }
            return output;
        }
    }
}
