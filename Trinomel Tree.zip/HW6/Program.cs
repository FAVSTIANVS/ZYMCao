﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// S: Underlying price, in home currency
// K: Strike price, in home currency
// r: Risk-free rate, unitless as a decimal
// T: Tenor, in years
// sigma: Volatility, unitless as a decimal
// N: number of steps
// M: the Mth step, only in use in auxiliary function
// q: dividend

namespace HW6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("by typing 'A' dealing with American options");
            Console.WriteLine("by typing 'E' dealing with European options");
            string AE = Console.ReadLine();
            Console.WriteLine("by typing 'C' dealing with call options");
            Console.WriteLine("by typing 'P' dealing with put options");
            string CP = Console.ReadLine();
            Console.WriteLine("Underlying price is?");
            double UP = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Strike price is?");
            double SP = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Interest rate is?");
            double I = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Duration is?");
            double jiu = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Volativity is?");
            double sig = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("How many steps? Integers only");
            int steps = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("δ is?");
            double dd = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("What do you want? Option price type 0; delta type 1; gamma type 2; vega 3; theta 4; rho 5.");
            int a = Convert.ToInt16(Console.ReadLine());
            if (a == 0)
            {
                if (AE == "A")
                {
                    if (CP == "C")
                    {
                        Console.WriteLine(ACP(UP, SP, I, jiu, sig, steps, dd));
                    }
                    else if (CP == "P")
                    {
                        Console.WriteLine(APP(UP, SP, I, jiu, sig, steps, dd));
                    }
                }
                else if (AE == "E")
                {
                    if (CP == "C")
                    {
                        Console.WriteLine(EC(UP, SP, I, jiu, sig, steps, dd));
                    }
                    else if (CP == "P")
                    {
                        Console.WriteLine(EP(UP, SP, I, jiu, sig, steps, dd));
                    }
                }
            }
            else if (a == 1)
            {
                if (AE == "A")
                {
                    Console.WriteLine(ACdelta(UP, SP, I, jiu, sig, steps, dd));
                }
                if (AE == "E")
                {
                    Console.WriteLine(ECdelta(UP, SP, I, jiu, sig, steps, dd));
                }
            }
            else if (a == 2)
            {
                if (AE == "A")
                {
                    Console.WriteLine(ACgamma(UP, SP, I, jiu, sig, steps, dd));
                }
                if (AE == "E")
                {
                    Console.WriteLine(ECgamma(UP, SP, I, jiu, sig, steps, dd));
                }
            }
            else if (a == 3)
            {
                if (AE == "A")
                {
                    Console.WriteLine(ACvega(UP, SP, I, jiu, sig, steps, dd));
                }
                if (AE == "E")
                {
                    Console.WriteLine(ECvega(UP, SP, I, jiu, sig, steps, dd));
                }
            }
            else if (a == 4)
            {
                if (AE == "A")
                {
                    Console.WriteLine(ACtheta(UP, SP, I, jiu, sig, steps, dd));
                }
                if (AE == "E")
                {
                    Console.WriteLine(ECtheta(UP, SP, I, jiu, sig, steps, dd));
                }
            }
            else if (a == 5)
            {
                if (AE == "A")
                {
                    Console.WriteLine(ACrho(UP, SP, I, jiu, sig, steps, dd));
                }
                if (AE == "E")
                {
                    Console.WriteLine(ACrho(UP, SP, I, jiu, sig, steps, dd));
                }
            }
        }
        static double uniformBoxMuller()
        {
            double x1;
            double x2;
            Random rnd = new Random();
            x1 = rnd.NextDouble();
            x2 = rnd.NextDouble();
            double z1 = Math.Sqrt(-2 * Math.Log(x1)) * Math.Cos(2 * Math.PI * x2);
            double z2 = Math.Sqrt(-2 * Math.Log(x1)) * Math.Sin(2 * Math.PI * x2);
            return z1;
        }
        static double edx(double sigma, double T, int N)
        // auxiliary variable edx
        {
            double dt = T / N;
            double dx = Math.Sqrt(dt * 3) * sigma;
            return Math.Exp(dx);
        }
        static double[] V(double S, double T, double sigma, int N, int M)
        // this gives the array of all possible underlying prices at the Mth step when the overall steps are N
        {
            double[] Output = new double[2*M+1];
            for(int a = 0; a < 2*M+1; a++)
            {
                Output[a] = S * Math.Pow(edx(sigma, T, N), 2-a);
            }
            return Output;
        }
        static double[] CallPriceEnd(double S, double K, double T, double sigma, int N)
        // this gives the array of the call prices at the end of T
        {
            double[] Output = V(S, T, sigma, N, N);
            for (int a = 0; a < 2 * N + 1; a++)
            {
                Output[a] = Math.Max(Output[a]-K, 0);
            }
            return Output;
        }
        static double[] PutPriceEnd(double S, double K, double T, double sigma, int N)
        // this gives the array of the put prices at the end of T
        {
            double[] Output = V(S, T, sigma, N, N);
            for (int a = 0; a < 2 * N + 1; a++)
            {
                Output[a] = Math.Max(K - Output[a], 0);
            }
            return Output;
        }
        static double[] EPrev(double S, double K, double r, double T, double sigma, int N, double ddd, double[] vector)
        // helping function
        // given vector, which is the the set of European call/put prices at a particular tick, 
        // calculate the European call/put prices at the previous tick
        {
            int b = vector.Length - 2;
            double[] Output = new double[b];
            double dt = T / N;
            double dx = Math.Sqrt(dt * 3) * sigma;
            double v = r - ddd - (Math.Pow(sigma, 2)) / 2;
            double Pu = ((Math.Pow(sigma ,2)*dt + Math.Pow(v*dt, 2))/(Math.Pow(dx, 2)) + v * dt/dx) /2;
            double Pd = ((Math.Pow(sigma, 2) * dt + Math.Pow(v * dt, 2)) / (Math.Pow(dx, 2)) - v * dt / dx) / 2;
            double Pm = 1 - ((Math.Pow(sigma, 2) * dt + Math.Pow(v * dt, 2)) / (Math.Pow(dx, 2)));
            double disc = Math.Exp(-r*dt);
            for (int a = 0; a < b; a++)
            {
                Output[a] = disc * (Pu * (vector[a]) + Pm * (vector[a + 1]) + Pd * (vector[a + 2]));
            }
            return Output;
        }
        static double EC(double S, double K, double r, double T, double sigma, int N, double ddd)
        // calculate the European call price at the beginning of time
        {
            double[] Output = CallPriceEnd( S,  K,  T,  sigma,  N);
            for (int a = 0; a < N; a++)
            {
                Output = EPrev(S, K, r, T, sigma, N, ddd, Output);
            }
            return Output[0];
        }
        static double EP(double S, double K, double r, double T, double sigma, int N, double ddd)
        // calculate the European call/put price at the beginning of time
        {
            double[] Output = PutPriceEnd(S, K, T, sigma, N);
            for (int a = 0; a < N; a++)
            {
                Output = EPrev(S, K, r, T, sigma, N, ddd, Output);
            }
            return Output[0];
        }
        static double[] ACPrev(double S, double K, double r, double T, double sigma, int N, double ddd, double[] vector)
        // helping function
        // given vector, which is the the set of American call prices at a particular tick, 
        // calculate the American call prices at the previous tick
        {
            int b = vector.Length - 2;
            int M = (vector.Length - 1) / 2;
            double[] Output = new double[b];
            double dt = T / N;
            double dx = Math.Sqrt(dt * 3) * sigma;
            double v = r - ddd - (Math.Pow(sigma, 2)) / 2;
            double Pu = ((Math.Pow(sigma, 2) * dt + Math.Pow(v * dt, 2)) / (Math.Pow(dx, 2)) + v * dt / dx) / 2;
            double Pd = ((Math.Pow(sigma, 2) * dt + Math.Pow(v * dt, 2)) / (Math.Pow(dx, 2)) - v * dt / dx) / 2;
            double Pm = 1 - ((Math.Pow(sigma, 2) * dt + Math.Pow(v * dt, 2)) / (Math.Pow(dx, 2)));
            double disc = Math.Exp(-r * dt);
            for (int a = 0; a < b; a++)
            {
                Output[a] = Math.Max(disc * (Pu * (vector[a]) + Pm * (vector[a + 1]) + Pd * (vector[a + 2])), (V(S, T, sigma, N, M)[a] - K));
            }
            return Output;
        }
        static double[] APPrev(double S, double K, double r, double T, double sigma, int N, double ddd, double[] vector)
        // helping function
        // given vector, which is the the set of American put prices at a particular tick, 
        // calculate the American put prices at the previous tick
        {
            int b = vector.Length - 2;
            int M = (vector.Length - 1) / 2;
            double[] Output = new double[b];
            double dt = T / N;
            double dx = Math.Sqrt(dt * 3) * sigma;
            double v = r - ddd - (Math.Pow(sigma, 2)) / 2;
            double Pu = ((Math.Pow(sigma, 2) * dt + Math.Pow(v * dt, 2)) / (Math.Pow(dx, 2)) + v * dt / dx) / 2;
            double Pd = ((Math.Pow(sigma, 2) * dt + Math.Pow(v * dt, 2)) / (Math.Pow(dx, 2)) - v * dt / dx) / 2;
            double Pm = 1 - ((Math.Pow(sigma, 2) * dt + Math.Pow(v * dt, 2)) / (Math.Pow(dx, 2)));
            double disc = Math.Exp(-r * dt);
            for (int a = 0; a < b; a++)
            {
                Output[a] = Math.Max(disc * (Pu * (vector[a]) + Pm * (vector[a + 1]) + Pd * (vector[a + 2])), (-V(S, T, sigma, N, M)[a] + K));
            }
            return Output;
        }
        static double ACP(double S, double K, double r, double T, double sigma, int N, double ddd)
        // calculate the American call price at the beginning of time
        {
            double[] Output = PutPriceEnd(S, K, T, sigma, N);
            for (int a = 0; a < N; a++)
            {
                Output = ACPrev(S, K, r, T, sigma, N, ddd, Output);
            }
            return Output[0];
        }
        static double APP(double S, double K, double r, double T, double sigma, int N, double ddd)
        // calculate the American put price at the beginning of time
        {
            double[] Output = PutPriceEnd(S, K, T, sigma, N);
            for (int a = 0; a < N; a++)
            {
                Output = APPrev(S, K, r, T, sigma, N, ddd, Output);
            }
            return Output[0];
        }
        static double ECdelta(double S, double K, double r, double T, double sigma, int N, double ddd)
        // delta for European call options
        {
            double[] A = CallPriceEnd(S, K, T, sigma, N);
            for (int a = 0; a < N - 1; a++)
            {
                A = EPrev(S, K, r, T, sigma, N, ddd, A);
            }
            double[] B = V(S, T, sigma, N, 1);
            // array B is underlying prices, array A is option prices when t = 1
            double z = (A[0] - A[2]) / (B[0] - B[2]);
            return z;
        }
        static double ACdelta(double S, double K, double r, double T, double sigma, int N, double ddd)
        // delta for American call options
        {
            double[] A = CallPriceEnd(S, K, T, sigma, N);
            for (int a = 0; a < N - 1; a++)
            {
                A = ACPrev(S, K, r, T, sigma, N, ddd, A);
            }
            double[] B = V(S, T, sigma, N, 1);
            // array B is underlying prices, array A is option prices when t = 1
            double z = (A[0] - A[2]) / (B[0] - B[2]);
            return z;
        }
        static double ECgamma(double S, double K, double r, double T, double sigma, int N, double ddd)
        // gamma for European call options
        {
            double[] A = CallPriceEnd(S, K, T, sigma, N);
            for (int a = 0; a < N - 1; a++)
            {
                A = EPrev(S, K, r, T, sigma, N, ddd, A);
            }
            double[] B = V(S, T, sigma, N, 1);
            // array B is underlying prices, array A is option prices when t = 1
            double z = 2 * ((A[0] - A[1]) / (B[0] - B[1]) - (A[1] - A[2]) / (B[1] - B[2])) / (B[0] - B[2]);
            return z;
        }
        static double ACgamma(double S, double K, double r, double T, double sigma, int N, double ddd)
        // gamma for American call options
        {
            double[] A = CallPriceEnd(S, K, T, sigma, N);
            for (int a = 0; a < N - 1; a++)
            {
                A = ACPrev(S, K, r, T, sigma, N, ddd, A);
            }
            double[] B = V(S, T, sigma, N, 1);
            // array B is underlying prices, array A is option prices when t = 1
            double z = 2 * ((A[0] - A[1]) / (B[0] - B[1]) - (A[1] - A[2]) / (B[1] - B[2])) / (B[0] - B[2]);
            return z;
        }
        static double ECvega(double S, double K, double r, double T, double sigma, int N, double ddd)
        // vega for European call options
        {
            double z = (EC(S, K, r, T, sigma * 1.00001, N, ddd) - EC(S, K, r, T, sigma * 0.99999, N, ddd)) / (0.00002 * sigma);
            return z;
        }
        static double ACvega(double S, double K, double r, double T, double sigma, int N, double ddd)
        // vega for American call options
        {
            double z = (ACP(S, K, r, T, sigma * 1.00001, N, ddd) - ACP(S, K, r, T, sigma * 0.99999, N, ddd)) / (0.00002 * sigma);
            return z;
        }
        static double ECtheta(double S, double K, double r, double T, double sigma, int N, double ddd)
        // theta for European call options
        {
            double[] A = CallPriceEnd(S, K, T, sigma, N);
            for (int a = 0; a < N - 2; a++)
            {
                A = EPrev(S, K, r, T, sigma, N, ddd, A);
            }
            double z = (EC(S, K, r, T, sigma, N, ddd) - A[2]) / (2*T/N);
            return z;
        }
        static double ACtheta(double S, double K, double r, double T, double sigma, int N, double ddd)
        // theta for American call options
        {
            double[] A = CallPriceEnd(S, K, T, sigma, N);
            for (int a = 0; a < N - 2; a++)
            {
                A = ACPrev(S, K, r, T, sigma, N, ddd, A);
            }
            double z = (EC(S, K, r, T, sigma, N, ddd) - A[2]) / (2 * T / N);
            return z;
        }
        static double ECrho(double S, double K, double r, double T, double sigma, int N, double ddd)
        // rho for European call options
        {
            double z = (EC(S, K, r * 1.00001, T, sigma, N, ddd) - EC(S, K, r * 0.99999, T, sigma, N, ddd)) / (0.00002 * r);
            return z;
        }
        static double ACrho(double S, double K, double r, double T, double sigma, int N, double ddd)
        // rho for American call options
        {
            double z = (ACP(S, K, r * 1.00001, T, sigma, N, ddd) - ACP(S, K, r * 0.99999, T, sigma, N, ddd)) / (0.00002 * r);
            return z;
        }
    }
}


