USE [MFM_C#_Object_Model]
GO

/****** Object:  Table [dbo].[Transaction]    Script Date: 3/16/2020 12:16:41 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Transaction](
	[Transaction ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Quantity of Buy] [int] NOT NULL,
	[Quantity of Sell] [int] NOT NULL,
	[Price of Buy] [decimal](18, 0) NOT NULL,
	[Price of Sell] [decimal](18, 0) NOT NULL,
	[MarketTraded] [varchar](50) NULL,
	[ID Instrument Buyed] [bigint] NOT NULL,
	[ID Instrument Selled] [bigint] NOT NULL,
 CONSTRAINT [PK_Transaction] PRIMARY KEY CLUSTERED 
(
	[Transaction ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Transaction]  WITH CHECK ADD  CONSTRAINT [FK_BuyedID] FOREIGN KEY([ID Instrument Buyed])
REFERENCES [dbo].[Instrument] ([Instrument ID])
GO

ALTER TABLE [dbo].[Transaction] CHECK CONSTRAINT [FK_BuyedID]
GO

ALTER TABLE [dbo].[Transaction]  WITH CHECK ADD  CONSTRAINT [FK_SelledID] FOREIGN KEY([ID Instrument Selled])
REFERENCES [dbo].[Instrument] ([Instrument ID])
GO

ALTER TABLE [dbo].[Transaction] CHECK CONSTRAINT [FK_SelledID]
GO

