USE [MFM_C#_Object_Model]
GO

/****** Object:  Table [dbo].[Option]    Script Date: 3/16/2020 12:16:26 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Option](
	[Option ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Instrument ID] [bigint] NOT NULL,
	[Underlying ID] [bigint] NOT NULL,
	[MC Price] [decimal](18, 0) NULL,
	[BS Price] [decimal](18, 0) NULL,
	[Option Symbol] [varchar](50) NULL,
 CONSTRAINT [PK_Option] PRIMARY KEY CLUSTERED 
(
	[Option ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Option]  WITH CHECK ADD  CONSTRAINT [FK_Option_Instrument] FOREIGN KEY([Instrument ID])
REFERENCES [dbo].[Instrument] ([Instrument ID])
GO

ALTER TABLE [dbo].[Option] CHECK CONSTRAINT [FK_Option_Instrument]
GO

