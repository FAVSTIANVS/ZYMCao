USE [MFM_C#_Object_Model]
GO

/****** Object:  Table [dbo].[Instrument]    Script Date: 3/16/2020 12:16:16 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Instrument](
	[Instrument ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Instrument Symbol] [varchar](50) NULL,
	[Market Traded] [varchar](50) NULL,
	[Realized Volatility] [decimal](18, 0) NULL,
	[Currency] [varchar](50) NULL,
 CONSTRAINT [PK_Instrument] PRIMARY KEY CLUSTERED 
(
	[Instrument ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

