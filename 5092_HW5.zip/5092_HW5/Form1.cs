﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace _5092_HW5
{
    public partial class Form1 : Form
    {
        Stopwatch watch = new Stopwatch();
        public Form1()
        {
            InitializeComponent();
            errorProvider1.SetIconAlignment(SI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(SI, 3);
            errorProvider1.SetIconAlignment(KI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(KI, 3);
            errorProvider1.SetIconAlignment(VolI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(VolI, 3);
            errorProvider1.SetIconAlignment(TI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(TI, 3);
            errorProvider1.SetIconAlignment(TrialsI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(TrialsI, 3);
            errorProvider1.SetIconAlignment(StepsI, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(StepsI, 3);
            CO.Text = Convert.ToString(System.Environment.ProcessorCount);
            KnockOut.Enabled = false;
            RebateI.Enabled = false;
            BarrierI.Enabled = false;
        }
        private void Form1_Load(object sender, EventArgs e) { }
        private void SI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(SI.Text, out _) || Convert.ToDouble(SI.Text) < 0)
                errorProvider1.SetError(SI, "Please enter a positive number!");
            else
                errorProvider1.SetError(SI, string.Empty);
        }
        private void KI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(KI.Text, out _) || Convert.ToDouble(KI.Text) < 0)
                errorProvider1.SetError(KI, "Please enter a positive number!");
            else
                errorProvider1.SetError(KI, string.Empty);
        }
        private void RI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(RI.Text, out _) || Convert.ToDouble(RI.Text) < 0)
                errorProvider1.SetError(RI, "Please enter a positive number!");
            else
                errorProvider1.SetError(RI, string.Empty);
        }
        private void TI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(TI.Text, out _) || Convert.ToDouble(TI.Text) < 0)
                errorProvider1.SetError(TI, "Please enter a positive number!");
            else
                errorProvider1.SetError(TI, string.Empty);
        }
        private void VolI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(VolI.Text, out _) || Convert.ToDouble(VolI.Text) < 0)
                errorProvider1.SetError(VolI, "Please enter a positive number!");
            else
                errorProvider1.SetError(VolI, string.Empty);
        }
        private void TrialsI_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(TrialsI.Text, out _) || Convert.ToInt32(TrialsI.Text) < 0)
                errorProvider1.SetError(TrialsI, "Please enter a positive integer!");
            else
                errorProvider1.SetError(TrialsI, string.Empty);
        }
        private void StepsI_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(StepsI.Text, out _) || Convert.ToInt32(StepsI.Text) < 0)
                errorProvider1.SetError(StepsI, "Please enter a positive integer!");
            else
                errorProvider1.SetError(StepsI, string.Empty);
        }
        private void RebateI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(RebateI.Text, out _) || Convert.ToDouble(RebateI.Text) < 0)
                errorProvider1.SetError(RebateI, "Please enter a positive number!");
            else
                errorProvider1.SetError(RebateI, string.Empty);
        }
        private void BarrierI_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(BarrierI.Text, out _) || Convert.ToDouble(BarrierI.Text) < 0)
                errorProvider1.SetError(BarrierI, "Please enter a positive number!");
            else
                errorProvider1.SetError(BarrierI, string.Empty);
        }
        private void Euro_CheckedChanged(object sender, EventArgs e)
        {
            if (Euro.Checked == true)
            {
                KnockOut.Enabled = false;
                RebateI.Enabled = false;
                BarrierI.Enabled = false;
            }
        }
        private void Asian_CheckedChanged(object sender, EventArgs e)
        {
            if (Asian.Checked == true)
            {
                KnockOut.Enabled = false;
                RebateI.Enabled = false;
                BarrierI.Enabled = false;
            }
        }
        private void Digital_CheckedChanged(object sender, EventArgs e)
        {
            if (Digital.Checked == true)
            {
                KnockOut.Enabled = false;
                RebateI.Enabled = true;
                BarrierI.Enabled = false;
            }
        }
        private void Barrier_CheckedChanged(object sender, EventArgs e)
        {
            if (Barrier.Checked == true)
            {
                KnockOut.Enabled = true;
                RebateI.Enabled = false;
                BarrierI.Enabled = true;
            }
        }
        private void Lookback_CheckedChanged(object sender, EventArgs e)
        {
            if (Euro.Checked == true)
            {
                KnockOut.Enabled = false;
                RebateI.Enabled = false;
                BarrierI.Enabled = false;
            }
        }
        private void Range_CheckedChanged(object sender, EventArgs e)
        {
            if (Range.Checked == true)
            {
                KnockOut.Enabled = false;
                RebateI.Enabled = false;
                BarrierI.Enabled = false;
            }
        }
        private void Outcome_Click(object sender, EventArgs e)
        {
            PBar.Value = 0;
            watch.Reset();
            watch.Start();
            Equity U = new Equity(Convert.ToDouble(SI.Text), Convert.ToDouble(VolI.Text));
            if(Euro.Checked) { EuropeanOption Opt = new EuropeanOption(U, Convert.ToDouble(KI.Text), Convert.ToDouble(TI.Text), Call.Checked);
                PBar.Value = 20;
                double[,] data = MMA.StdMatrixBoxMuller(Convert.ToInt32(TrialsI.Text), Convert.ToInt32(StepsI.Text), Antithetic.Checked);
                PBar.Value = 50;
                PO.Text = Opt.MCPrice(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                DO.Text = Opt.MCDelta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                GO.Text = Opt.MCGamma(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                PBar.Value = 75;
                VO.Text = Opt.MCVega(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                ThO.Text = Opt.MCTheta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                RhO.Text = Opt.MCRho(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                SEO.Text = Opt.MCStdError(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
            }
            else if (Asian.Checked) { AsianOption Opt = new AsianOption(U, Convert.ToDouble(KI.Text), Convert.ToDouble(TI.Text), Call.Checked);
                PBar.Value = 20;
                double[,] data = MMA.StdMatrixBoxMuller(Convert.ToInt32(TrialsI.Text), Convert.ToInt32(StepsI.Text), Antithetic.Checked);
                PBar.Value = 50;
                PO.Text = Opt.MCPrice(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                DO.Text = Opt.MCDelta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                GO.Text = Opt.MCGamma(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                PBar.Value = 75;
                VO.Text = Opt.MCVega(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                ThO.Text = Opt.MCTheta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                RhO.Text = Opt.MCRho(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                SEO.Text = Opt.MCStdError(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
            }
            else if (Digital.Checked) { DigitalOption Opt = new DigitalOption(U, Convert.ToDouble(KI.Text), Convert.ToDouble(TI.Text), Call.Checked, Convert.ToDouble(RebateI.Text));
                PBar.Value = 20;
                double[,] data = MMA.StdMatrixBoxMuller(Convert.ToInt32(TrialsI.Text), Convert.ToInt32(StepsI.Text), Antithetic.Checked);
                PBar.Value = 50;
                PO.Text = Opt.MCPrice(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                DO.Text = Opt.MCDelta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                GO.Text = Opt.MCGamma(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                PBar.Value = 75;
                VO.Text = Opt.MCVega(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                ThO.Text = Opt.MCTheta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                RhO.Text = Opt.MCRho(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                SEO.Text = Opt.MCStdError(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
            }
            else if (Barrier.Checked) { BarrierOption Opt = new BarrierOption(U, Convert.ToDouble(KI.Text), Convert.ToDouble(TI.Text), Call.Checked, Convert.ToDouble(BarrierI.Text), KnockOut.Checked);
                PBar.Value = 20;
                double[,] data = MMA.StdMatrixBoxMuller(Convert.ToInt32(TrialsI.Text), Convert.ToInt32(StepsI.Text), Antithetic.Checked);
                PBar.Value = 50;
                PO.Text = Opt.MCPrice(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                DO.Text = Opt.MCDelta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                GO.Text = Opt.MCGamma(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                PBar.Value = 75;
                VO.Text = Opt.MCVega(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                ThO.Text = Opt.MCTheta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                RhO.Text = Opt.MCRho(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                SEO.Text = Opt.MCStdError(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
            }
            else if (Lookback.Checked) { LookbackOption Opt = new LookbackOption(U, Convert.ToDouble(KI.Text), Convert.ToDouble(TI.Text), Call.Checked);
                PBar.Value = 20;
                double[,] data = MMA.StdMatrixBoxMuller(Convert.ToInt32(TrialsI.Text), Convert.ToInt32(StepsI.Text), Antithetic.Checked);
                PBar.Value = 50;
                PO.Text = Opt.MCPrice(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                DO.Text = Opt.MCDelta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                GO.Text = Opt.MCGamma(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                PBar.Value = 75;
                VO.Text = Opt.MCVega(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                ThO.Text = Opt.MCTheta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                RhO.Text = Opt.MCRho(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                SEO.Text = Opt.MCStdError(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
            }
            else { RangeOption Opt = new RangeOption(U, Convert.ToDouble(KI.Text), Convert.ToDouble(TI.Text), Call.Checked);
                PBar.Value = 20;
                double[,] data = MMA.StdMatrixBoxMuller(Convert.ToInt32(TrialsI.Text), Convert.ToInt32(StepsI.Text), Antithetic.Checked);
                PBar.Value = 50;
                PO.Text = Opt.MCPrice(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                DO.Text = Opt.MCDelta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                GO.Text = Opt.MCGamma(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                PBar.Value = 75;
                VO.Text = Opt.MCVega(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                ThO.Text = Opt.MCTheta(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                RhO.Text = Opt.MCRho(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
                SEO.Text = Opt.MCStdError(Convert.ToDouble(RI.Text), data, CV.Checked).ToString();
            }
            watch.Stop();
            PBar.Value = 100;
            cTimerO.Text = watch.Elapsed.Minutes.ToString() + ":" + watch.Elapsed.Seconds.ToString() + ":" + watch.Elapsed.Milliseconds.ToString();
        }
    }
    class Instrument
    {
        protected double price, volatility;
        //protected string name;
        //protected string marketTraded;
        //protected string jurisdiction;
        //protected string currency;
        //protected DateTime issuance;
        //protected DateTime expiration;
        public double Price { get { return price; } set { price = value; } }
        public double Volatility { get { return volatility; } set { volatility = value; } }
        //public string Name { get { return name; } set { name = value; } }
        //public string MarketTraded { get { return marketTraded; } set { marketTraded = value; } }
        //public string Jurisdiction { get { return jurisdiction; } set { jurisdiction = value; } }
        //public string Currency { get { return currency; } set { currency = value; } }
        //public DateTime Issuance { get { return issuance; } set { issuance = value; } }
        //public DateTime Expiration { get { return expiration; } set { expiration = value; } }
        protected static double dx = 0.0001; // used as infinitesimal in order to calculate partial derivatives
    }
    class Equity : Instrument
    {
        public Equity(double p, double vol)
        {
            price = p;
            volatility = vol;
        }
    }
    abstract class Option : Instrument
    {
        protected bool isCall;
        protected double tenor, strike, uPrice, uVol;
        protected Instrument underlying;
        public bool IsCall { get { return isCall; } set { isCall = value; } }
        public double Tenor { get { return tenor; } set { tenor = value; } }
        public double Strike { get { return strike; } set { strike = value; } }
        public Instrument Underlying { get { return underlying; } set { underlying = value; } }
        public Option(Instrument U, double K, double T, bool Call)
        {
            underlying = U;
            strike = K;
            tenor = T;
            isCall = Call;
            uPrice = U.Price;
            uVol = U.Volatility;
        }
        protected virtual double[] Intrinsic(double R, double[,] Data, double s, double vol, double k, double t, bool c, bool dcv) { return new double[] { 0 }; }
        // return the array of intrinsic values of the option at the last step; the length of the array is the number of trials.
        // "c" stands for if this option is a call; 
        // "dcv" stands for if employing delta-based control variate method;
        //public virtual double MCPrice(double R, double[,] Data, bool dCV) { return 0; }
        //public virtual double MCDelta(double R, double[,] Data, bool dCV) { return 0; }
        //public virtual double MCGamma(double R, double[,] Data, bool dCV) { return 0; }
        //public virtual double MCVega(double R, double[,] Data, bool dCV) { return 0; }
        //public virtual double MCTheta(double R, double[,] Data, bool dCV) { return 0; }
        //public virtual double MCRho(double R, double[,] Data, bool dCV) { return 0; }
        //public virtual double MCStdError(double R, double[,] Data, bool dCV) { return 0; }
        public double MCPrice(double R, double[,] Data, bool dCV) // price; "MC" stands for Monte Carlo simulation
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, strike, tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            return y0;
        }
        public double MCDelta(double R, double[,] Data, bool dCV)
        {
            double y0 = Intrinsic(R, Data, (1 - dx) * uPrice, uVol, strike, tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            double y1 = Intrinsic(R, Data, (1 + dx) * uPrice, uVol, strike, tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            return (y1 - y0) / (2 * dx);
        }
        public double MCGamma(double R, double[,] Data, bool dCV)
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, strike, tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            double y1 = Intrinsic(R, Data, (1 + dx) * uPrice, uVol, strike, tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            double y2 = Intrinsic(R, Data, (1 - dx) * uPrice, uVol, strike, tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            return (y1 + y2 - 2 * y0) / (dx * dx);
        }
        public double MCVega(double R, double[,] Data, bool dCV)
        {
            double y0 = Intrinsic(R, Data, uPrice, (1 - dx) * uVol, strike, tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            double y1 = Intrinsic(R, Data, uPrice, (1 + dx) * uVol, strike, tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-R * tenor);
            return (y1 - y0) / (2 * dx);
        }
        public double MCTheta(double R, double[,] Data, bool dCV)
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, strike, (1 - dx) * tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-R * (1 - dx) * tenor);
            double y1 = Intrinsic(R, Data, uPrice, uVol, strike, (1 + dx) * tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-R * (1 + dx) * tenor);
            return (y1 - y0) / (2 * dx);
        }
        public double MCRho(double R, double[,] Data, bool dCV)
        {
            double y0 = Intrinsic((1 - dx) * R, Data, uPrice, uVol, strike, tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-(1 - dx) * R * tenor);
            double y1 = Intrinsic((1 + dx) * R, Data, uPrice, uVol, strike, tenor, isCall, dCV).Sum() / Data.GetLength(0) * Math.Exp(-(1 + dx) * R * tenor);
            return (y1 - y0) / (2 * dx);
        }
        public double MCStdError(double R, double[,] Data, bool dCV)
        {
            double Output = MMA.SD(Intrinsic(R, Data, uPrice, uVol, strike, tenor, isCall, dCV)) / Math.Sqrt(Data.GetLength(0));
            return Output;
        }

        // Above is Monte Carlo Simulation
        // Below is Black & Scholes.

        public double d1(double r) { return (Math.Log(uPrice / strike) + (r + Math.Pow(uVol, 2) / 2) * tenor) / (uVol * Math.Sqrt(tenor)); }
        public double d2(double r) { return (Math.Log(uPrice / strike) - (r + Math.Pow(uVol, 2) / 2) * tenor) / (uVol * Math.Sqrt(tenor)); }
        public double BSPrice(double r)
        {
            if (isCall) { return uPrice * MMA.CDF(d1(r)) - strike * Math.Exp(-r * tenor) * MMA.CDF(d2(r)); }
            else { return strike * Math.Exp(-r * tenor) * MMA.CDF(-d2(r)) - uPrice * MMA.CDF(-d1(r)); }
        }
        public double BSDelta(double r) { return isCall ? MMA.CDF(d1(r)) : MMA.CDF(d1(r)) - 1; }
        public double BSGamma(double r) { return MMA.PDF(d1(r)) / (uPrice * uVol * Math.Sqrt(tenor)); }
        public double BSVega(double r) { return uPrice * MMA.PDF(d1(r)) * Math.Sqrt(tenor); }
        public double BSTheta(double r)
        {
            if (isCall)
            {
                return -(uPrice * MMA.PDF(d1(r) * uVol) / (2 * Math.Sqrt(tenor)) - r * Strike * Math.Exp(-r * tenor) * MMA.CDF(d2(r)));
            }
            else
            {
                return -(uPrice * MMA.PDF(d1(r) * uVol) / (2 * Math.Sqrt(tenor)) + r * Strike * Math.Exp(-r * tenor) * MMA.CDF(-d2(r)));
            }
        }
        public double BSRho(double r)
        {
            if (isCall) { return strike * tenor * Math.Exp(-r * tenor) * MMA.CDF(d2(r)); }
            else { return -strike * tenor * Math.Exp(-r * tenor) * MMA.CDF(-d2(r)); }
        }
    }
    class DigitalOption : Option
    {
        double rebate;
        public double Rebate { get { return rebate; } set { rebate = value; } }
        public DigitalOption(Instrument U, double K, double T, bool Call, double Reb) : base(U, K, T, Call) { rebate = Reb; }
        protected override double[] Intrinsic(double R, double[,] Data, double s, double vol, double k, double t, bool c, bool CV)
        {
            int simTrials = Data.GetLength(0);
            double[] sim = Brownian.GBMZ(R, vol, s, t, Data);
            double[] Output = new double[simTrials];
            if (CV) // whether or not control variate is employed
            {
                double[] cv1 = Brownian.CV(R, this, Data, this.BSGamma);
                if (c) // whether or not this option is a call
                    //for (int i = 0; i < simTrials; i++)
                    //{
                    //    Output[i] = Math.Max(sim[i] - k, 0) - cv1[i];
                    //}
                    Parallel.For(0, simTrials, i => {
                        Output[i] = (sim[i] - k > 0) ? rebate - cv1[i] : 0 - cv1[i];
                    });
                else
                    //for (int i = 0; i < simTrials; i++)
                    //{
                    //    Output[i] = Math.Max(k - sim[i], 0) - cv1[i];
                    //}
                    Parallel.For(0, simTrials, i => {
                        Output[i] = (k - sim[i] > 0) ? rebate - cv1[i] : 0 - cv1[i];
                    });
            }
            else
            {
                if (c)
                    //for (int i = 0; i < simTrials; i++)
                    //{
                    //    Output[i] = Math.Max(sim[i] - k, 0);
                    //}
                    Parallel.For(0, simTrials, i => {
                        Output[i] = (sim[i] - k > 0) ? rebate : 0;
                    });
                else
                    //for (int i = 0; i < simTrials; i++)
                    //{
                    //    Output[i] = Math.Max(k - sim[i], 0);
                    //}
                    Parallel.For(0, simTrials, i => {
                        Output[i] = (k - sim[i] > 0) ? rebate : 0;
                    });
            }
            return Output;
        }
    }
    class BarrierOption : Option
    {
        double barrier;
        bool knockOut;
        public double Barrier { get { return barrier; } set { barrier = value; } }
        public bool KnockOut { get { return knockOut; } set { knockOut = value; } }
        public BarrierOption(Instrument U, double K, double T, bool Call, double Bar, bool KnkO) : base(U, K, T, Call) { barrier = Bar; KnkO = knockOut; }
        protected override double[] Intrinsic(double R, double[,] Data, double s, double vol, double k, double t, bool c, bool CV)
        {
            int simTrials = Data.GetLength(0);
            int simSteps = Data.GetLength(1);
            double[] sim = new double[simTrials];
            Parallel.For(0, simTrials, i => {
                double[] route = Brownian.Path(R, vol, s, t / simSteps, Enumerable.Range(0, simSteps).Select(x => Data[i, x]).ToArray());
                if(barrier > s)
                {
                    if (knockOut)
                    {
                        if (route.Max() > barrier) { sim[i] = 0; }
                        else { sim[i] = route[route.Length - 1]; }
                    }
                    else
                    {
                        if (route.Max() < barrier) { sim[i] = 0; }
                        else { sim[i] = route[route.Length - 1]; }
                    }
                }
                else
                {
                    if (knockOut)
                    {
                        if (route.Min() < barrier) { sim[i] = 0; }
                        else { sim[i] = route[route.Length - 1]; }
                    }
                    else
                    {
                        if (route.Min() > barrier) { sim[i] = 0; }
                        else { sim[i] = route[route.Length - 1]; }
                    }
                }
            });
            double[] Output = new double[simTrials];
            if (CV) // whether or not delta-based control variate is employed
            {
                double[] cv1 = Brownian.CV(R, this, Data, this.BSDelta);
                if (c) // whether or not this option is a call
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(sim[i] - k, 0) - cv1[i];
                    }
                else
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(k - sim[i], 0) - cv1[i];
                    }
            }
            else
            {
                if (c)
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(sim[i] - k, 0);
                    }
                else
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(k - sim[i], 0);
                    }
            }
            return Output;
        }
    }
    class LookbackOption : Option
    {
        public LookbackOption(Instrument U, double K, double T, bool Call) : base(U, K, T, Call) { }
        protected override double[] Intrinsic(double R, double[,] Data, double s, double vol, double k, double t, bool c, bool CV)
        {
            int simTrials = Data.GetLength(0);
            int simSteps = Data.GetLength(1);
            double[] sim = new double[simTrials];
            Parallel.For(0, simTrials, i => {
                sim[i] = Brownian.Path(R, vol, s, t / simSteps, Enumerable.Range(0, simSteps).Select(x => Data[i, x]).ToArray()).Max();
            });
            double[] Output = new double[simTrials];
            if (CV) // whether or not delta-based control variate is employed
            {
                double[] cv1 = Brownian.CV(R, this, Data, this.BSDelta);
                if (c) // whether or not this option is a call
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(sim[i] - k, 0) - cv1[i];
                    }
                else
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(k - sim[i], 0) - cv1[i];
                    }
            }
            else
            {
                if (c)
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(sim[i] - k, 0);
                    }
                else
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(k - sim[i], 0);
                    }
            }
            return Output;
        }
    }
    class RangeOption : Option
    {
        public RangeOption(Instrument U, double K, double T, bool Call) : base(U, K, T, Call) { }
        protected override double[] Intrinsic(double R, double[,] Data, double s, double vol, double k, double t, bool c, bool CV)
        {
            int simTrials = Data.GetLength(0);
            int simSteps = Data.GetLength(1);
            double[] sim = new double[simTrials];
            Parallel.For(0, simTrials, i => {
                double[] route = Brownian.Path(R, vol, s, t / simSteps, Enumerable.Range(0, simSteps).Select(x => Data[i, x]).ToArray());
                sim[i] = route.Max() - route.Min();
            });
            double[] Output = new double[simTrials];
            if (CV) // whether or not control variate is employed
            {
                double[] cv1 = Brownian.CV(R, this, Data, this.BSDelta);
                for (int i = 0; i < simTrials; i++)
                {
                    Output[i] = sim[i] - cv1[i];
                }
            }
            else
            {
                for (int i = 0; i < simTrials; i++)
                {
                    Output[i] = Math.Max(sim[i] - k, 0);
                }
            }
            return Output;
        }
    }
    class AsianOption : Option
    {
        public AsianOption(Instrument U, double K, double T, bool Call) : base(U, K, T, Call) { }
        protected override double[] Intrinsic(double R, double[,] Data, double s, double vol, double k, double t, bool c, bool dCV)
        {
            int simTrials = Data.GetLength(0);
            int simSteps = Data.GetLength(1);
            double[] sim = new double[simTrials];
            Parallel.For(0, simTrials, i => {
                sim[i] = Brownian.Path(R, vol, s, t / simSteps, Enumerable.Range(0, simSteps).Select(x => Data[i, x]).ToArray()).Sum()/ simSteps;
            });
            double[] Output = new double[simTrials];
            if (dCV) // whether or not delta-based control variate is employed
            {
                double[] cv1 = Brownian.CV(R, this, Data, this.BSDelta);
                if (c) // whether or not this option is a call
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(sim[i] - k, 0) - cv1[i];
                    }
                else
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(k - sim[i], 0) - cv1[i];
                    }
            }
            else
            {
                if (c)
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(sim[i] - k, 0);
                    }
                else
                    for (int i = 0; i < simTrials; i++)
                    {
                        Output[i] = Math.Max(k - sim[i], 0);
                    }
            }
            return Output;
        }
    }
        class EuropeanOption : Option
    {
        public EuropeanOption(Instrument U, double K, double T, bool Call) : base(U, K, T, Call) { }
        protected override double[] Intrinsic(double R, double[,] Data, double s, double vol, double k, double t, bool c, bool dCV)
        {
            int simTrials = Data.GetLength(0);
            double[] sim = Brownian.GBMZ(R, vol, s, t, Data);
            double[] Output = new double[simTrials];
            if (dCV) // whether or not delta-based control variate is employed
            {
                double[] cv1 = Brownian.CV(R, this, Data, this.BSDelta);
                if (c) // whether or not this option is a call
                    //for (int i = 0; i < simTrials; i++)
                    //{
                    //    Output[i] = Math.Max(sim[i] - k, 0) - cv1[i];
                    //}
                    Parallel.For(0, simTrials, i => {
                        Output[i] = Math.Max(sim[i] - k, 0) - cv1[i];
                    });
                else
                    //for (int i = 0; i < simTrials; i++)
                    //{
                    //    Output[i] = Math.Max(k - sim[i], 0) - cv1[i];
                    //}
                    Parallel.For(0, simTrials, i => {
                        Output[i] = Math.Max(k - sim[i], 0) - cv1[i];
                    });
            }
            else
            {
                if (c)
                    //for (int i = 0; i < simTrials; i++)
                    //{
                    //    Output[i] = Math.Max(sim[i] - k, 0);
                    //}
                    Parallel.For(0, simTrials, i => {
                        Output[i] = Math.Max(sim[i] - k, 0);
                    });
                else
                    //for (int i = 0; i < simTrials; i++)
                    //{
                    //    Output[i] = Math.Max(k - sim[i], 0);
                    //}
                    Parallel.For(0, simTrials, i => {
                        Output[i] = Math.Max(k - sim[i], 0);
                    });
            }
            return Output;
        }
    }
    class MMA
    {
        static public double StdBoxMuller(Random rnd)
        {
            double x1 = rnd.NextDouble();
            double x2 = rnd.NextDouble();
            double z1 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Cos(2 * Math.PI * x2));
            double z2 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Sin(2 * Math.PI * x2));
            return z1;
        }
        static private double erf(double x)
        {
            //credit to www.johndcook.com/blog/csharp_erf
            double a1 = 0.254829592;
            double a2 = -0.284496736;
            double a3 = 1.421413741;
            double a4 = -1.453152027;
            double a5 = 1.061405429;
            double p = 0.3275911;
            int s = 1;
            if (x < 0)
                s = -1;
            x = Math.Abs(x);
            double t = 1.0 / (1.0 + p * x);
            double y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.Exp(-x * x);
            return s * y;
        }
        static public double CDF(double x)
        // CDF of standard normal distribution
        {
            double y = (1 + erf(x / Math.Sqrt(2))) / 2;
            return y;
        }
        static public double PDF(double x)
        // PDF of standard normal distribution
        {
            double y = Math.Exp(-(x * x) / 2) / (1 * Math.Sqrt(2 * Math.PI));
            return y;
        }
        //static public double BoxMuller(Random rnd, double mean, double vol)
        //{
        //    double x1 = rnd.NextDouble();
        //    double x2 = rnd.NextDouble();
        //    double z1 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Cos(2 * Math.PI * x2)) * Math.Sqrt(vol) + mean;
        //    double z2 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Sin(2 * Math.PI * x2)) * Math.Sqrt(vol) + mean;
        //    return z2;
        //}

        //static public double StdPolarReject(Random rnd)
        //{
        //    double x1;
        //    double x2;
        //    double w;
        //    double c;
        //    do
        //    {
        //        x1 = rnd.NextDouble() * 2 - 1;
        //        x2 = rnd.NextDouble() * 2 - 1;
        //        w = x1 * x1 + x2 * x2;
        //    }
        //    while (w > 1);
        //    c = Math.Sqrt(-2 * Math.Log(w) / w);
        //    double z1 = c * x1;
        //    double z2 = c * x2;
        //    return z1;
        //}
        static public double[,] StdMatrixBoxMuller(int Trials, int Steps, Boolean anti)
        {
            // anti determines whether or not antithetic is employed
            double[,] output = new double[Trials, Steps];
            Random Rnd = new Random();
            if (anti)
            {
                for (int a = 0; a < Trials / 2; a++)
                {
                    for (int b = 0; b < Steps; b++)
                    {
                        output[a, b] = StdBoxMuller(Rnd);
                        output[a + Trials / 2, b] = -StdBoxMuller(Rnd);
                    }
                    //Parallel.For(0, Steps, b =>
                    //{
                    //    output[a, b] = StdBoxMuller(Rnd);
                    //    output[a + Trials / 2, b] = -StdBoxMuller(Rnd);
                    //});
                }
            }
            else
            {
                for (int a = 0; a < Trials; a++)
                {
                    for (int b = 0; b < Steps; b++)
                    {
                        output[a, b] = StdBoxMuller(Rnd);
                    }
                    //Parallel.For(0, Steps, b =>
                    //{
                    //    output[a, b] = StdBoxMuller(Rnd);
                    //});
                }
            }
            return output;
        }

        //static public double[,] StdMatrixPolarReject(int Trials, int Steps, bool anti)
        //{
        //    double[,] output = new double[Trials, Steps];
        //    Random Rnd = new Random();
        //    if (anti)
        //    {
        //        for (int a = 0; a < Trials / 2; a++)
        //        {
        //            for (int b = 0; b < Steps; b++)
        //            {
        //                output[a, b] = DefaultPolarReject(Rnd);
        //                output[a + Trials / 2, b] = -DefaultPolarReject(Rnd);
        //            }
        //        }
        //    }
        //    else
        //    {
        //        for (int a = 0; a < Trials; a++)
        //        {
        //            for (int b = 0; b < Steps; b++)
        //            {
        //                output[a, b] = DefaultPolarReject(Rnd);
        //            }
        //        }
        //    }
        //    return output;
        //}
        static public double SD(double[] input)  // gives the standard deviation of an array
        {
            double z1 = 0;
            double z2 = 0;
            foreach (double x in input)
            {
                z1 += x;
                z2 += Math.Pow(x, 2);
            }
            double output = (z2 / input.Length) - Math.Pow(z1 / input.Length, 2);
            return output;
        }
        static public double Cov(double[] X, double[] Y)  // gives the covariance of two arraies
        {
            double meanX = X.Sum() / X.Length;
            double meanY = Y.Sum() / Y.Length;
            double z = 0;
            for (int i = 0; i < X.Length; i++)
            {
                z = z + (X[i] - meanX) * (Y[i] - meanY);
            }
            return (z / X.Length);
        }
    }
    class Brownian
    {
        static double GBM(double Drift, double Vol, double Pre, double DeltaT, double RndN)
        {
            double Seq = Pre * Math.Exp((Drift - Vol * Vol / 2) * DeltaT + Vol * Math.Sqrt(DeltaT) * RndN);
            return Seq;
        }
        static public double[] Path(double Drift, double Vol, double S0, double DeltaT, double[] RndN)
        {
            int steps = RndN.Length;
            double[] output = new double[steps+1];
            output[0] = S0;
            for(int i = 0; i < steps; i++)
            {
                output[i + 1] = GBM(Drift, Vol, output[i], DeltaT, RndN[i]);
            }
            return output;
        }
        static public double[] GBMZ(double Drift, double Vol, double S0, double Tenor, double[,] RndN)
        // gives the underlying prices of all trials at the LAST step; prices of a trial follow Geometric Brownian Motion.
        {
            int Trials = RndN.GetLength(0);
            int Steps = RndN.GetLength(1);
            double[] output = new double[Trials];
            double dt = Tenor / Steps;
            for (int a = 0; a < Trials; a++)
            {
                output[a] = S0;
                for (int b = 0; b < Steps; b++)
                {
                    output[a] = GBM(Drift, Vol, output[a], dt, RndN[a, b]);
                }
            }
            return output;
        }
        static public Func<double, Option, double[,], Func<double, double>, double[]> CV = (Drift, O, RndN, f) =>
        {
            // gives the summations of f-based control variate of each trials at the LAST step.
            double Vol = O.Underlying.Volatility;
            double S0 = O.Underlying.Price;
            double K = O.Strike;
            double Tenor = O.Tenor;
            int Trials = RndN.GetLength(0);
            int Steps = RndN.GetLength(1);
            double dt = Tenor / Steps;
            double[] output = new double[Trials];
            for (int j = 0; j < Trials; j++)
            {
                double s = S0;
                double cv = 0;
                //for (int i = 0; i < Steps; i++)
                //{
                //    double tau = Tenor - dt * i;
                //    double BCDelta = O.BSDelta(Drift);
                //    double sSeq = GBM(Drift, Vol, s, dt, RndN[j, i]);
                //    cv = cv + BCDelta * (sSeq - s * Math.Exp(Drift * dt));
                //    s = sSeq;
                //}
                Parallel.For(0, Steps, i =>
                {
                    double tau = Tenor - dt * i;
                    double BCDelta = f(Drift);
                    double sSeq = GBM(Drift, Vol, s, dt, RndN[j, i]);
                    cv = cv + BCDelta * (sSeq - s * Math.Exp(Drift * dt));
                    s = sSeq;
                });
                output[j] = cv;
            }
            return output;
        };
        //static public double[] PathDCV(double Drift, Option O, double[] RndN)
        //{   // gives delta-based control variates of one trials at each step.
        //    double Vol = O.Underlying.Volatility;
        //    double s = O.Underlying.Price;
        //    double K = O.Strike;
        //    double Tenor = O.Tenor;
        //    int Steps = RndN.Length;
        //    double dt = Tenor / Steps;
        //    double[] output = new double[Steps+1];
        //    output[0] = 0;
        //    Parallel.For(0, Steps, i =>
        //        {
        //            double tau = Tenor - dt * i;
        //            output[i+1] = O.BSDelta(Drift) * (GBM(Drift, Vol, s, dt, RndN[i]) - s * Math.Exp(Drift * dt));
        //            s = GBM(Drift, Vol, s, dt, RndN[i]);
        //        });
        //    return output;
        //}
    }
}