﻿namespace _5092_HW4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Outcome = new System.Windows.Forms.Button();
            this.SL = new System.Windows.Forms.Label();
            this.KL = new System.Windows.Forms.Label();
            this.RL = new System.Windows.Forms.Label();
            this.TL = new System.Windows.Forms.Label();
            this.VolL = new System.Windows.Forms.Label();
            this.TrialsL = new System.Windows.Forms.Label();
            this.StepsL = new System.Windows.Forms.Label();
            this.SI = new System.Windows.Forms.TextBox();
            this.KI = new System.Windows.Forms.TextBox();
            this.RI = new System.Windows.Forms.TextBox();
            this.TI = new System.Windows.Forms.TextBox();
            this.VolI = new System.Windows.Forms.TextBox();
            this.TrialsI = new System.Windows.Forms.TextBox();
            this.StepsI = new System.Windows.Forms.TextBox();
            this.PL = new System.Windows.Forms.Label();
            this.DL = new System.Windows.Forms.Label();
            this.GL = new System.Windows.Forms.Label();
            this.VL = new System.Windows.Forms.Label();
            this.ThL = new System.Windows.Forms.Label();
            this.RhL = new System.Windows.Forms.Label();
            this.SEL = new System.Windows.Forms.Label();
            this.PO = new System.Windows.Forms.Label();
            this.DO = new System.Windows.Forms.Label();
            this.GO = new System.Windows.Forms.Label();
            this.VO = new System.Windows.Forms.Label();
            this.ThO = new System.Windows.Forms.Label();
            this.RhO = new System.Windows.Forms.Label();
            this.SEO = new System.Windows.Forms.Label();
            this.Antithetic = new System.Windows.Forms.CheckBox();
            this.Call = new System.Windows.Forms.CheckBox();
            this.CVDelta = new System.Windows.Forms.CheckBox();
            this.CVGamma = new System.Windows.Forms.CheckBox();
            this.sTimerL = new System.Windows.Forms.Label();
            this.cTimerL = new System.Windows.Forms.Label();
            this.sTimerO = new System.Windows.Forms.Label();
            this.cTimerO = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.PBar = new System.Windows.Forms.ProgressBar();
            this.CL = new System.Windows.Forms.Label();
            this.CO = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // Outcome
            // 
            this.Outcome.Font = new System.Drawing.Font("Palatino Linotype", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Outcome.Location = new System.Drawing.Point(946, 717);
            this.Outcome.Name = "Outcome";
            this.Outcome.Size = new System.Drawing.Size(239, 105);
            this.Outcome.TabIndex = 0;
            this.Outcome.Text = "Calculate!";
            this.Outcome.UseVisualStyleBackColor = true;
            this.Outcome.Click += new System.EventHandler(this.Outcome_Click);
            // 
            // SL
            // 
            this.SL.AutoSize = true;
            this.SL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SL.Location = new System.Drawing.Point(30, 30);
            this.SL.Name = "SL";
            this.SL.Size = new System.Drawing.Size(166, 38);
            this.SL.TabIndex = 1;
            this.SL.Text = "Underlying";
            // 
            // KL
            // 
            this.KL.AutoSize = true;
            this.KL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KL.Location = new System.Drawing.Point(32, 100);
            this.KL.Name = "KL";
            this.KL.Size = new System.Drawing.Size(160, 38);
            this.KL.TabIndex = 2;
            this.KL.Text = "Strike Price";
            // 
            // RL
            // 
            this.RL.AutoSize = true;
            this.RL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RL.Location = new System.Drawing.Point(30, 170);
            this.RL.Name = "RL";
            this.RL.Size = new System.Drawing.Size(195, 38);
            this.RL.TabIndex = 3;
            this.RL.Text = "Risk Free Rate";
            // 
            // TL
            // 
            this.TL.AutoSize = true;
            this.TL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TL.Location = new System.Drawing.Point(30, 240);
            this.TL.Name = "TL";
            this.TL.Size = new System.Drawing.Size(92, 38);
            this.TL.TabIndex = 4;
            this.TL.Text = "Tenor";
            // 
            // VolL
            // 
            this.VolL.AutoSize = true;
            this.VolL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VolL.Location = new System.Drawing.Point(30, 310);
            this.VolL.Name = "VolL";
            this.VolL.Size = new System.Drawing.Size(137, 38);
            this.VolL.TabIndex = 5;
            this.VolL.Text = "Volatility";
            // 
            // TrialsL
            // 
            this.TrialsL.AutoSize = true;
            this.TrialsL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrialsL.Location = new System.Drawing.Point(30, 380);
            this.TrialsL.Name = "TrialsL";
            this.TrialsL.Size = new System.Drawing.Size(89, 38);
            this.TrialsL.TabIndex = 6;
            this.TrialsL.Text = "Trials";
            // 
            // StepsL
            // 
            this.StepsL.AutoSize = true;
            this.StepsL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StepsL.Location = new System.Drawing.Point(30, 450);
            this.StepsL.Name = "StepsL";
            this.StepsL.Size = new System.Drawing.Size(84, 38);
            this.StepsL.TabIndex = 7;
            this.StepsL.Text = "Steps";
            // 
            // SI
            // 
            this.SI.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SI.Location = new System.Drawing.Point(250, 30);
            this.SI.Name = "SI";
            this.SI.Size = new System.Drawing.Size(312, 47);
            this.SI.TabIndex = 8;
            this.SI.Text = "50";
            this.SI.TextChanged += new System.EventHandler(this.SI_TextChanged);
            // 
            // KI
            // 
            this.KI.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KI.Location = new System.Drawing.Point(250, 100);
            this.KI.Name = "KI";
            this.KI.Size = new System.Drawing.Size(312, 47);
            this.KI.TabIndex = 9;
            this.KI.Text = "60";
            this.KI.TextChanged += new System.EventHandler(this.KI_TextChanged);
            // 
            // RI
            // 
            this.RI.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RI.Location = new System.Drawing.Point(250, 170);
            this.RI.Name = "RI";
            this.RI.Size = new System.Drawing.Size(312, 47);
            this.RI.TabIndex = 10;
            this.RI.Text = "0.05";
            this.RI.TextChanged += new System.EventHandler(this.RI_TextChanged);
            // 
            // TI
            // 
            this.TI.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TI.Location = new System.Drawing.Point(250, 240);
            this.TI.Name = "TI";
            this.TI.Size = new System.Drawing.Size(312, 47);
            this.TI.TabIndex = 11;
            this.TI.Text = "1";
            this.TI.TextChanged += new System.EventHandler(this.TI_TextChanged);
            // 
            // VolI
            // 
            this.VolI.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VolI.Location = new System.Drawing.Point(250, 310);
            this.VolI.Name = "VolI";
            this.VolI.Size = new System.Drawing.Size(312, 47);
            this.VolI.TabIndex = 12;
            this.VolI.Text = "0.5";
            this.VolI.TextChanged += new System.EventHandler(this.VolI_TextChanged);
            // 
            // TrialsI
            // 
            this.TrialsI.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrialsI.Location = new System.Drawing.Point(250, 380);
            this.TrialsI.Name = "TrialsI";
            this.TrialsI.Size = new System.Drawing.Size(312, 47);
            this.TrialsI.TabIndex = 13;
            this.TrialsI.Text = "10000";
            this.TrialsI.TextChanged += new System.EventHandler(this.TrialsI_TextChanged);
            // 
            // StepsI
            // 
            this.StepsI.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StepsI.Location = new System.Drawing.Point(250, 450);
            this.StepsI.Name = "StepsI";
            this.StepsI.Size = new System.Drawing.Size(312, 47);
            this.StepsI.TabIndex = 14;
            this.StepsI.Text = "128";
            this.StepsI.TextChanged += new System.EventHandler(this.StepsI_TextChanged);
            // 
            // PL
            // 
            this.PL.AutoSize = true;
            this.PL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PL.Location = new System.Drawing.Point(639, 30);
            this.PL.Name = "PL";
            this.PL.Size = new System.Drawing.Size(80, 38);
            this.PL.TabIndex = 15;
            this.PL.Text = "Price";
            // 
            // DL
            // 
            this.DL.AutoSize = true;
            this.DL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DL.Location = new System.Drawing.Point(639, 100);
            this.DL.Name = "DL";
            this.DL.Size = new System.Drawing.Size(86, 38);
            this.DL.TabIndex = 16;
            this.DL.Text = "Delta";
            // 
            // GL
            // 
            this.GL.AutoSize = true;
            this.GL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GL.Location = new System.Drawing.Point(639, 170);
            this.GL.Name = "GL";
            this.GL.Size = new System.Drawing.Size(121, 38);
            this.GL.TabIndex = 17;
            this.GL.Text = "Gamma";
            // 
            // VL
            // 
            this.VL.AutoSize = true;
            this.VL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VL.Location = new System.Drawing.Point(639, 240);
            this.VL.Name = "VL";
            this.VL.Size = new System.Drawing.Size(81, 38);
            this.VL.TabIndex = 18;
            this.VL.Text = "Vega";
            // 
            // ThL
            // 
            this.ThL.AutoSize = true;
            this.ThL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThL.Location = new System.Drawing.Point(639, 310);
            this.ThL.Name = "ThL";
            this.ThL.Size = new System.Drawing.Size(92, 38);
            this.ThL.TabIndex = 19;
            this.ThL.Text = "Theta";
            // 
            // RhL
            // 
            this.RhL.AutoSize = true;
            this.RhL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RhL.Location = new System.Drawing.Point(639, 380);
            this.RhL.Name = "RhL";
            this.RhL.Size = new System.Drawing.Size(69, 38);
            this.RhL.TabIndex = 20;
            this.RhL.Text = "Rho";
            // 
            // SEL
            // 
            this.SEL.AutoSize = true;
            this.SEL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SEL.Location = new System.Drawing.Point(639, 450);
            this.SEL.Name = "SEL";
            this.SEL.Size = new System.Drawing.Size(132, 38);
            this.SEL.TabIndex = 21;
            this.SEL.Text = "Std Error";
            // 
            // PO
            // 
            this.PO.AutoSize = true;
            this.PO.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PO.Location = new System.Drawing.Point(900, 33);
            this.PO.Name = "PO";
            this.PO.Size = new System.Drawing.Size(0, 38);
            this.PO.TabIndex = 22;
            // 
            // DO
            // 
            this.DO.AutoSize = true;
            this.DO.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DO.Location = new System.Drawing.Point(900, 100);
            this.DO.Name = "DO";
            this.DO.Size = new System.Drawing.Size(0, 38);
            this.DO.TabIndex = 23;
            // 
            // GO
            // 
            this.GO.AutoSize = true;
            this.GO.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GO.Location = new System.Drawing.Point(900, 170);
            this.GO.Name = "GO";
            this.GO.Size = new System.Drawing.Size(0, 38);
            this.GO.TabIndex = 24;
            // 
            // VO
            // 
            this.VO.AutoSize = true;
            this.VO.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VO.Location = new System.Drawing.Point(900, 240);
            this.VO.Name = "VO";
            this.VO.Size = new System.Drawing.Size(0, 38);
            this.VO.TabIndex = 25;
            // 
            // ThO
            // 
            this.ThO.AutoSize = true;
            this.ThO.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThO.Location = new System.Drawing.Point(900, 310);
            this.ThO.Name = "ThO";
            this.ThO.Size = new System.Drawing.Size(0, 38);
            this.ThO.TabIndex = 26;
            // 
            // RhO
            // 
            this.RhO.AutoSize = true;
            this.RhO.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RhO.Location = new System.Drawing.Point(900, 380);
            this.RhO.Name = "RhO";
            this.RhO.Size = new System.Drawing.Size(0, 38);
            this.RhO.TabIndex = 27;
            // 
            // SEO
            // 
            this.SEO.AutoSize = true;
            this.SEO.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SEO.Location = new System.Drawing.Point(900, 450);
            this.SEO.Name = "SEO";
            this.SEO.Size = new System.Drawing.Size(0, 38);
            this.SEO.TabIndex = 28;
            // 
            // Antithetic
            // 
            this.Antithetic.AutoSize = true;
            this.Antithetic.Checked = true;
            this.Antithetic.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Antithetic.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Antithetic.Location = new System.Drawing.Point(250, 520);
            this.Antithetic.Name = "Antithetic";
            this.Antithetic.Size = new System.Drawing.Size(181, 42);
            this.Antithetic.TabIndex = 31;
            this.Antithetic.Text = "Antithetic";
            this.Antithetic.UseVisualStyleBackColor = true;
            // 
            // Call
            // 
            this.Call.AutoSize = true;
            this.Call.Checked = true;
            this.Call.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Call.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Call.Location = new System.Drawing.Point(37, 520);
            this.Call.Name = "Call";
            this.Call.Size = new System.Drawing.Size(100, 42);
            this.Call.TabIndex = 32;
            this.Call.Text = "Call";
            this.Call.UseVisualStyleBackColor = true;
            // 
            // CVDelta
            // 
            this.CVDelta.AutoSize = true;
            this.CVDelta.Checked = true;
            this.CVDelta.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CVDelta.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CVDelta.Location = new System.Drawing.Point(37, 590);
            this.CVDelta.Name = "CVDelta";
            this.CVDelta.Size = new System.Drawing.Size(406, 42);
            this.CVDelta.TabIndex = 33;
            this.CVDelta.Text = "Delta-based Control Variate";
            this.CVDelta.UseVisualStyleBackColor = true;
            // 
            // CVGamma
            // 
            this.CVGamma.AutoSize = true;
            this.CVGamma.Checked = true;
            this.CVGamma.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CVGamma.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CVGamma.Location = new System.Drawing.Point(37, 660);
            this.CVGamma.Name = "CVGamma";
            this.CVGamma.Size = new System.Drawing.Size(441, 42);
            this.CVGamma.TabIndex = 34;
            this.CVGamma.Text = "Gamma-based Control Variate";
            this.CVGamma.UseVisualStyleBackColor = true;
            // 
            // sTimerL
            // 
            this.sTimerL.AutoSize = true;
            this.sTimerL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sTimerL.Location = new System.Drawing.Point(639, 520);
            this.sTimerL.Name = "sTimerL";
            this.sTimerL.Size = new System.Drawing.Size(232, 38);
            this.sTimerL.TabIndex = 35;
            this.sTimerL.Text = "Simulation Time";
            // 
            // cTimerL
            // 
            this.cTimerL.AutoSize = true;
            this.cTimerL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cTimerL.Location = new System.Drawing.Point(639, 590);
            this.cTimerL.Name = "cTimerL";
            this.cTimerL.Size = new System.Drawing.Size(239, 38);
            this.cTimerL.TabIndex = 36;
            this.cTimerL.Text = "Calculation Time";
            // 
            // sTimerO
            // 
            this.sTimerO.AutoSize = true;
            this.sTimerO.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sTimerO.Location = new System.Drawing.Point(900, 520);
            this.sTimerO.Name = "sTimerO";
            this.sTimerO.Size = new System.Drawing.Size(0, 38);
            this.sTimerO.TabIndex = 37;
            // 
            // cTimerO
            // 
            this.cTimerO.AutoSize = true;
            this.cTimerO.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cTimerO.Location = new System.Drawing.Point(900, 590);
            this.cTimerO.Name = "cTimerO";
            this.cTimerO.Size = new System.Drawing.Size(0, 38);
            this.cTimerO.TabIndex = 38;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // PBar
            // 
            this.PBar.Location = new System.Drawing.Point(37, 717);
            this.PBar.Maximum = 1280000;
            this.PBar.Name = "PBar";
            this.PBar.Size = new System.Drawing.Size(841, 105);
            this.PBar.TabIndex = 39;
            // 
            // CL
            // 
            this.CL.AutoSize = true;
            this.CL.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CL.Location = new System.Drawing.Point(639, 660);
            this.CL.Name = "CL";
            this.CL.Size = new System.Drawing.Size(78, 38);
            this.CL.TabIndex = 40;
            this.CL.Text = "Core";
            // 
            // CO
            // 
            this.CO.AutoSize = true;
            this.CO.Font = new System.Drawing.Font("Palatino Linotype", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CO.Location = new System.Drawing.Point(900, 660);
            this.CO.Name = "CO";
            this.CO.Size = new System.Drawing.Size(0, 38);
            this.CO.TabIndex = 41;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1216, 843);
            this.Controls.Add(this.CO);
            this.Controls.Add(this.CL);
            this.Controls.Add(this.PBar);
            this.Controls.Add(this.cTimerO);
            this.Controls.Add(this.sTimerO);
            this.Controls.Add(this.cTimerL);
            this.Controls.Add(this.sTimerL);
            this.Controls.Add(this.CVGamma);
            this.Controls.Add(this.CVDelta);
            this.Controls.Add(this.Call);
            this.Controls.Add(this.Antithetic);
            this.Controls.Add(this.SEO);
            this.Controls.Add(this.RhO);
            this.Controls.Add(this.ThO);
            this.Controls.Add(this.VO);
            this.Controls.Add(this.GO);
            this.Controls.Add(this.DO);
            this.Controls.Add(this.PO);
            this.Controls.Add(this.SEL);
            this.Controls.Add(this.RhL);
            this.Controls.Add(this.ThL);
            this.Controls.Add(this.VL);
            this.Controls.Add(this.GL);
            this.Controls.Add(this.DL);
            this.Controls.Add(this.PL);
            this.Controls.Add(this.StepsI);
            this.Controls.Add(this.TrialsI);
            this.Controls.Add(this.VolI);
            this.Controls.Add(this.TI);
            this.Controls.Add(this.RI);
            this.Controls.Add(this.KI);
            this.Controls.Add(this.SI);
            this.Controls.Add(this.StepsL);
            this.Controls.Add(this.TrialsL);
            this.Controls.Add(this.VolL);
            this.Controls.Add(this.TL);
            this.Controls.Add(this.RL);
            this.Controls.Add(this.KL);
            this.Controls.Add(this.SL);
            this.Controls.Add(this.Outcome);
            this.Name = "Form1";
            this.Text = "MC Simulation Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Outcome;
        private System.Windows.Forms.Label SL;
        private System.Windows.Forms.Label KL;
        private System.Windows.Forms.Label RL;
        private System.Windows.Forms.Label TL;
        private System.Windows.Forms.Label VolL;
        private System.Windows.Forms.Label TrialsL;
        private System.Windows.Forms.Label StepsL;
        private System.Windows.Forms.TextBox SI;
        private System.Windows.Forms.TextBox KI;
        private System.Windows.Forms.TextBox RI;
        private System.Windows.Forms.TextBox TI;
        private System.Windows.Forms.TextBox VolI;
        private System.Windows.Forms.TextBox TrialsI;
        private System.Windows.Forms.TextBox StepsI;
        private System.Windows.Forms.Label PL;
        private System.Windows.Forms.Label DL;
        private System.Windows.Forms.Label GL;
        private System.Windows.Forms.Label VL;
        private System.Windows.Forms.Label ThL;
        private System.Windows.Forms.Label RhL;
        private System.Windows.Forms.Label SEL;
        private System.Windows.Forms.Label PO;
        private System.Windows.Forms.Label DO;
        private System.Windows.Forms.Label GO;
        private System.Windows.Forms.Label VO;
        private System.Windows.Forms.Label ThO;
        private System.Windows.Forms.Label RhO;
        private System.Windows.Forms.Label SEO;
        private System.Windows.Forms.CheckBox Antithetic;
        private System.Windows.Forms.CheckBox Call;
        private System.Windows.Forms.CheckBox CVDelta;
        private System.Windows.Forms.CheckBox CVGamma;
        private System.Windows.Forms.Label sTimerL;
        private System.Windows.Forms.Label cTimerL;
        private System.Windows.Forms.Label sTimerO;
        private System.Windows.Forms.Label cTimerO;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ProgressBar PBar;
        private System.Windows.Forms.Label CL;
        private System.Windows.Forms.Label CO;
    }
}