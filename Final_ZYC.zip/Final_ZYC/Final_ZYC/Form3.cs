﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_ZYC
{
    public partial class HistlPricesForm : Form
    {
        bool AA { get; set; }
        bool BB { get; set; }
        bool CC { get; set; }
        bool DD { get; set; }
        Model1Container db { get; set; }

        public HistlPricesForm()
        {
            InitializeComponent();

            ErrorProvider.SetIconAlignment(EquityIDBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(EquityIDBox, 3);
            ErrorProvider.SetIconAlignment(PriceBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(PriceBox, 3);
            ErrorProvider.SetIconAlignment(IDBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(IDBox, 3);

            db = new Model1Container();
            AA = false;
            BB = false;
            CC = false;
            DD = false;

            HistPButton.Enabled = AA && BB && CC;
            DeleteButtton.Enabled = false;
        }

        private void IDBox_TextChanged(object sender, EventArgs e)
        {

            if (!double.TryParse(IDBox.Text, out _) || Convert.ToInt32(IDBox.Text) < 0)
            {
                ErrorProvider.SetError(IDBox, "Please enter a positive integer!");
                DD = false;
                HistPButton.Enabled = AA && BB && CC && DD;
            }
            else
            {
                ErrorProvider.SetError(IDBox, string.Empty);
                DD = true;
                HistPButton.Enabled = AA && BB && CC && DD;
                DeleteButtton.Enabled = Convert.ToInt32(IDBox.Text) != 0;
            }
        }

        private void EquityIDBox_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(EquityIDBox.Text, out _) || Convert.ToInt32(EquityIDBox.Text) < 0)
            {
                ErrorProvider.SetError(EquityIDBox, "Please enter a positive integer!");
                AA = false;
                HistPButton.Enabled = AA && BB && CC && DD;
            }
            else
            {
                ErrorProvider.SetError(EquityIDBox, string.Empty);
                AA = true;
                HistPButton.Enabled = AA && BB && CC && DD;
            }
        }

        private void PriceBox_TextChanged(object sender, EventArgs e)
        {

            if (!double.TryParse(PriceBox.Text, out _) || Convert.ToDouble(PriceBox.Text) < 0)
            {
                ErrorProvider.SetError(PriceBox, "Please enter a positive number!");
                BB = false;
                HistPButton.Enabled = AA && BB && CC && DD;
            }
            else
            {
                ErrorProvider.SetError(PriceBox, string.Empty);
                BB = true;
                HistPButton.Enabled = AA && BB && CC && DD;
            }
        }

        private void DateTimePick_ValueChanged(object sender, EventArgs e)
        {

            CC = true;
            HistPButton.Enabled = AA && BB && CC && DD;
        }

        private void DeleteButtton_Click(object sender, EventArgs e)
        {

        }

        private void HistPButton_Click(object sender, EventArgs e)
        {
            HistPButton.Enabled = false;

            if(IDBox.Text == "0")
            {
                db.HistPrices.Add(new HistPrice()
                {
                    Price = Convert.ToDouble(PriceBox.Text),
                    Date = DateTimePick.Value,
                    EquityId = Convert.ToInt32(EquityIDBox.Text)
                });
            }
            else
            {
                int yId = Convert.ToInt32(IDBox.Text);
                db.HistPrices.FirstOrDefault(x => x.Id == yId).Price = Convert.ToDouble(PriceBox.Text);
                db.HistPrices.FirstOrDefault(x => x.Id == yId).Date = DateTimePick.Value;
                db.HistPrices.FirstOrDefault(x => x.Id == yId).EquityId = Convert.ToInt32(EquityIDBox.Text);
            }

            db.SaveChanges();
            HistPButton.Enabled = true;
        }

    }
}
