
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 05/12/2020 15:31:10
-- Generated from EDMX file: C:\Users\zhany\Documents\FM 5091\C#\Final_ZYC\Final_ZYC\Model1.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [FRamsey];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Trades'
CREATE TABLE [dbo].[Trades] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Price] float  NOT NULL,
    [Quantity] int  NOT NULL,
    [EquityId] int  NULL,
    [AsianOptionId] int  NULL,
    [BarrierOptionId] int  NULL,
    [DigitalOptionId] int  NULL,
    [EuropeanOptionId] int  NULL,
    [RangeOptionId] int  NULL,
    [LookbackOptionId] int  NULL
);
GO

-- Creating table 'HistPrices'
CREATE TABLE [dbo].[HistPrices] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Price] float  NOT NULL,
    [Date] datetime  NOT NULL,
    [EquityId] int  NOT NULL
);
GO

-- Creating table 'Equities'
CREATE TABLE [dbo].[Equities] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Symbol] nvarchar(max)  NOT NULL,
    [Volatility] float  NOT NULL
);
GO

-- Creating table 'AsianOptions'
CREATE TABLE [dbo].[AsianOptions] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Symbol] nvarchar(max)  NOT NULL,
    [Strike] float  NOT NULL,
    [IsCall] bit  NOT NULL,
    [Tenor] float  NOT NULL,
    [EquityId] int  NOT NULL
);
GO

-- Creating table 'EuropeanOptions'
CREATE TABLE [dbo].[EuropeanOptions] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Symbol] nvarchar(max)  NOT NULL,
    [Strike] float  NOT NULL,
    [IsCall] bit  NOT NULL,
    [Tenor] float  NOT NULL,
    [EquityId] int  NOT NULL
);
GO

-- Creating table 'DigitalOptions'
CREATE TABLE [dbo].[DigitalOptions] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Symbol] nvarchar(max)  NOT NULL,
    [Strike] float  NOT NULL,
    [IsCall] bit  NOT NULL,
    [Tenor] float  NOT NULL,
    [Rebate] float  NOT NULL,
    [EquityId] int  NOT NULL
);
GO

-- Creating table 'BarrierOptions'
CREATE TABLE [dbo].[BarrierOptions] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Symbol] nvarchar(max)  NOT NULL,
    [Strike] float  NOT NULL,
    [IsCall] bit  NOT NULL,
    [Tenor] float  NOT NULL,
    [KnockOut] bit  NOT NULL,
    [Barrier] float  NOT NULL,
    [EquityId] int  NOT NULL
);
GO

-- Creating table 'LookbackOptions'
CREATE TABLE [dbo].[LookbackOptions] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Symbol] nvarchar(max)  NOT NULL,
    [Strike] float  NOT NULL,
    [IsCall] bit  NOT NULL,
    [Tenor] float  NOT NULL,
    [EquityId] int  NOT NULL
);
GO

-- Creating table 'RangeOptions'
CREATE TABLE [dbo].[RangeOptions] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Symbol] nvarchar(max)  NOT NULL,
    [Strike] float  NOT NULL,
    [IsCall] bit  NOT NULL,
    [Tenor] float  NOT NULL,
    [EquityId] int  NOT NULL
);
GO

-- Creating table 'Bonds'
CREATE TABLE [dbo].[Bonds] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [InterestRate] float  NOT NULL,
    [Tenor] float  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'Trades'
ALTER TABLE [dbo].[Trades]
ADD CONSTRAINT [PK_Trades]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'HistPrices'
ALTER TABLE [dbo].[HistPrices]
ADD CONSTRAINT [PK_HistPrices]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Equities'
ALTER TABLE [dbo].[Equities]
ADD CONSTRAINT [PK_Equities]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'AsianOptions'
ALTER TABLE [dbo].[AsianOptions]
ADD CONSTRAINT [PK_AsianOptions]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'EuropeanOptions'
ALTER TABLE [dbo].[EuropeanOptions]
ADD CONSTRAINT [PK_EuropeanOptions]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'DigitalOptions'
ALTER TABLE [dbo].[DigitalOptions]
ADD CONSTRAINT [PK_DigitalOptions]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'BarrierOptions'
ALTER TABLE [dbo].[BarrierOptions]
ADD CONSTRAINT [PK_BarrierOptions]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'LookbackOptions'
ALTER TABLE [dbo].[LookbackOptions]
ADD CONSTRAINT [PK_LookbackOptions]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'RangeOptions'
ALTER TABLE [dbo].[RangeOptions]
ADD CONSTRAINT [PK_RangeOptions]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Bonds'
ALTER TABLE [dbo].[Bonds]
ADD CONSTRAINT [PK_Bonds]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [EquityId] in table 'Trades'
ALTER TABLE [dbo].[Trades]
ADD CONSTRAINT [FK_EquityTrade]
    FOREIGN KEY ([EquityId])
    REFERENCES [dbo].[Equities]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_EquityTrade'
CREATE INDEX [IX_FK_EquityTrade]
ON [dbo].[Trades]
    ([EquityId]);
GO

-- Creating foreign key on [AsianOptionId] in table 'Trades'
ALTER TABLE [dbo].[Trades]
ADD CONSTRAINT [FK_AsianOptionTrade]
    FOREIGN KEY ([AsianOptionId])
    REFERENCES [dbo].[AsianOptions]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AsianOptionTrade'
CREATE INDEX [IX_FK_AsianOptionTrade]
ON [dbo].[Trades]
    ([AsianOptionId]);
GO

-- Creating foreign key on [BarrierOptionId] in table 'Trades'
ALTER TABLE [dbo].[Trades]
ADD CONSTRAINT [FK_BarrierOptionTrade]
    FOREIGN KEY ([BarrierOptionId])
    REFERENCES [dbo].[BarrierOptions]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_BarrierOptionTrade'
CREATE INDEX [IX_FK_BarrierOptionTrade]
ON [dbo].[Trades]
    ([BarrierOptionId]);
GO

-- Creating foreign key on [DigitalOptionId] in table 'Trades'
ALTER TABLE [dbo].[Trades]
ADD CONSTRAINT [FK_DigitalOptionTrade]
    FOREIGN KEY ([DigitalOptionId])
    REFERENCES [dbo].[DigitalOptions]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DigitalOptionTrade'
CREATE INDEX [IX_FK_DigitalOptionTrade]
ON [dbo].[Trades]
    ([DigitalOptionId]);
GO

-- Creating foreign key on [EuropeanOptionId] in table 'Trades'
ALTER TABLE [dbo].[Trades]
ADD CONSTRAINT [FK_EuropeanOptionTrade]
    FOREIGN KEY ([EuropeanOptionId])
    REFERENCES [dbo].[EuropeanOptions]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_EuropeanOptionTrade'
CREATE INDEX [IX_FK_EuropeanOptionTrade]
ON [dbo].[Trades]
    ([EuropeanOptionId]);
GO

-- Creating foreign key on [RangeOptionId] in table 'Trades'
ALTER TABLE [dbo].[Trades]
ADD CONSTRAINT [FK_RangeOptionTrade]
    FOREIGN KEY ([RangeOptionId])
    REFERENCES [dbo].[RangeOptions]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_RangeOptionTrade'
CREATE INDEX [IX_FK_RangeOptionTrade]
ON [dbo].[Trades]
    ([RangeOptionId]);
GO

-- Creating foreign key on [LookbackOptionId] in table 'Trades'
ALTER TABLE [dbo].[Trades]
ADD CONSTRAINT [FK_LookbackOptionTrade]
    FOREIGN KEY ([LookbackOptionId])
    REFERENCES [dbo].[LookbackOptions]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LookbackOptionTrade'
CREATE INDEX [IX_FK_LookbackOptionTrade]
ON [dbo].[Trades]
    ([LookbackOptionId]);
GO

-- Creating foreign key on [EquityId] in table 'HistPrices'
ALTER TABLE [dbo].[HistPrices]
ADD CONSTRAINT [FK_EquityHistPrice]
    FOREIGN KEY ([EquityId])
    REFERENCES [dbo].[Equities]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_EquityHistPrice'
CREATE INDEX [IX_FK_EquityHistPrice]
ON [dbo].[HistPrices]
    ([EquityId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------