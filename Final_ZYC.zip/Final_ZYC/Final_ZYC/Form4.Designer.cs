﻿namespace Final_ZYC
{
    partial class TradesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PriceL = new System.Windows.Forms.Label();
            this.QuantityL = new System.Windows.Forms.Label();
            this.QuantityBox = new System.Windows.Forms.TextBox();
            this.PriceBox = new System.Windows.Forms.TextBox();
            this.TradesButton = new System.Windows.Forms.Button();
            this.ErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.TradeIDL = new System.Windows.Forms.Label();
            this.RORadio = new System.Windows.Forms.RadioButton();
            this.EORadio = new System.Windows.Forms.RadioButton();
            this.AORadio = new System.Windows.Forms.RadioButton();
            this.DORadio = new System.Windows.Forms.RadioButton();
            this.BORadio = new System.Windows.Forms.RadioButton();
            this.LORadio = new System.Windows.Forms.RadioButton();
            this.EquityRadio = new System.Windows.Forms.RadioButton();
            this.InstruIDLabel = new System.Windows.Forms.Label();
            this.InstruIDBox = new System.Windows.Forms.TextBox();
            this.TradeIDBox = new System.Windows.Forms.TextBox();
            this.DeleteButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // PriceL
            // 
            this.PriceL.AutoSize = true;
            this.PriceL.Location = new System.Drawing.Point(46, 237);
            this.PriceL.Name = "PriceL";
            this.PriceL.Size = new System.Drawing.Size(48, 23);
            this.PriceL.TabIndex = 29;
            this.PriceL.Text = "Price";
            // 
            // QuantityL
            // 
            this.QuantityL.AutoSize = true;
            this.ErrorProvider.SetIconAlignment(this.QuantityL, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.QuantityL.Location = new System.Drawing.Point(46, 137);
            this.QuantityL.Name = "QuantityL";
            this.QuantityL.Size = new System.Drawing.Size(78, 23);
            this.QuantityL.TabIndex = 28;
            this.QuantityL.Text = "Quantity";
            // 
            // QuantityBox
            // 
            this.QuantityBox.Location = new System.Drawing.Point(46, 187);
            this.QuantityBox.Name = "QuantityBox";
            this.QuantityBox.Size = new System.Drawing.Size(172, 30);
            this.QuantityBox.TabIndex = 31;
            this.QuantityBox.TextChanged += new System.EventHandler(this.QuantityBox_TextChanged);
            // 
            // PriceBox
            // 
            this.PriceBox.Location = new System.Drawing.Point(46, 287);
            this.PriceBox.Name = "PriceBox";
            this.PriceBox.Size = new System.Drawing.Size(172, 30);
            this.PriceBox.TabIndex = 30;
            this.PriceBox.TextChanged += new System.EventHandler(this.PriceBox_TextChanged);
            // 
            // TradesButton
            // 
            this.TradesButton.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TradesButton.Location = new System.Drawing.Point(50, 436);
            this.TradesButton.Name = "TradesButton";
            this.TradesButton.Size = new System.Drawing.Size(202, 68);
            this.TradesButton.TabIndex = 32;
            this.TradesButton.Text = "Exchange!";
            this.TradesButton.UseVisualStyleBackColor = true;
            this.TradesButton.Click += new System.EventHandler(this.TradesButton_Click);
            // 
            // ErrorProvider
            // 
            this.ErrorProvider.ContainerControl = this;
            // 
            // TradeIDL
            // 
            this.TradeIDL.AutoSize = true;
            this.ErrorProvider.SetIconAlignment(this.TradeIDL, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.TradeIDL.Location = new System.Drawing.Point(46, 39);
            this.TradeIDL.Name = "TradeIDL";
            this.TradeIDL.Size = new System.Drawing.Size(306, 23);
            this.TradeIDL.TabIndex = 43;
            this.TradeIDL.Text = "Trade ID (type 0 if you\'re instantiating)";
            // 
            // RORadio
            // 
            this.RORadio.AutoSize = true;
            this.RORadio.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.RORadio.Location = new System.Drawing.Point(291, 387);
            this.RORadio.Name = "RORadio";
            this.RORadio.Size = new System.Drawing.Size(135, 27);
            this.RORadio.TabIndex = 39;
            this.RORadio.TabStop = true;
            this.RORadio.Text = "Range Option";
            this.RORadio.UseVisualStyleBackColor = true;
            this.RORadio.CheckedChanged += new System.EventHandler(this.RORadio_CheckedChanged);
            // 
            // EORadio
            // 
            this.EORadio.AutoSize = true;
            this.EORadio.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.EORadio.Location = new System.Drawing.Point(291, 137);
            this.EORadio.Name = "EORadio";
            this.EORadio.Size = new System.Drawing.Size(161, 27);
            this.EORadio.TabIndex = 38;
            this.EORadio.TabStop = true;
            this.EORadio.Text = "European Option";
            this.EORadio.UseVisualStyleBackColor = true;
            this.EORadio.CheckedChanged += new System.EventHandler(this.EORadio_CheckedChanged);
            // 
            // AORadio
            // 
            this.AORadio.AutoSize = true;
            this.AORadio.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.AORadio.Location = new System.Drawing.Point(291, 187);
            this.AORadio.Name = "AORadio";
            this.AORadio.Size = new System.Drawing.Size(133, 27);
            this.AORadio.TabIndex = 37;
            this.AORadio.TabStop = true;
            this.AORadio.Text = "Asian Option";
            this.AORadio.UseVisualStyleBackColor = true;
            this.AORadio.CheckedChanged += new System.EventHandler(this.AORadio_CheckedChanged);
            // 
            // DORadio
            // 
            this.DORadio.AutoSize = true;
            this.DORadio.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.DORadio.Location = new System.Drawing.Point(291, 237);
            this.DORadio.Name = "DORadio";
            this.DORadio.Size = new System.Drawing.Size(140, 27);
            this.DORadio.TabIndex = 36;
            this.DORadio.TabStop = true;
            this.DORadio.Text = "Digital Option";
            this.DORadio.UseVisualStyleBackColor = true;
            this.DORadio.CheckedChanged += new System.EventHandler(this.DORadio_CheckedChanged);
            // 
            // BORadio
            // 
            this.BORadio.AutoSize = true;
            this.BORadio.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.BORadio.Location = new System.Drawing.Point(291, 287);
            this.BORadio.Name = "BORadio";
            this.BORadio.Size = new System.Drawing.Size(141, 27);
            this.BORadio.TabIndex = 35;
            this.BORadio.TabStop = true;
            this.BORadio.Text = "Barrier Option";
            this.BORadio.UseVisualStyleBackColor = true;
            this.BORadio.CheckedChanged += new System.EventHandler(this.BORadio_CheckedChanged);
            // 
            // LORadio
            // 
            this.LORadio.AutoSize = true;
            this.LORadio.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.LORadio.Location = new System.Drawing.Point(291, 337);
            this.LORadio.Name = "LORadio";
            this.LORadio.Size = new System.Drawing.Size(161, 27);
            this.LORadio.TabIndex = 34;
            this.LORadio.TabStop = true;
            this.LORadio.Text = "Lookback Option";
            this.LORadio.UseVisualStyleBackColor = true;
            this.LORadio.CheckedChanged += new System.EventHandler(this.LORadio_CheckedChanged);
            // 
            // EquityRadio
            // 
            this.EquityRadio.AutoSize = true;
            this.EquityRadio.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.EquityRadio.Location = new System.Drawing.Point(291, 87);
            this.EquityRadio.Name = "EquityRadio";
            this.EquityRadio.Size = new System.Drawing.Size(81, 27);
            this.EquityRadio.TabIndex = 33;
            this.EquityRadio.TabStop = true;
            this.EquityRadio.Text = "Equity";
            this.EquityRadio.UseVisualStyleBackColor = true;
            this.EquityRadio.CheckedChanged += new System.EventHandler(this.EquityRadio_CheckedChanged);
            // 
            // InstruIDLabel
            // 
            this.InstruIDLabel.AutoSize = true;
            this.InstruIDLabel.Location = new System.Drawing.Point(46, 337);
            this.InstruIDLabel.Name = "InstruIDLabel";
            this.InstruIDLabel.Size = new System.Drawing.Size(117, 23);
            this.InstruIDLabel.TabIndex = 40;
            this.InstruIDLabel.Text = "Instrument ID";
            // 
            // InstruIDBox
            // 
            this.InstruIDBox.Location = new System.Drawing.Point(46, 387);
            this.InstruIDBox.Name = "InstruIDBox";
            this.InstruIDBox.Size = new System.Drawing.Size(172, 30);
            this.InstruIDBox.TabIndex = 41;
            this.InstruIDBox.TextChanged += new System.EventHandler(this.IDBox_TextChanged);
            // 
            // TradeIDBox
            // 
            this.TradeIDBox.Location = new System.Drawing.Point(46, 87);
            this.TradeIDBox.Name = "TradeIDBox";
            this.TradeIDBox.Size = new System.Drawing.Size(172, 30);
            this.TradeIDBox.TabIndex = 42;
            this.TradeIDBox.TextChanged += new System.EventHandler(this.TradeIDBox_TextChanged);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteButton.Location = new System.Drawing.Point(291, 436);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(161, 68);
            this.DeleteButton.TabIndex = 44;
            this.DeleteButton.Text = "Delete!";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // TradesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 539);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.TradeIDL);
            this.Controls.Add(this.TradeIDBox);
            this.Controls.Add(this.InstruIDBox);
            this.Controls.Add(this.InstruIDLabel);
            this.Controls.Add(this.RORadio);
            this.Controls.Add(this.EORadio);
            this.Controls.Add(this.AORadio);
            this.Controls.Add(this.DORadio);
            this.Controls.Add(this.BORadio);
            this.Controls.Add(this.LORadio);
            this.Controls.Add(this.EquityRadio);
            this.Controls.Add(this.TradesButton);
            this.Controls.Add(this.QuantityBox);
            this.Controls.Add(this.PriceBox);
            this.Controls.Add(this.PriceL);
            this.Controls.Add(this.QuantityL);
            this.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "TradesForm";
            this.Text = "Trades";
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label PriceL;
        private System.Windows.Forms.Label QuantityL;
        private System.Windows.Forms.TextBox QuantityBox;
        private System.Windows.Forms.TextBox PriceBox;
        private System.Windows.Forms.Button TradesButton;
        private System.Windows.Forms.ErrorProvider ErrorProvider;
        private System.Windows.Forms.RadioButton RORadio;
        private System.Windows.Forms.RadioButton EORadio;
        private System.Windows.Forms.RadioButton AORadio;
        private System.Windows.Forms.RadioButton DORadio;
        private System.Windows.Forms.RadioButton BORadio;
        private System.Windows.Forms.RadioButton LORadio;
        private System.Windows.Forms.RadioButton EquityRadio;
        private System.Windows.Forms.Label InstruIDLabel;
        private System.Windows.Forms.TextBox InstruIDBox;
        private System.Windows.Forms.TextBox TradeIDBox;
        private System.Windows.Forms.Label TradeIDL;
        private System.Windows.Forms.Button DeleteButton;
    }
}