﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SyntacticCinnamon;

namespace Final_ZYC
{
    static public class Population
    {
        public static void GenTrades(Model1Container db)
        {

            db.Trades.Add(new Trade()
            {
                Quantity = 30,
                Price = 7,
                AsianOptionId = 1
            });
            db.Trades.Add(new Trade()
            {
                Quantity = 200,
                Price = 20,
                EuropeanOptionId = 3
            });
            db.Trades.Add(new Trade()
            {
                Quantity = 120,
                Price = 20,
                AsianOptionId = 2
            });
            db.Trades.Add(new Trade()
            {
                Quantity = 200,
                Price = 7,
                BarrierOptionId = 1
            });
            db.Trades.Add(new Trade()
            {
                Quantity = -20,
                Price = 8,
                BarrierOptionId = 1
            });


            db.SaveChanges();
        }

        public static void GenHistPrices(Model1Container db)
        {

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    db.HistPrices.Add(new HistPrice()
                    {
                        Date = new DateTime(2016, 3, 9 + j),
                        Price = j + 30,
                        EquityId = i + 1
                    });
                }
            }

            db.SaveChanges();
        }

        public static void GenBarrier(Model1Container db)
        {
            string[] st = { "awss", "uwehj", "BBdf" };

            for (int i = 1; i < 3; i++)
            {
                db.BarrierOptions.Add(new BarrierOption()
                {
                    Symbol = String.Join(db.Equities.FirstOrDefault(x => x.Id == i).Symbol, st[i]),
                    Strike = 50 + i * 10,
                    Tenor = i,
                    IsCall = true,
                    EquityId = i
                });
            }

            db.SaveChanges();
        }

        public static void GenEquity(Model1Container db)
        {
            db.Equities.Add(new Equity()
            {
                Volatility = 0.5,
                Symbol = "PRI"
            });

            db.Equities.Add(new Equity()
            {
                Volatility = 0.3,
                Symbol = "NCEPS"
            });

            db.Equities.Add(new Equity()
            {
                Volatility = 0.6,
                Symbol = "QUAT"
            });
            db.SaveChanges();
        }

        public static void GenAsian(Model1Container db)
        {
            string[] st = { "aws", "wehj", "df" };

            db.AsianOptions.Add(new AsianOption()
            {
                Symbol = String.Join(db.Equities.FirstOrDefault(x => x.Id == 1).Symbol, st[0]),
                Strike = 50,
                Tenor = 1,
                IsCall = true,
                EquityId = 1
            });

            db.AsianOptions.Add(new AsianOption()
            {
                Symbol = String.Join(db.Equities.FirstOrDefault(x => x.Id == 1).Symbol, st[1]),
                Strike = 60,
                Tenor = 2,
                IsCall = true,
                EquityId = 2
            });
            db.AsianOptions.Add(new AsianOption()
            {
                Symbol = String.Join(db.Equities.FirstOrDefault(x => x.Id == 1).Symbol, st[2]),
                Strike = 70,
                Tenor = 1,
                IsCall = true,
                EquityId = 3
            });
            db.SaveChanges();
        }

        public static void GenEuro(Model1Container db)
        {
            db.EuropeanOptions.Add(new EuropeanOption()
            {
                Symbol = String.Join(db.Equities.FirstOrDefault(x => x.Id == 1).Symbol, "O"),
                Strike = 50,
                Tenor = 1,
                IsCall = true,
                EquityId = 1
            });

            db.EuropeanOptions.Add(new EuropeanOption()
            {
                Symbol = String.Join(db.Equities.FirstOrDefault(x => x.Id == 2).Symbol, "O"),
                Strike = 60,
                Tenor = 2,
                IsCall = false,
                EquityId = 2
            });

            db.EuropeanOptions.Add(new EuropeanOption()
            {
                Symbol = String.Join(db.Equities.FirstOrDefault(x => x.Id == 3).Symbol, "O"),
                Strike = 30,
                Tenor = 1,
                IsCall = true,
                EquityId = 3
            });

            db.SaveChanges();
        }

    }

    public class Instrument
    {
        public double Price { get; set; }
        public string Company { get; set; }
        public DateTime Issuance { get; set; }
        public DateTime Expiration { get; set; }
        protected static double dx = 0.0001; // used as infinitesimal in order to calculate partial derivatives
    }

    partial class Equity : Instrument
    {

    }

    public class Option : Instrument
    {
        public Equity Underlying { get; set; }
        public double uPrice, uVol;
        public double Strike { get; set; }
        public double Tenor { get; set; }
        public bool IsCall { get; set; }
        public int EquityId { get; set; }

        public string Symbol { get; set; }

        protected virtual double payoffFunction(double[] path) { return 0; }

        /// <summary>
        /// Intrinsic Values of the option, depends implicitly on the payoffFunction
        /// </summary>
        /// <param name="R">risk free interest rate</param>
        /// <param name="Data">random numbers</param>
        /// <param name="s">spot price of the underlying</param>
        /// <param name="vol">volatility of the underlying</param>
        /// <param name="k">Strike price</param>
        /// <param name="t">Tenor</param>
        /// <param name="c">if this is a call</param>
        /// <param name="cv">if control variate is employed</param>
        /// <returns></returns>
        protected virtual double[] Intrinsic(double R, double[][] Data, double s, double vol, double k, double t, bool c, bool cv)
        {
            double[][] sim = Brownian.GBMMatrix(R, vol, s, t, Data);
            double[] simZ = sim.Select(x => x[x.Length - 1]).ToArray();
            //double[] simZ = sim.Transpose()[sim[0].Length - 1];
            double[] raw = new double[sim.Length];
            for (int i = 0; i < raw.Length; i++)
            {
                raw[i] = payoffFunction(sim[i]);
            }
            if (cv)
            {
                Func<double, double, double> d1 = (uP, tau) => (Math.Log(uP / Strike) + (R + Math.Pow(uVol, 2) / 2) * tau) / (uVol * Math.Sqrt(tau));
                double[] ControlVariate = Enumerable.Repeat(0.0, Data.Length).ToArray();
                for (int i = 0; i < ControlVariate.Length; i++)
                {
                    double y = 0;
                    for (int j = 1; j < sim[0].Length; j++)
                    {
                        double tau = t - t / sim[0].Length * j;
                        double BSD = IsCall ? MMA.CDF(d1(sim[i][j - 1], tau)) : MMA.CDF(d1(sim[i][j - 1], tau)) - 1;
                        y = y + BSD * (sim[i][j] - sim[i][j - 1] * Math.Exp(R * t / sim[0].Length));
                    }
                    ControlVariate[i] = y;
                }
                return MMA.BinaryMap(raw, ControlVariate, (x, y) => x - y);
            }
            else { return raw; }
        }

        /// <summary>
        /// Monte Carolo Simulation Price
        /// </summary>
        /// <param name="R">risk free interest rate</param>
        /// <param name="Data">random numbers</param>
        /// <param name="CV">use control variate or not</param>
        /// <returns>Price</returns>
        public double MCPrice(double R, double[][] Data, bool CV)
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, Strike, Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-R * Tenor);
            return y0;
        }

        public double MCDelta(double R, double[][] Data, bool CV)
        {
            double y0 = Intrinsic(R, Data, (1 - dx) * uPrice, uVol, Strike, Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-R * Tenor);
            double y1 = Intrinsic(R, Data, (1 + dx) * uPrice, uVol, Strike, Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-R * Tenor);
            return (y1 - y0) / (2 * dx * uPrice);
        }

        public double MCGamma(double R, double[][] Data, bool CV)
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, Strike, Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-R * Tenor);
            double y1 = Intrinsic(R, Data, (1 + dx) * uPrice, uVol, Strike, Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-R * Tenor);
            double y2 = Intrinsic(R, Data, (1 - dx) * uPrice, uVol, Strike, Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-R * Tenor);
            return (y1 + y2 - 2 * y0) / (dx * dx * uPrice * uPrice);
        }

        public double MCVega(double R, double[][] Data, bool CV)
        {
            double y0 = Intrinsic(R, Data, uPrice, (1 - dx) * uVol, Strike, Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-R * Tenor);
            double y1 = Intrinsic(R, Data, uPrice, (1 + dx) * uVol, Strike, Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-R * Tenor);
            return (y1 - y0) / (2 * dx * uVol);
        }

        public double MCTheta(double R, double[][] Data, bool CV)
        {
            double y0 = Intrinsic(R, Data, uPrice, uVol, Strike, (1 - dx) * Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-R * (1 - dx) * Tenor);
            double y1 = Intrinsic(R, Data, uPrice, uVol, Strike, (1 + dx) * Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-R * (1 + dx) * Tenor);
            return (y1 - y0) / (2 * dx * Tenor);
        }

        public double MCRho(double R, double[][] Data, bool CV)
        {
            double y0 = Intrinsic((1 - dx) * R, Data, uPrice, uVol, Strike, Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-(1 - dx) * R * Tenor);
            double y1 = Intrinsic((1 + dx) * R, Data, uPrice, uVol, Strike, Tenor, IsCall, CV).Sum() / Data.Length * Math.Exp(-(1 + dx) * R * Tenor);
            return (y1 - y0) / (2 * dx * R);
        }

        public double MCStdError(double R, double[][] Data, bool CV)
        {
            double Output = MMA.SD(Intrinsic(R, Data, uPrice, uVol, Strike, Tenor, IsCall, CV)) / Math.Sqrt(Data.Length);
            return Output;
        }

        // Above is Monte Carlo Simulation
        // Below is Black & Scholes.

        double d1(double r) { return (Math.Log(uPrice / Strike) + (r + Math.Pow(uVol, 2) / 2) * Tenor) / (uVol * Math.Sqrt(Tenor)); }

        double d2(double r) { return (Math.Log(uPrice / Strike) - (r + Math.Pow(uVol, 2) / 2) * Tenor) / (uVol * Math.Sqrt(Tenor)); }

        public double BSPrice(double r)
        {
            if (IsCall) { return uPrice * MMA.CDF(d1(r)) - Strike * Math.Exp(-r * Tenor) * MMA.CDF(d2(r)); }
            else { return Strike * Math.Exp(-r * Tenor) * MMA.CDF(-d2(r)) - uPrice * MMA.CDF(-d1(r)); }
        }

        public double BSDelta(double r) { return IsCall ? MMA.CDF(d1(r)) : MMA.CDF(d1(r)) - 1; }

        public double BSGamma(double r) { return MMA.PDF(d1(r)) / (uPrice * uVol * Math.Sqrt(Tenor)); }

        public double BSVega(double r) { return uPrice * MMA.PDF(d1(r)) * Math.Sqrt(Tenor); }

        public double BSTheta(double r)
        {
            if (IsCall)
            {
                return -(uPrice * MMA.PDF(d1(r) * uVol) / (2 * Math.Sqrt(Tenor)) - r * Strike * Math.Exp(-r * Tenor) * MMA.CDF(d2(r)));
            }
            else
            {
                return -(uPrice * MMA.PDF(d1(r) * uVol) / (2 * Math.Sqrt(Tenor)) + r * Strike * Math.Exp(-r * Tenor) * MMA.CDF(-d2(r)));
            }
        }

        public double BSRho(double r)
        {
            if (IsCall) { return Strike * Tenor * Math.Exp(-r * Tenor) * MMA.CDF(d2(r)); }
            else { return -Strike * Tenor * Math.Exp(-r * Tenor) * MMA.CDF(-d2(r)); }
        }
    }

    partial class EuropeanOption : Option
    {
        protected override double payoffFunction(double[] path)
        {
            return IsCall ? Math.Max(path[path.Length - 1] - Strike, 0) : Math.Max(Strike - path[path.Length - 1], 0);
        }
    }

    partial class AsianOption : Option
    {
        protected override double payoffFunction(double[] path)
        {
            return IsCall ? Math.Max(path.Average() - Strike, 0) : Math.Max(Strike - path.Average(), 0);
        }
    }

    partial class DigitalOption : Option
    {
        protected override double payoffFunction(double[] path)
        {
            if (IsCall)
            {
                return path[path.Length - 1] > Strike ? Rebate : 0;
            }
            else
            {
                return path[path.Length - 1] < Strike ? Rebate : 0;
            }
        }
    }

    partial class BarrierOption : Option
    {
        protected override double payoffFunction(double[] path)
        {
            if (Barrier > uPrice)
            {
                if (KnockOut)
                {
                    if (IsCall) { return path.Max() > Barrier ? 0 : Math.Max(path[path.Length - 1] - Strike, 0); }
                    else { return path.Max() > Barrier ? 0 : Math.Max(Strike - path[path.Length - 1], 0); }
                }
                else
                {
                    if (IsCall) { return path.Max() > Barrier ? Math.Max(path[path.Length - 1] - Strike, 0) : 0; }
                    else { return path.Max() > Barrier ? Math.Max(Strike - path[path.Length - 1], 0) : 0; }
                }
            }
            else
            {
                if (KnockOut)
                {
                    if (IsCall) { return path.Max() > Barrier ? 0 : Math.Max(path[path.Length - 1] - Strike, 0); }
                    else { return path.Max() > Barrier ? 0 : Math.Max(Strike - path[path.Length - 1], 0); }
                }
                else
                {
                    if (IsCall) { return path.Max() > Barrier ? Math.Max(path[path.Length - 1] - Strike, 0) : 0; }
                    else { return path.Max() > Barrier ? Math.Max(Strike - path[path.Length - 1], 0) : 0; }
                }
            }
        }
    }

    partial class LookbackOption : Option
    {
        protected override double payoffFunction(double[] path)
        {
            return IsCall ? Math.Max(path.Max() - Strike, 0) : Math.Max(Strike - path.Min(), 0);
        }
    }

    partial class RangeOption : Option
    {
        protected override double payoffFunction(double[] path)
        {
            return path.Max() - path.Min(); ;
        }
    }

    class MMA
    //Stands for Mathematica
    {
        static Func<Random, double, double, double[]> BoxMuller = (rnd, mean, vol) =>
        //Gives 2 Normal distribution RNs
        {
            double x1 = rnd.NextDouble();
            double x2 = rnd.NextDouble();
            double z1 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Cos(2 * Math.PI * x2)) * Math.Sqrt(vol) + mean;
            double z2 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Sin(2 * Math.PI * x2)) * Math.Sqrt(vol) + mean;
            double[] z = new double[2] { z1, z2 }; ;
            return z;
        };

        static Func<Random, double, double, double[]> PolarReject = (rnd, mean, vol) =>
        //Gives 2 Normal distribution RNs
        {
            double x1, x2, w, c, z1, z2;
            do
            {
                x1 = rnd.NextDouble() * 2 - 1;
                x2 = rnd.NextDouble() * 2 - 1;
                w = x1 * x1 + x2 * x2;
            }
            while (w > 1);
            c = Math.Sqrt(-2 * Math.Log(w) / w);
            z1 = c * x1 * Math.Sqrt(vol) + mean;
            z2 = c * x2 * Math.Sqrt(vol) + mean;
            double[] z = { z1, z2 }; ;
            return z;
        };

        static public Func<Random, double[]> StdBoxMuller = (rnd) => BoxMuller(rnd, 0, 1);
        //Gives 2 Std Normal distribution RNs

        static public Func<Random, double[]> StdPolarReject = (rnd) => PolarReject(rnd, 0, 1);
        //Gives 2 Std Normal distribution RNs

        static Func<double, double> Erf = (x) =>
        // Error function; credit to www.johndcook.com/blog/csharp_erf
        {
            double a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
            int s = x < 0 ? -1 : 1;
            x = Math.Abs(x);
            double t = 1.0 / (1.0 + p * x);
            double y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.Exp(-x * x);
            return s * y;
        };

        static public Func<double, double> CDF = x => (1 + Erf(x / Math.Sqrt(2))) / 2;
        // CDF of standard normal distribution

        static public Func<double, double> PDF = x => Math.Exp(-(x * x) / 2) / (1 * Math.Sqrt(2 * Math.PI));
        // PDF of standard normal distribution

        static public Func<int, int, bool, Func<Random, double[]>, bool, double[][]> StdNormalRNGMatrix = (Trials, Steps, Antithetic, Transform, ThreadS) =>
        // Generates a Trials * Steps matrix whose entries are all random numbers given by a std normal distribution
        // "Transform" argument can be either StdBoxMuller or StdPolarReject.
        {
            Random rnd = new Random();
            if (ThreadS)
            {
                if (Antithetic)
                {
                    Trials = Trials % 2 == 0 ? Trials : Trials + 1;
                    Steps = Steps % 2 == 0 ? Steps : Steps + 1;
                    double[][] output = new double[Trials][];
                    Parallel.For(0, Trials / 2, a =>
                    //for (int a = 0; a < Trials / 2; a++)
                    {
                        output[a] = new double[Steps];
                        output[a + Trials / 2] = new double[Steps];
                        Parallel.For(0, Steps / 2, b =>
                        //for (int b = 0; b < Steps / 2; b++)
                        {
                            double[] z = Transform(rnd); // "Transform" argument can be either StdBoxMuller or StdPolarReject.
                            output[a][b] = z[0];
                            output[a + Trials / 2][b] = -z[0];
                            output[a][b + Steps / 2] = -z[1];
                            output[a + Trials / 2][b + Steps / 2] = -z[1];
                        });
                    });
                    return output;
                }
                else
                {
                    Trials = Trials % 2 == 0 ? Trials : Trials + 1;
                    double[][] output = new double[Trials][];
                    Parallel.For(0, Trials / 2, a =>
                    //for (int a = 0; a < Trials / 2; a++)
                    {
                        output[a] = new double[Steps];
                        output[a + Trials / 2] = new double[Steps];
                        for (int b = 0; b < Steps; b++)
                        {
                            double[] z = Transform(rnd); // "Transform" argument can be either StdBoxMuller or StdPolarReject.
                            output[a][b] = z[0];
                            output[a][b] = z[1];
                        }
                    });
                    return output;
                }
            }
            else
            {
                if (Antithetic)
                {
                    Trials = Trials % 2 == 0 ? Trials : Trials + 1;
                    Steps = Steps % 2 == 0 ? Steps : Steps + 1;
                    double[][] output = new double[Trials][];
                    //Parallel.For(0, Trials / 2, a =>
                    for (int a = 0; a < Trials / 2; a++)
                    {
                        output[a] = new double[Steps];
                        output[a + Trials / 2] = new double[Steps];
                        //Parallel.For(0, Steps / 2, b =>
                        for (int b = 0; b < Steps / 2; b++)
                        {
                            double[] z = Transform(rnd); // "Transform" argument can be either StdBoxMuller or StdPolarReject.
                            output[a][b] = z[0];
                            output[a + Trials / 2][b] = -z[0];
                            output[a][b + Steps / 2] = -z[1];
                            output[a + Trials / 2][b + Steps / 2] = -z[1];
                        };
                    };
                    return output;
                }
                else
                {
                    Trials = Trials % 2 == 0 ? Trials : Trials + 1;
                    double[][] output = new double[Trials][];
                    //Parallel.For(0, Trials / 2, a =>
                    for (int a = 0; a < Trials / 2; a++)
                    {
                        output[a] = new double[Steps];
                        output[a + Trials / 2] = new double[Steps];
                        for (int b = 0; b < Steps; b++)
                        {
                            double[] z = Transform(rnd); // "Transform" argument can be either StdBoxMuller or StdPolarReject.
                            output[a][b] = z[0];
                            output[a][b] = z[1];
                        }
                    };
                    return output;
                }
            }
        };

        public static Func<double[], double[], Func<double, double, double>, double[]> BinaryMap = (L1, L2, f) =>
        // might just be syntactic salt
        {
            int l = L1.Length;
            double[] Z = new double[l];
            for (int i = 0; i < l; i++)
            {
                Z[i] = f(L1[i], L2[i]);
            }
            return Z;
        };

        static public Func<double[], double> Variance = input => input.Map(x => x * x).Average() - Math.Pow(input.Average(), 2);
        // Gives the Variance of an array

        static public Func<double[], double[], double> Covariance = (X, Y) => BinaryMap(X, Y, (x, y) => x * y).Average() - X.Average() * Y.Average();
        // Gives the Covariance of an array

        static public Func<double[], double> SD = input => Math.Sqrt(Variance(input));
        // Gives the standard deviation of an array

        static Predicate<int> PrimeTF = n =>
        // whether or not an integer is a prime number; non-positives are all false
        {
            if (n < 2) { return false; }
            else if (n == 2) { return true; }
            else
            {
                bool Z = true;
                int i = 2;
                do
                {
                    if (n % i == 0) { Z = false; }
                    i = i + 1;
                }
                while (i <= Math.Sqrt(n) && Z);
                return Z;
            }
        };

        static public Func<int, int> PrimeSmallest = n =>
        // returns the smallest prime number larger than or equal to n
        {
            bool Z = true;
            int m = n;
            do
            {
                Z = PrimeTF(m);
                m = m + 1;
            }
            while (m <= 2 * n && !Z);
            return m - 1;
        };

        static public Func<double, Func<double, double>, double> FirstDerivative = (x, f) =>
        // use 0.000001 as if infinitesimal
        {
            double dx = 0.000001 * x;
            return (f(x + dx) - f(x - dx)) / (2 * dx);
        };

        static Func<int, int> factorial = n => Enumerable.Range(1, n).Aggregate(1, (b, c) => b * c);

        static public Func<int, int, double[]> Faure = (M, N) =>
        // apparently this one doesn't work
        {
            double[] X = new double[M * N];
            int p = PrimeSmallest(N);
            double u = Math.Log(M) / Math.Log(p);
            int m = Convert.ToInt32(Math.Floor(u));
            int[][] A = new int[M * N][];
            A[0] = new int[m];
            for (int l = 0; l < m; l++)
            {
                A[0][l] = Convert.ToInt32(M % Math.Pow(p, l + 1) / p);
            }
            for (int k = 1; k < X.Length; k++)
            {
                double x = 0;
                A[k] = new int[m];
                for (int l = 0; l < m; l++)
                {
                    int y = 0;
                    for (int q = l; q < m; q++)
                    {
                        y = y + (factorial(q) / (factorial(l) * factorial(q - l)) * A[k - 1][q]) % p;
                    }
                    A[k][l] = y;
                    x = x + (A[k][l] * Convert.ToDouble((1 / Math.Pow(p, l + 1))));
                }
                X[k] = x;
            }
            return X;
        };
    }

    class Brownian
    {
        static Func<double, double, double, double, double, double> RecursiveBM
            // Recursive Brownian Motion
            = (Drift, Vol, Pre, dt, Rnd) => Pre + Drift * dt + Vol * Math.Sqrt(dt) * Rnd;

        static Func<double, double, double, double, double[], double> AnalyticBM
            // Analytic Brownian Motion; gives the nth step of the motion, n = Rnd.Length
            = (Drift, Vol, S0, T, Rnd) => S0 + Drift * Convert.ToDouble(T / Rnd.Length) * Rnd.Length + Vol * Math.Sqrt(Convert.ToDouble(T / Rnd.Length)) * Rnd.Sum();

        static public Func<double, double, double, double, double, double> RecursiveGBM
            // Recursive Geometric Brownian Motion
            = (Drift, Vol, Pre, dt, Rnd) => Pre * Math.Exp((Drift - Vol * Vol / 2) * dt + Vol * Math.Sqrt(dt) * Rnd);

        static Func<double, double, double, double, double[], double> AnalyticGBM
            // Analytic Brownian Motion; gives the nth step of the motion, n = Rnd.Length
            = (Drift, Vol, S0, T, Rnd) => S0 * Math.Exp((Drift - Vol * Vol / 2) * Convert.ToDouble(T / Rnd.Length) * Rnd.Length + Vol * Math.Sqrt(Convert.ToDouble(T / Rnd.Length)) * Rnd.Sum());

        static double[] Path(double Drift, double Vol, double S0, double T, double[] RndN, Func<double, double, double, double, double, double> Motion)
        // Generates a trial {S0, S1, S2, S3, ...}
        {
            double dt = T / RndN.Length;
            double[] output = RndN.FoldList(S0, (Pre, Rnd) => Motion(Drift, Vol, Pre, dt, Rnd));
            return output;
        }

        static double[][] Matrix(double Drift, double Vol, double S0, double T, double[][] RndN, Func<double, double, double, double, double, double> Motion)
        // Generates trials {S0, S1, S2, S3, ...}
        {
            double dt = T / RndN[0].Length;
            double[] Princeps = Enumerable.Repeat(S0, RndN.Length).ToArray();
            double[][] output = RndN.FoldMatrix(Princeps, (Pre, Rnd) => Motion(Drift, Vol, Pre, dt, Rnd));
            return output;
        }

        static public double[] GBMPath(double Drift, double Vol, double S0, double T, double[] RndN)
        // Generates a trial based on Geometric Brownian Motion 
        { return Path(Drift, Vol, S0, T, RndN, RecursiveGBM); }

        static public double[][] GBMMatrix(double Drift, double Vol, double S0, double T, double[][] RndN)
        // Generates many trials based on Geometric Brownian Motion 
        { return Matrix(Drift, Vol, S0, T, RndN, RecursiveGBM); }

        static double[] BMPath(double Drift, double Vol, double S0, double T, double[] RndN)
        // Generates a trial based on Brownian Motion 
        { return Path(Drift, Vol, S0, T, RndN, RecursiveBM); }

        static double[][] BMMatrix(double Drift, double Vol, double S0, double T, double[][] RndN)
        // Generates many trials based on Brownian Motion 
        { return Matrix(Drift, Vol, S0, T, RndN, RecursiveBM); }
    }
}
namespace SyntacticCinnamon
{
    static class Functionals
    {
        public static double Fold(this double[] L, double Z, Func<double, double, double> f)
        // Extension method for an unidimensional array
        // Almost the same as LINQ Aggregate
        {
            for (int i = 0; i < L.Length; i++)
            {
                Z = f(Z, L[i]);
            }
            return Z;
        }

        public static double[] FoldList(this double[] L, double Z, Func<double, double, double> f)
        // Extension method for an unidimensional array
        // The purpose of this method is attempting to achieve exactly the same functionality as reference.wolfram.com/language/ref/FoldList.html
        {
            double[] Y = new double[L.Length + 1];
            Y[0] = Z;
            for (int i = 0; i < L.Length; i++)
            {
                Z = f(Z, L[i]);
                Y[i + 1] = Z;
            }
            return Y;
        }

        public static double[][] FoldMatrix(this double[][] M, double[] Z, Func<double, double, double> f)
        // Extension method for an bidimensional array; similar to FoldList
        // could be a general case of FoldList if C# weren't strongly typed, unless there is some trick I don't know
        {
            int row = M.Length;
            int col = M[0].Length;
            double[][] W = new double[row][];
            for (int i = 0; i < row; i++)
            {
                double X = Z[i];
                W[i] = new double[col + 1];
                W[i][0] = X;
                for (int j = 0; j < col; j++)
                {
                    X = f(X, M[i][j]);
                    W[i][j + 1] = X;
                }
            }
            return W;
        }

        public static double Nest(this double X, Func<double, double> f, int n)
        // Extension method for a double with an unary operation defined on doubles
        {
            double Y = X;
            for (int i = 0; i < n; i++)
            {
                Y = f(Y);
            }
            return Y;
        }

        public static double[] NestList(this double X, Func<double, double> f, int n)
        // Extension method for a double with an unary operation defined on doubles
        {
            double[] Z = new double[n + 1];
            Z[0] = X;
            for (int i = 1; i < Z.Length; i++)
            {
                Z[i] = f(Z[i - 1]);
            }
            return Z;
        }

        public static double[] Map(this double[] L, Func<double, double> f)
        // Extension method for an unidimensional array
        {
            double[] Z = new double[L.Length];
            for (int i = 0; i < L.Length; i++)
            {
                Z[i] = f(L[i]);
            }
            return Z;
        }

        public static double[][] Transpose(this double[][] M)
        // Extension method for a jagged bidimensional array
        {
            double[][] W = new double[M[0].Length][];
            for (int i = 0; i < M[0].Length; i++)
            {
                W[i] = new double[M.Length];
                for (int j = 0; j < M.Length; j++)
                {
                    W[i][j] = M[j][i];
                }
            }
            return W;
        }

        public static void PrintMatrix(this double[][] M)
        // Extension method for a jagged bidimensional array
        {
            foreach (double[] i in M)
            {
                foreach (double j in i)
                {
                    Console.Write("{0}, ", Math.Round(j, 2));
                }
                Console.Write("\n");
            }
            Console.ReadLine();
        }
    }
}