﻿namespace Final_ZYC
{
    partial class HistlPricesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.EquityIDL = new System.Windows.Forms.Label();
            this.PriceL = new System.Windows.Forms.Label();
            this.DateL = new System.Windows.Forms.Label();
            this.DateTimePick = new System.Windows.Forms.DateTimePicker();
            this.HistPButton = new System.Windows.Forms.Button();
            this.PriceBox = new System.Windows.Forms.TextBox();
            this.EquityIDBox = new System.Windows.Forms.TextBox();
            this.ErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.IDL = new System.Windows.Forms.Label();
            this.IDBox = new System.Windows.Forms.TextBox();
            this.DeleteButtton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // EquityIDL
            // 
            this.EquityIDL.AutoSize = true;
            this.EquityIDL.Location = new System.Drawing.Point(49, 92);
            this.EquityIDL.Name = "EquityIDL";
            this.EquityIDL.Size = new System.Drawing.Size(82, 23);
            this.EquityIDL.TabIndex = 0;
            this.EquityIDL.Text = "Equity ID";
            // 
            // PriceL
            // 
            this.PriceL.AutoSize = true;
            this.PriceL.Location = new System.Drawing.Point(49, 142);
            this.PriceL.Name = "PriceL";
            this.PriceL.Size = new System.Drawing.Size(48, 23);
            this.PriceL.TabIndex = 1;
            this.PriceL.Text = "Price";
            // 
            // DateL
            // 
            this.DateL.AutoSize = true;
            this.DateL.Location = new System.Drawing.Point(49, 192);
            this.DateL.Name = "DateL";
            this.DateL.Size = new System.Drawing.Size(46, 23);
            this.DateL.TabIndex = 2;
            this.DateL.Text = "Date";
            // 
            // DateTimePick
            // 
            this.DateTimePick.Location = new System.Drawing.Point(169, 192);
            this.DateTimePick.Name = "DateTimePick";
            this.DateTimePick.Size = new System.Drawing.Size(303, 30);
            this.DateTimePick.TabIndex = 3;
            this.DateTimePick.ValueChanged += new System.EventHandler(this.DateTimePick_ValueChanged);
            // 
            // HistPButton
            // 
            this.HistPButton.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HistPButton.Location = new System.Drawing.Point(49, 267);
            this.HistPButton.Name = "HistPButton";
            this.HistPButton.Size = new System.Drawing.Size(255, 66);
            this.HistPButton.TabIndex = 4;
            this.HistPButton.Text = "INSERE HOC DATUM!";
            this.HistPButton.UseVisualStyleBackColor = true;
            this.HistPButton.Click += new System.EventHandler(this.HistPButton_Click);
            // 
            // PriceBox
            // 
            this.PriceBox.Location = new System.Drawing.Point(299, 142);
            this.PriceBox.Name = "PriceBox";
            this.PriceBox.Size = new System.Drawing.Size(172, 30);
            this.PriceBox.TabIndex = 5;
            this.PriceBox.TextChanged += new System.EventHandler(this.PriceBox_TextChanged);
            // 
            // EquityIDBox
            // 
            this.EquityIDBox.Location = new System.Drawing.Point(299, 92);
            this.EquityIDBox.Name = "EquityIDBox";
            this.EquityIDBox.Size = new System.Drawing.Size(172, 30);
            this.EquityIDBox.TabIndex = 6;
            this.EquityIDBox.TextChanged += new System.EventHandler(this.EquityIDBox_TextChanged);
            // 
            // ErrorProvider
            // 
            this.ErrorProvider.ContainerControl = this;
            // 
            // IDL
            // 
            this.IDL.AutoSize = true;
            this.IDL.Location = new System.Drawing.Point(49, 43);
            this.IDL.Name = "IDL";
            this.IDL.Size = new System.Drawing.Size(207, 23);
            this.IDL.TabIndex = 7;
            this.IDL.Text = "ID (type 0 if instantiation)";
            // 
            // IDBox
            // 
            this.IDBox.Location = new System.Drawing.Point(299, 40);
            this.IDBox.Name = "IDBox";
            this.IDBox.Size = new System.Drawing.Size(172, 30);
            this.IDBox.TabIndex = 8;
            this.IDBox.TextChanged += new System.EventHandler(this.IDBox_TextChanged);
            // 
            // DeleteButtton
            // 
            this.DeleteButtton.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteButtton.Location = new System.Drawing.Point(324, 267);
            this.DeleteButtton.Name = "DeleteButtton";
            this.DeleteButtton.Size = new System.Drawing.Size(164, 66);
            this.DeleteButtton.TabIndex = 9;
            this.DeleteButtton.Text = "Delete";
            this.DeleteButtton.UseVisualStyleBackColor = true;
            this.DeleteButtton.Click += new System.EventHandler(this.DeleteButtton_Click);
            // 
            // HistlPricesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 361);
            this.Controls.Add(this.DeleteButtton);
            this.Controls.Add(this.IDBox);
            this.Controls.Add(this.IDL);
            this.Controls.Add(this.EquityIDBox);
            this.Controls.Add(this.PriceBox);
            this.Controls.Add(this.HistPButton);
            this.Controls.Add(this.DateTimePick);
            this.Controls.Add(this.DateL);
            this.Controls.Add(this.PriceL);
            this.Controls.Add(this.EquityIDL);
            this.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "HistlPricesForm";
            this.Text = "Historical Prices";
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label EquityIDL;
        private System.Windows.Forms.Label PriceL;
        private System.Windows.Forms.Label DateL;
        private System.Windows.Forms.DateTimePicker DateTimePick;
        private System.Windows.Forms.Button HistPButton;
        private System.Windows.Forms.TextBox PriceBox;
        private System.Windows.Forms.TextBox EquityIDBox;
        private System.Windows.Forms.ErrorProvider ErrorProvider;
        private System.Windows.Forms.TextBox IDBox;
        private System.Windows.Forms.Label IDL;
        private System.Windows.Forms.Button DeleteButtton;
    }
}