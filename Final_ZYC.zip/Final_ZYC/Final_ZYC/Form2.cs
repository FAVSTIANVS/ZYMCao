﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_ZYC
{
    public partial class InstruInputForm : Form
    {
        bool AA { get; set; }
        bool BB { get; set; }
        bool CC { get; set; }
        Model1Container db { get; set; }

        public InstruInputForm()
        {
            InitializeComponent();

            ErrorProvider.SetIconAlignment(SymbolBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(SymbolBox, 3);

            ErrorProvider.SetIconAlignment(VolatilityBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(VolatilityBox, 3);

            ErrorProvider.SetIconAlignment(StrikeBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(StrikeBox, 3);

            ErrorProvider.SetIconAlignment(TenorBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(TenorBox, 3);

            ErrorProvider.SetIconAlignment(RebateBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(RebateBox, 3);

            ErrorProvider.SetIconAlignment(BarrierBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(BarrierBox, 3);

            ErrorProvider.SetIconAlignment(IDBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(IDBox, 3);

            ErrorProvider.SetIconAlignment(UnderlyingIDBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(UnderlyingIDBox, 3);

            db = new Model1Container();

            InstruButton.Enabled = false;
            SymbolBox.Enabled = false;
            VolatilityBox.Enabled = false;
            StrikeBox.Enabled = false;
            TenorBox.Enabled = false;
            RebateBox.Enabled = false;
            BarrierBox.Enabled = false;
            IsCallBox.Enabled = false;
            KnockOutBox.Enabled = false;
            UnderlyingIDBox.Enabled = false;

            AA = false;
            BB = false;
            CC = false;

            DeleteButton.Enabled = false;
        }

        private void SymbolBox_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(VolatilityBox.Text, out _) || Convert.ToInt32(VolatilityBox.Text) < 0)
            {
                ErrorProvider.SetError(VolatilityBox, "Please enter a positive number!");
                InstruButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(VolatilityBox, string.Empty);
            }
        }

        private void IDBox_TextChanged(object sender, EventArgs e)
        {

            if (!int.TryParse(IDBox.Text, out _) || Convert.ToInt32(IDBox.Text) < 0)
            {
                ErrorProvider.SetError(IDBox, "Please enter a positive number!");
                InstruButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(IDBox, string.Empty);
                DeleteButton.Enabled = Convert.ToInt32(IDBox.Text) != 0;
            }
        }

        private void UnderlyingIDBox_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(UnderlyingIDBox.Text, out _) || Convert.ToInt32(UnderlyingIDBox.Text) < 0)
            {
                ErrorProvider.SetError(UnderlyingIDBox, "Please enter a positive number!");
                CC = false;
                InstruButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(UnderlyingIDBox, string.Empty);
                CC = true;
                InstruButton.Enabled = AA && BB && CC;
            }
        }

        private void VolatilityBox_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(VolatilityBox.Text, out _) || Convert.ToDouble(VolatilityBox.Text) < 0)
            {
                ErrorProvider.SetError(VolatilityBox, "Please enter a positive number!");
                InstruButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(VolatilityBox, string.Empty);
                InstruButton.Enabled = true;
            }
        }

        private void StrikeBox_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(StrikeBox.Text, out _) || Convert.ToDouble(StrikeBox.Text) < 0)
            {
                ErrorProvider.SetError(StrikeBox, "Please enter a positive number!");
                AA = false;
                InstruButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(StrikeBox, string.Empty);
                AA = true;
                InstruButton.Enabled = AA && BB && CC;
            }

        }

        private void TenorBox_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(TenorBox.Text, out _) || Convert.ToDouble(TenorBox.Text) < 0)
            {
                ErrorProvider.SetError(TenorBox, "Please enter a positive number!");
                BB = false;
                InstruButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(TenorBox, string.Empty);
                BB = true;
                InstruButton.Enabled = AA && BB && CC;
            }

        }

        private void RebateBox_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(RebateBox.Text, out _) || Convert.ToDouble(RebateBox.Text) < 0)
            {
                ErrorProvider.SetError(RebateBox, "Please enter a positive number!");
                InstruButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(RebateBox, string.Empty);
                InstruButton.Enabled = true;
            }
        }

        private void BarrierBox_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(BarrierBox.Text, out _) || Convert.ToDouble(BarrierBox.Text) < 0)
            {
                ErrorProvider.SetError(BarrierBox, "Please enter a positive number!");
                InstruButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(BarrierBox, string.Empty);
                InstruButton.Enabled = true;
            }
        }

        private void EquityRadio_CheckedChanged(object sender, EventArgs e)
        {
            SymbolBox.Enabled = EquityRadio.Checked;
            VolatilityBox.Enabled = EquityRadio.Checked;
            ErrorProvider.SetError(VolatilityBox, string.Empty);
        }

        private void EORadio_CheckedChanged(object sender, EventArgs e)
        {
            ErrorProvider.SetError(StrikeBox, string.Empty);
            ErrorProvider.SetError(TenorBox, string.Empty);
            SymbolBox.Enabled = EORadio.Checked;
            StrikeBox.Enabled = EORadio.Checked;
            TenorBox.Enabled = EORadio.Checked;
            IsCallBox.Enabled = EORadio.Checked;
            UnderlyingIDBox.Enabled = EORadio.Checked;
        }

        private void AORadio_CheckedChanged(object sender, EventArgs e)
        {
            ErrorProvider.SetError(StrikeBox, string.Empty);
            ErrorProvider.SetError(TenorBox, string.Empty);
            SymbolBox.Enabled = AORadio.Checked;
            StrikeBox.Enabled = AORadio.Checked;
            TenorBox.Enabled = AORadio.Checked;
            IsCallBox.Enabled = AORadio.Checked;
            UnderlyingIDBox.Enabled = AORadio.Checked;
        }

        private void DORadio_CheckedChanged(object sender, EventArgs e)
        {
            ErrorProvider.SetError(StrikeBox, string.Empty);
            ErrorProvider.SetError(TenorBox, string.Empty);
            SymbolBox.Enabled = DORadio.Checked;
            StrikeBox.Enabled = DORadio.Checked;
            TenorBox.Enabled = DORadio.Checked;
            IsCallBox.Enabled = DORadio.Checked;
            RebateBox.Enabled = DORadio.Checked;
            UnderlyingIDBox.Enabled = DORadio.Checked;
        }

        private void BORadio_CheckedChanged(object sender, EventArgs e)
        {
            ErrorProvider.SetError(StrikeBox, string.Empty);
            ErrorProvider.SetError(TenorBox, string.Empty);
            SymbolBox.Enabled = BORadio.Checked;
            StrikeBox.Enabled = BORadio.Checked;
            TenorBox.Enabled = BORadio.Checked;
            IsCallBox.Enabled = BORadio.Checked;
            KnockOutBox.Enabled = BORadio.Checked;
            BarrierBox.Enabled = BORadio.Checked;
            UnderlyingIDBox.Enabled = BORadio.Checked;
        }

        private void LORadio_CheckedChanged(object sender, EventArgs e)
        {
            ErrorProvider.SetError(StrikeBox, string.Empty);
            ErrorProvider.SetError(TenorBox, string.Empty);
            SymbolBox.Enabled = LORadio.Checked;
            StrikeBox.Enabled = LORadio.Checked;
            TenorBox.Enabled = LORadio.Checked;
            IsCallBox.Enabled = LORadio.Checked;
            UnderlyingIDBox.Enabled = LORadio.Checked;
        }

        private void RORadio_CheckedChanged(object sender, EventArgs e)
        {
            ErrorProvider.SetError(StrikeBox, string.Empty);
            ErrorProvider.SetError(TenorBox, string.Empty);
            SymbolBox.Enabled = RORadio.Checked;
            StrikeBox.Enabled = RORadio.Checked;
            TenorBox.Enabled = RORadio.Checked;
            IsCallBox.Enabled = RORadio.Checked;
            UnderlyingIDBox.Enabled = RORadio.Checked;
        }


        private void InstruButton_Enter(object sender, EventArgs e)
        {
            InstruButton_Click(sender, e);
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {

            int yId = Convert.ToInt32(IDBox.Text);
            if (EquityRadio.Checked)
            {
                var rem = db.Equities.FirstOrDefault(x => x.Id == yId);
                db.Equities.Remove(rem);
            }
            else if (EORadio.Checked)
            {
                var rem = db.EuropeanOptions.FirstOrDefault(x => x.Id == yId);
                db.EuropeanOptions.Remove(rem);
            }
            else if (AORadio.Checked)
            {
                var rem = db.AsianOptions.FirstOrDefault(x => x.Id == yId);
                db.AsianOptions.Remove(rem);
            }
            else if (DORadio.Checked)
            {
                var rem = db.DigitalOptions.FirstOrDefault(x => x.Id == yId);
                db.DigitalOptions.Remove(rem);
            }
            else if (BORadio.Checked)
            {
                var rem = db.BarrierOptions.FirstOrDefault(x => x.Id == yId);
                db.BarrierOptions.Remove(rem);
            }
            else if (LORadio.Checked)
            {
                var rem = db.LookbackOptions.FirstOrDefault(x => x.Id == yId);
                db.LookbackOptions.Remove(rem);
            }
            else
            {
                var rem = db.RangeOptions.FirstOrDefault(x => x.Id == yId);
                db.RangeOptions.Remove(rem);
            }

            db.SaveChanges();
        }
        private void InstruButton_Click(object sender, EventArgs e)
        {
            InstruButton.Enabled = false;


            if (IDBox.Text == "0")
            {
                if (EquityRadio.Checked)
                {
                    db.Equities.Add(new Equity()
                    {
                        Symbol = SymbolBox.Text,
                        Volatility = Convert.ToDouble(VolatilityBox.Text)
                    }); 
                }
                else if (EORadio.Checked)
                {
                    db.EuropeanOptions.Add(new EuropeanOption()
                    {
                        Symbol = SymbolBox.Text,
                        Strike = Convert.ToDouble(StrikeBox.Text),
                        Tenor = Convert.ToDouble(TenorBox.Text),
                        IsCall = IsCallBox.Checked
                    }); ; 
                }
                else if (AORadio.Checked)
                {
                    db.AsianOptions.Add(new AsianOption()
                    {
                        Symbol = SymbolBox.Text,
                        Strike = Convert.ToDouble(StrikeBox.Text),
                        Tenor = Convert.ToDouble(TenorBox.Text),
                        IsCall = IsCallBox.Checked
                    });
                }
                else if (DORadio.Checked)
                {
                    db.DigitalOptions.Add(new DigitalOption()
                    {
                        Symbol = SymbolBox.Text,
                        Strike = Convert.ToDouble(StrikeBox.Text),
                        Tenor = Convert.ToDouble(TenorBox.Text),
                        IsCall = IsCallBox.Checked,
                        Rebate = Convert.ToDouble(RebateBox.Text)
                    });
                }
                else if (BORadio.Checked)
                {
                    db.BarrierOptions.Add(new BarrierOption()
                    {
                        Symbol = SymbolBox.Text,
                        Strike = Convert.ToDouble(StrikeBox.Text),
                        Tenor = Convert.ToDouble(TenorBox.Text),
                        IsCall = IsCallBox.Checked,
                        Barrier = Convert.ToDouble(BarrierBox.Text),
                        KnockOut = KnockOutBox.Checked
                    }); ;
                }
                else if (LORadio.Checked)
                {
                    db.LookbackOptions.Add(new LookbackOption()
                    {
                        Symbol = SymbolBox.Text,
                        Strike = Convert.ToDouble(StrikeBox.Text),
                        Tenor = Convert.ToDouble(TenorBox.Text),
                        IsCall = IsCallBox.Checked
                    });
                }
                else
                {
                    db.RangeOptions.Add(new RangeOption()
                    {
                        Symbol = SymbolBox.Text,
                        Strike = Convert.ToDouble(StrikeBox.Text),
                        Tenor = Convert.ToDouble(TenorBox.Text),
                        IsCall = IsCallBox.Checked
                    });
                }
            }
            else
            {
                int yId = Convert.ToInt32(IDBox.Text);
                if (EquityRadio.Checked)
                {
                    db.Equities.FirstOrDefault(x => x.Id == yId).Symbol = SymbolBox.Text;
                    db.Equities.FirstOrDefault(x => x.Id == yId).Volatility = Convert.ToDouble(VolatilityBox.Text);
                }
                else if (EORadio.Checked)
                {
                    db.EuropeanOptions.FirstOrDefault(x => x.Id == yId).Symbol = SymbolBox.Text;
                    db.EuropeanOptions.FirstOrDefault(x => x.Id == yId).Strike = Convert.ToDouble(StrikeBox.Text);
                    db.EuropeanOptions.FirstOrDefault(x => x.Id == yId).Tenor = Convert.ToDouble(TenorBox.Text);
                    db.EuropeanOptions.FirstOrDefault(x => x.Id == yId).IsCall = IsCallBox.Checked;
                    db.EuropeanOptions.FirstOrDefault(x => x.Id == yId).EquityId = Convert.ToInt32(UnderlyingIDBox.Text);
                }
                else if (AORadio.Checked)
                {
                    db.AsianOptions.FirstOrDefault(x => x.Id == yId).Symbol = SymbolBox.Text;
                    db.AsianOptions.FirstOrDefault(x => x.Id == yId).Strike = Convert.ToDouble(StrikeBox.Text);
                    db.AsianOptions.FirstOrDefault(x => x.Id == yId).Tenor = Convert.ToDouble(TenorBox.Text);
                    db.AsianOptions.FirstOrDefault(x => x.Id == yId).IsCall = IsCallBox.Checked;
                    db.AsianOptions.FirstOrDefault(x => x.Id == yId).EquityId = Convert.ToInt32(UnderlyingIDBox.Text);
                }
                else if (DORadio.Checked)
                {
                    db.DigitalOptions.FirstOrDefault(x => x.Id == yId).Symbol = SymbolBox.Text;
                    db.DigitalOptions.FirstOrDefault(x => x.Id == yId).Strike = Convert.ToDouble(StrikeBox.Text);
                    db.DigitalOptions.FirstOrDefault(x => x.Id == yId).Tenor = Convert.ToDouble(TenorBox.Text);
                    db.DigitalOptions.FirstOrDefault(x => x.Id == yId).IsCall = IsCallBox.Checked;
                    db.DigitalOptions.FirstOrDefault(x => x.Id == yId).Rebate = Convert.ToDouble(RebateBox.Text);
                    db.DigitalOptions.FirstOrDefault(x => x.Id == yId).EquityId = Convert.ToInt32(UnderlyingIDBox.Text);
                }
                else if (BORadio.Checked)
                {
                    db.BarrierOptions.FirstOrDefault(x => x.Id == yId).Symbol = SymbolBox.Text;
                    db.BarrierOptions.FirstOrDefault(x => x.Id == yId).Strike = Convert.ToDouble(StrikeBox.Text);
                    db.BarrierOptions.FirstOrDefault(x => x.Id == yId).Tenor = Convert.ToDouble(TenorBox.Text);
                    db.BarrierOptions.FirstOrDefault(x => x.Id == yId).IsCall = IsCallBox.Checked;
                    db.BarrierOptions.FirstOrDefault(x => x.Id == yId).KnockOut = KnockOutBox.Checked;
                    db.BarrierOptions.FirstOrDefault(x => x.Id == yId).Barrier = Convert.ToDouble(BarrierBox.Text);
                    db.BarrierOptions.FirstOrDefault(x => x.Id == yId).EquityId = Convert.ToInt32(UnderlyingIDBox.Text);
                }
                else if (LORadio.Checked)
                {
                    db.LookbackOptions.FirstOrDefault(x => x.Id == yId).Symbol = SymbolBox.Text;
                    db.LookbackOptions.FirstOrDefault(x => x.Id == yId).Strike = Convert.ToDouble(StrikeBox.Text);
                    db.LookbackOptions.FirstOrDefault(x => x.Id == yId).Tenor = Convert.ToDouble(TenorBox.Text);
                    db.LookbackOptions.FirstOrDefault(x => x.Id == yId).IsCall = IsCallBox.Checked;
                    db.LookbackOptions.FirstOrDefault(x => x.Id == yId).EquityId = Convert.ToInt32(UnderlyingIDBox.Text);
                }
                else
                {
                    db.RangeOptions.FirstOrDefault(x => x.Id == yId).Symbol = SymbolBox.Text;
                    db.RangeOptions.FirstOrDefault(x => x.Id == yId).Strike = Convert.ToDouble(StrikeBox.Text);
                    db.RangeOptions.FirstOrDefault(x => x.Id == yId).Tenor = Convert.ToDouble(TenorBox.Text);
                    db.RangeOptions.FirstOrDefault(x => x.Id == yId).IsCall = IsCallBox.Checked;
                    db.RangeOptions.FirstOrDefault(x => x.Id == yId).EquityId = Convert.ToInt32(UnderlyingIDBox.Text);
                }
            }

            db.SaveChanges();

            TradesForm Trades = new TradesForm();
            Trades.ShowDialog();

            InstruButton.Enabled = true;
        }

    }
}
