﻿namespace Final_ZYC
{
    partial class InstruInputForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InstruInputForm));
            this.VolatilityL = new System.Windows.Forms.Label();
            this.StrikeL = new System.Windows.Forms.Label();
            this.TenorL = new System.Windows.Forms.Label();
            this.RebateL = new System.Windows.Forms.Label();
            this.BarrierL = new System.Windows.Forms.Label();
            this.IsCallBox = new System.Windows.Forms.CheckBox();
            this.SymbolL = new System.Windows.Forms.Label();
            this.SymbolBox = new System.Windows.Forms.TextBox();
            this.RebateBox = new System.Windows.Forms.TextBox();
            this.TenorBox = new System.Windows.Forms.TextBox();
            this.StrikeBox = new System.Windows.Forms.TextBox();
            this.VolatilityBox = new System.Windows.Forms.TextBox();
            this.BarrierBox = new System.Windows.Forms.TextBox();
            this.InstruButton = new System.Windows.Forms.Button();
            this.EquityRadio = new System.Windows.Forms.RadioButton();
            this.LORadio = new System.Windows.Forms.RadioButton();
            this.BORadio = new System.Windows.Forms.RadioButton();
            this.DORadio = new System.Windows.Forms.RadioButton();
            this.AORadio = new System.Windows.Forms.RadioButton();
            this.EORadio = new System.Windows.Forms.RadioButton();
            this.RORadio = new System.Windows.Forms.RadioButton();
            this.KnockOutBox = new System.Windows.Forms.CheckBox();
            this.ErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.IDLabel = new System.Windows.Forms.Label();
            this.IDBox = new System.Windows.Forms.TextBox();
            this.UnderlyingIDL = new System.Windows.Forms.Label();
            this.UnderlyingIDBox = new System.Windows.Forms.TextBox();
            this.DeleteButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // VolatilityL
            // 
            resources.ApplyResources(this.VolatilityL, "VolatilityL");
            this.VolatilityL.Name = "VolatilityL";
            // 
            // StrikeL
            // 
            resources.ApplyResources(this.StrikeL, "StrikeL");
            this.StrikeL.Name = "StrikeL";
            // 
            // TenorL
            // 
            resources.ApplyResources(this.TenorL, "TenorL");
            this.TenorL.Name = "TenorL";
            // 
            // RebateL
            // 
            resources.ApplyResources(this.RebateL, "RebateL");
            this.RebateL.Name = "RebateL";
            // 
            // BarrierL
            // 
            resources.ApplyResources(this.BarrierL, "BarrierL");
            this.BarrierL.Name = "BarrierL";
            // 
            // IsCallBox
            // 
            resources.ApplyResources(this.IsCallBox, "IsCallBox");
            this.IsCallBox.Name = "IsCallBox";
            this.IsCallBox.UseVisualStyleBackColor = true;
            // 
            // SymbolL
            // 
            resources.ApplyResources(this.SymbolL, "SymbolL");
            this.SymbolL.Name = "SymbolL";
            // 
            // SymbolBox
            // 
            resources.ApplyResources(this.SymbolBox, "SymbolBox");
            this.SymbolBox.Name = "SymbolBox";
            this.SymbolBox.TextChanged += new System.EventHandler(this.SymbolBox_TextChanged);
            // 
            // RebateBox
            // 
            resources.ApplyResources(this.RebateBox, "RebateBox");
            this.RebateBox.Name = "RebateBox";
            this.RebateBox.TextChanged += new System.EventHandler(this.RebateBox_TextChanged);
            // 
            // TenorBox
            // 
            resources.ApplyResources(this.TenorBox, "TenorBox");
            this.TenorBox.Name = "TenorBox";
            this.TenorBox.TextChanged += new System.EventHandler(this.TenorBox_TextChanged);
            // 
            // StrikeBox
            // 
            resources.ApplyResources(this.StrikeBox, "StrikeBox");
            this.StrikeBox.Name = "StrikeBox";
            this.StrikeBox.TextChanged += new System.EventHandler(this.StrikeBox_TextChanged);
            // 
            // VolatilityBox
            // 
            resources.ApplyResources(this.VolatilityBox, "VolatilityBox");
            this.VolatilityBox.Name = "VolatilityBox";
            this.VolatilityBox.TextChanged += new System.EventHandler(this.VolatilityBox_TextChanged);
            // 
            // BarrierBox
            // 
            resources.ApplyResources(this.BarrierBox, "BarrierBox");
            this.BarrierBox.Name = "BarrierBox";
            this.BarrierBox.TextChanged += new System.EventHandler(this.BarrierBox_TextChanged);
            // 
            // InstruButton
            // 
            resources.ApplyResources(this.InstruButton, "InstruButton");
            this.InstruButton.Name = "InstruButton";
            this.InstruButton.UseVisualStyleBackColor = true;
            this.InstruButton.Click += new System.EventHandler(this.InstruButton_Click);
            this.InstruButton.Enter += new System.EventHandler(this.InstruButton_Enter);
            // 
            // EquityRadio
            // 
            resources.ApplyResources(this.EquityRadio, "EquityRadio");
            this.EquityRadio.Name = "EquityRadio";
            this.EquityRadio.TabStop = true;
            this.EquityRadio.UseVisualStyleBackColor = true;
            this.EquityRadio.CheckedChanged += new System.EventHandler(this.EquityRadio_CheckedChanged);
            // 
            // LORadio
            // 
            resources.ApplyResources(this.LORadio, "LORadio");
            this.LORadio.Name = "LORadio";
            this.LORadio.TabStop = true;
            this.LORadio.UseVisualStyleBackColor = true;
            this.LORadio.CheckedChanged += new System.EventHandler(this.LORadio_CheckedChanged);
            // 
            // BORadio
            // 
            resources.ApplyResources(this.BORadio, "BORadio");
            this.BORadio.Name = "BORadio";
            this.BORadio.TabStop = true;
            this.BORadio.UseVisualStyleBackColor = true;
            this.BORadio.CheckedChanged += new System.EventHandler(this.BORadio_CheckedChanged);
            // 
            // DORadio
            // 
            resources.ApplyResources(this.DORadio, "DORadio");
            this.DORadio.Name = "DORadio";
            this.DORadio.TabStop = true;
            this.DORadio.UseVisualStyleBackColor = true;
            this.DORadio.CheckedChanged += new System.EventHandler(this.DORadio_CheckedChanged);
            // 
            // AORadio
            // 
            resources.ApplyResources(this.AORadio, "AORadio");
            this.AORadio.Name = "AORadio";
            this.AORadio.TabStop = true;
            this.AORadio.UseVisualStyleBackColor = true;
            this.AORadio.CheckedChanged += new System.EventHandler(this.AORadio_CheckedChanged);
            // 
            // EORadio
            // 
            resources.ApplyResources(this.EORadio, "EORadio");
            this.EORadio.Name = "EORadio";
            this.EORadio.TabStop = true;
            this.EORadio.UseVisualStyleBackColor = true;
            this.EORadio.CheckedChanged += new System.EventHandler(this.EORadio_CheckedChanged);
            // 
            // RORadio
            // 
            resources.ApplyResources(this.RORadio, "RORadio");
            this.RORadio.Name = "RORadio";
            this.RORadio.TabStop = true;
            this.RORadio.UseVisualStyleBackColor = true;
            this.RORadio.CheckedChanged += new System.EventHandler(this.RORadio_CheckedChanged);
            // 
            // KnockOutBox
            // 
            resources.ApplyResources(this.KnockOutBox, "KnockOutBox");
            this.KnockOutBox.Name = "KnockOutBox";
            this.KnockOutBox.UseVisualStyleBackColor = true;
            // 
            // ErrorProvider
            // 
            this.ErrorProvider.ContainerControl = this;
            // 
            // IDLabel
            // 
            resources.ApplyResources(this.IDLabel, "IDLabel");
            this.IDLabel.Name = "IDLabel";
            // 
            // IDBox
            // 
            resources.ApplyResources(this.IDBox, "IDBox");
            this.IDBox.Name = "IDBox";
            this.IDBox.TextChanged += new System.EventHandler(this.IDBox_TextChanged);
            // 
            // UnderlyingIDL
            // 
            resources.ApplyResources(this.UnderlyingIDL, "UnderlyingIDL");
            this.UnderlyingIDL.Name = "UnderlyingIDL";
            // 
            // UnderlyingIDBox
            // 
            resources.ApplyResources(this.UnderlyingIDBox, "UnderlyingIDBox");
            this.UnderlyingIDBox.Name = "UnderlyingIDBox";
            this.UnderlyingIDBox.TextChanged += new System.EventHandler(this.UnderlyingIDBox_TextChanged);
            // 
            // DeleteButton
            // 
            resources.ApplyResources(this.DeleteButton, "DeleteButton");
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // InstruInputForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.UnderlyingIDBox);
            this.Controls.Add(this.UnderlyingIDL);
            this.Controls.Add(this.IDBox);
            this.Controls.Add(this.IDLabel);
            this.Controls.Add(this.KnockOutBox);
            this.Controls.Add(this.RORadio);
            this.Controls.Add(this.EORadio);
            this.Controls.Add(this.AORadio);
            this.Controls.Add(this.DORadio);
            this.Controls.Add(this.BORadio);
            this.Controls.Add(this.LORadio);
            this.Controls.Add(this.EquityRadio);
            this.Controls.Add(this.InstruButton);
            this.Controls.Add(this.BarrierBox);
            this.Controls.Add(this.VolatilityBox);
            this.Controls.Add(this.StrikeBox);
            this.Controls.Add(this.TenorBox);
            this.Controls.Add(this.RebateBox);
            this.Controls.Add(this.SymbolBox);
            this.Controls.Add(this.SymbolL);
            this.Controls.Add(this.IsCallBox);
            this.Controls.Add(this.BarrierL);
            this.Controls.Add(this.RebateL);
            this.Controls.Add(this.TenorL);
            this.Controls.Add(this.StrikeL);
            this.Controls.Add(this.VolatilityL);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "InstruInputForm";
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label VolatilityL;
        private System.Windows.Forms.Label StrikeL;
        private System.Windows.Forms.Label TenorL;
        private System.Windows.Forms.Label RebateL;
        private System.Windows.Forms.Label BarrierL;
        private System.Windows.Forms.CheckBox IsCallBox;
        private System.Windows.Forms.Label SymbolL;
        private System.Windows.Forms.TextBox SymbolBox;
        private System.Windows.Forms.TextBox RebateBox;
        private System.Windows.Forms.TextBox TenorBox;
        private System.Windows.Forms.TextBox StrikeBox;
        private System.Windows.Forms.TextBox VolatilityBox;
        private System.Windows.Forms.TextBox BarrierBox;
        private System.Windows.Forms.Button InstruButton;
        private System.Windows.Forms.RadioButton EquityRadio;
        private System.Windows.Forms.RadioButton LORadio;
        private System.Windows.Forms.RadioButton BORadio;
        private System.Windows.Forms.RadioButton DORadio;
        private System.Windows.Forms.RadioButton AORadio;
        private System.Windows.Forms.RadioButton EORadio;
        private System.Windows.Forms.RadioButton RORadio;
        private System.Windows.Forms.CheckBox KnockOutBox;
        private System.Windows.Forms.ErrorProvider ErrorProvider;
        private System.Windows.Forms.TextBox IDBox;
        private System.Windows.Forms.Label IDLabel;
        private System.Windows.Forms.Label UnderlyingIDL;
        private System.Windows.Forms.TextBox UnderlyingIDBox;
        private System.Windows.Forms.Button DeleteButton;
    }
}