﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_ZYC
{
    public partial class TradesForm : Form
    {
        bool AA { get; set; }
        bool BB { get; set; }
        bool CC { get; set; }
        Model1Container db { get; set; }

        public TradesForm()
        {
            InitializeComponent();

            db = new Model1Container();

            ErrorProvider.SetIconAlignment(PriceBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(PriceBox, 3);
            ErrorProvider.SetIconAlignment(QuantityBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(QuantityBox, 3);
            ErrorProvider.SetIconAlignment(InstruIDBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(InstruIDBox, 3);
            ErrorProvider.SetIconAlignment(TradeIDBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(TradeIDBox, 3);

            EquityRadio.Enabled = false;
            EORadio.Enabled = false;
            AORadio.Enabled = false;
            DORadio.Enabled = false;
            BORadio.Enabled = false;
            LORadio.Enabled = false;
            RORadio.Enabled = false;
            TradesButton.Enabled = false;
            AA = false;
            BB = false;
            CC = false;
            InstruIDBox.Enabled = false;
            DeleteButton.Enabled = false;
        }

        private void QuantityBox_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(QuantityBox.Text, out _))
            {
                ErrorProvider.SetError(QuantityBox, "Please enter a integer!");
                TradesButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(QuantityBox, string.Empty);
                AA = true;
                TradesButton.Enabled = AA && BB && CC;
            }
        }

        private void PriceBox_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(PriceBox.Text, out _) || Convert.ToDouble(PriceBox.Text) < 0)
            {
                ErrorProvider.SetError(PriceBox, "Please enter a positive number!");
                TradesButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(PriceBox, string.Empty);
                BB = true;
                TradesButton.Enabled = AA && BB && CC;
            }
        }

        private void IDBox_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(InstruIDBox.Text, out _) || Convert.ToInt32(InstruIDBox.Text) < 0)
            {
                ErrorProvider.SetError(InstruIDBox, "Please enter a integer!");
                TradesButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(InstruIDBox, string.Empty);
                CC = true;
                TradesButton.Enabled = AA && BB && CC;
            }
        }

        private void EquityRadio_CheckedChanged(object sender, EventArgs e)
        {
            InstruIDBox.Enabled = true;
        }

        private void EORadio_CheckedChanged(object sender, EventArgs e)
        {

            InstruIDBox.Enabled = true;
        }

        private void AORadio_CheckedChanged(object sender, EventArgs e)
        {
            InstruIDBox.Enabled = true;
        }

        private void DORadio_CheckedChanged(object sender, EventArgs e)
        {
            InstruIDBox.Enabled = true;
        }

        private void BORadio_CheckedChanged(object sender, EventArgs e)
        {
            InstruIDBox.Enabled = true;
        }

        private void LORadio_CheckedChanged(object sender, EventArgs e)
        {
            InstruIDBox.Enabled = true;
        }

        private void RORadio_CheckedChanged(object sender, EventArgs e)
        {
            InstruIDBox.Enabled = true;
        }

        private void TradeIDBox_TextChanged(object sender, EventArgs e)
        {

            if (!int.TryParse(TradeIDBox.Text, out _) || Convert.ToInt32(TradeIDBox.Text) < 0)
            {
                ErrorProvider.SetError(TradeIDBox, "Please enter a positive integer!");
                TradesButton.Enabled = false;

            }
            else
            {
                ErrorProvider.SetError(TradeIDBox, string.Empty);
                if (Convert.ToInt32(TradeIDBox.Text) == 0)
                {
                    EquityRadio.Enabled = true;
                    EORadio.Enabled = true;
                    AORadio.Enabled = true;
                    DORadio.Enabled = true;
                    BORadio.Enabled = true;
                    LORadio.Enabled = true;
                    RORadio.Enabled = true;
                    TradesButton.Enabled = AA && BB && CC;
                    DeleteButton.Enabled = false;
                }

                else
                {
                    DeleteButton.Enabled = true;
                    EquityRadio.Enabled = true;
                    EORadio.Enabled = true;
                    AORadio.Enabled = true;
                    DORadio.Enabled = true;
                    BORadio.Enabled = true;
                    LORadio.Enabled = true;
                    RORadio.Enabled = true;
                    TradesButton.Enabled = AA && BB && CC;
                    DeleteButton.Enabled = true;
                }
            }
        }
        private void DeleteButton_Click(object sender, EventArgs e)
        {

        }

        private void TradesButton_Click(object sender, EventArgs e)
        {
            TradesButton.Enabled = false;

            if(TradeIDBox.Text == "0")
            {
                if (EquityRadio.Checked)
                {
                    db.Trades.Add(new Trade()
                    {
                        Quantity = Convert.ToInt32(QuantityBox.Text),
                        Price = Convert.ToDouble(PriceBox.Text),
                        EquityId = Convert.ToInt32(InstruIDBox.Text)
                    });
                }
                else if (EORadio.Checked)
                {
                    db.Trades.Add(new Trade()
                    {
                        Quantity = Convert.ToInt32(QuantityBox.Text),
                        Price = Convert.ToDouble(PriceBox.Text),
                        EuropeanOptionId = Convert.ToInt32(InstruIDBox.Text)
                    });
                }
                else if (AORadio.Checked)
                {
                    db.Trades.Add(new Trade()
                    {
                        Quantity = Convert.ToInt32(QuantityBox.Text),
                        Price = Convert.ToDouble(PriceBox.Text),
                        AsianOptionId = Convert.ToInt32(InstruIDBox.Text)
                    });
                }
                else if (DORadio.Checked)
                {
                    db.Trades.Add(new Trade()
                    {
                        Quantity = Convert.ToInt32(QuantityBox.Text),
                        Price = Convert.ToDouble(PriceBox.Text),
                        DigitalOptionId = Convert.ToInt32(InstruIDBox.Text)
                    });
                }
                else if (BORadio.Checked)
                {
                    db.Trades.Add(new Trade()
                    {
                        Quantity = Convert.ToInt32(QuantityBox.Text),
                        Price = Convert.ToDouble(PriceBox.Text),
                        BarrierOptionId = Convert.ToInt32(InstruIDBox.Text)
                    });
                }
                else if (LORadio.Checked)
                {
                    db.Trades.Add(new Trade()
                    {
                        Quantity = Convert.ToInt32(QuantityBox.Text),
                        Price = Convert.ToDouble(PriceBox.Text),
                        LookbackOptionId = Convert.ToInt32(InstruIDBox.Text)
                    });
                }
                else
                {
                    db.Trades.Add(new Trade()
                    {
                        Quantity = Convert.ToInt32(QuantityBox.Text),
                        Price = Convert.ToDouble(PriceBox.Text),
                        RangeOptionId = Convert.ToInt32(InstruIDBox.Text)
                    });
                }
            }
            else
            {
                db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).Price = Convert.ToDouble(PriceBox.Text);
                db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).Quantity = Convert.ToInt32(QuantityBox.Text);

                if (EquityRadio.Checked)
                {
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EuropeanOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).AsianOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).DigitalOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).BarrierOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).LookbackOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).RangeOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EquityId = Convert.ToInt32(InstruIDBox.Text);
                }
                else if (EORadio.Checked)
                {
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EquityId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).AsianOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).DigitalOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).BarrierOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).LookbackOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).RangeOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EuropeanOptionId = Convert.ToInt32(InstruIDBox.Text);
                }
                else if (AORadio.Checked)
                {
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EquityId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EuropeanOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).DigitalOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).BarrierOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).LookbackOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).RangeOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).AsianOptionId = Convert.ToInt32(InstruIDBox.Text);
                }
                else if (DORadio.Checked)
                {
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EquityId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EuropeanOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).AsianOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).BarrierOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).LookbackOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).RangeOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).DigitalOptionId = Convert.ToInt32(InstruIDBox.Text);
                }
                else if (BORadio.Checked)
                {
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EquityId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EuropeanOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).AsianOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).DigitalOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).LookbackOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).RangeOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).BarrierOptionId = Convert.ToInt32(InstruIDBox.Text);
                }
                else if (LORadio.Checked)
                {
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EquityId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EuropeanOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).AsianOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).DigitalOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).BarrierOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).RangeOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).LookbackOptionId = Convert.ToInt32(InstruIDBox.Text);
                }
                else
                {
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EquityId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).EuropeanOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).AsianOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).DigitalOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).BarrierOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).LookbackOptionId = null;
                    db.Trades.FirstOrDefault(x => x.Id == Convert.ToInt32(TradeIDBox.Text)).RangeOptionId = Convert.ToInt32(InstruIDBox.Text);
                }
            }

            db.SaveChanges();
            TradesButton.Enabled = true;
        }

    }
}
