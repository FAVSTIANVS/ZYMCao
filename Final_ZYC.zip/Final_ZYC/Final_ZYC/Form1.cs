﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_ZYC
{
    public partial class PortfolioManager : Form
    {
        Model1Container db { get; set; }
        bool ttrial { get; set; }
        bool rrate { get; set; }
        bool sstep { get; set; }
        bool sspecific { get; set; }

        public PortfolioManager()
        {
            InitializeComponent();

            ErrorProvider.SetIconAlignment(TrialsBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(TrialsBox, 3);
            ErrorProvider.SetIconAlignment(StepsBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(StepsBox, 3);
            ErrorProvider.SetIconAlignment(RateBox, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(RateBox, 3);
            rrate = false;
            ttrial = false;
            sstep = false;
            sspecific = false;
            FaureBox.Enabled = false;

            RNGButton.Enabled = false;
            db = new Model1Container();
        }

        private void InstruMenu_Click(object sender, EventArgs e)
        {
            InstruInputForm InstrumentInstantiation = new InstruInputForm();
            InstrumentInstantiation.ShowDialog();
        }

        private void HistPricesMenu_Click(object sender, EventArgs e)
        {
            HistlPricesForm HistoricalPrices = new HistlPricesForm();
            HistoricalPrices.ShowDialog();
        }

        private void TradesMenu_Click(object sender, EventArgs e)
        {
            TradesForm Trades = new TradesForm();
            Trades.ShowDialog();
        }

        private void PortfolioManager_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'fRamseyDataSet.Trades' table. You can move, or remove it, as needed.
            this.tradesTableAdapter.Fill(this.fRamseyDataSet.Trades);
        }

        private void StepsBox_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(StepsBox.Text, out _) || Convert.ToInt32(StepsBox.Text) < 0)
            {
                ErrorProvider.SetError(StepsBox, "Please enter a positive integer!");
                RNGButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(StepsBox, string.Empty);
                sstep = true;
                RNGButton.Enabled = rrate && sstep && ttrial && sspecific;
            }
        }

        private void RateBox_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(RateBox.Text, out _))
            {
                ErrorProvider.SetError(RateBox, "Please enter a double!");
                RNGButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(RateBox, string.Empty);
                rrate = true;
                RNGButton.Enabled = rrate && sstep && ttrial && sspecific;
            }
        }

        private void TrialsBox_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(TrialsBox.Text, out _) || Convert.ToInt32(TrialsBox.Text) < 0)
            {
                ErrorProvider.SetError(TrialsBox, "Please enter a positive integer!");
                RNGButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(TrialsBox, string.Empty);
                ttrial = true;
                RNGButton.Enabled = rrate && sstep && ttrial && sspecific;
            }
        }

        private void SpecificIDL_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(SpecificIDL.Text, out _) || Convert.ToInt32(SpecificIDL.Text) < 0)
            {
                ErrorProvider.SetError(SpecificIDL, "Please enter a positive integer!");
                RNGButton.Enabled = false;
            }
            else
            {
                ErrorProvider.SetError(SpecificIDL, string.Empty);
                sspecific = true;
                RNGButton.Enabled = rrate && sstep && ttrial && sspecific;
            }
        }

        private void RNGButton_Click(object sender, EventArgs e)
        {
            int m = Convert.ToInt32(TrialsBox.Text) * 100;
            int n = Convert.ToInt32(StepsBox.Text) * 100;
            double[][] RNs = MMA.StdNormalRNGMatrix(m, n, AntitheticBox.Checked, MMA.StdBoxMuller, CVBox.Checked);
            double r = Convert.ToDouble(RateBox.Text);

            double OATradePrice = 0, OAMarkPrice = 0, OADelta = 0, OAGamma = 0, OARho = 0, OATheta = 0, OAVega = 0;

            foreach(var x in db.Trades)
            {
                OATradePrice = OATradePrice + x.Price * x.Quantity;
                if (x.EquityId != null)
                {
                    DateTime LastT = db.HistPrices.Where(y => y.EquityId == x.EquityId).Select(y => y.Date).Max();
                    OAMarkPrice = OAMarkPrice + db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price * x.Quantity;
                    OADelta = OADelta + x.Quantity;
                }
                else if(x.AsianOptionId != null) 
                {
                    AsianOption Z = db.AsianOptions.FirstOrDefault(y => y.Id == x.AsianOptionId);
                    DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                    Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                    Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                    OAMarkPrice = OAMarkPrice + Z.MCPrice(r, RNs, CVBox.Checked) * x.Quantity;
                    OADelta = OADelta + Z.MCDelta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAGamma = OAGamma + Z.MCGamma(r, RNs, CVBox.Checked) * x.Quantity;
                    OARho = OARho + Z.MCRho(r, RNs, CVBox.Checked) * x.Quantity;
                    OATheta = OATheta + Z.MCTheta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAVega = OAVega + Z.MCVega(r, RNs, CVBox.Checked) * x.Quantity;
                }
                else if(x.BarrierOptionId != null)
                {
                    BarrierOption Z = db.BarrierOptions.FirstOrDefault(y => y.Id == x.BarrierOptionId);
                    DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                    Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                    Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                    OAMarkPrice = OAMarkPrice + Z.MCPrice(r, RNs, CVBox.Checked) * x.Quantity;
                    OADelta = OADelta + Z.MCDelta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAGamma = OAGamma + Z.MCGamma(r, RNs, CVBox.Checked) * x.Quantity;
                    OARho = OARho + Z.MCRho(r, RNs, CVBox.Checked) * x.Quantity;
                    OATheta = OATheta + Z.MCTheta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAVega = OAVega + Z.MCVega(r, RNs, CVBox.Checked) * x.Quantity;
                }
                else if(x.DigitalOptionId != null)
                {
                    DigitalOption Z = db.DigitalOptions.FirstOrDefault(y => y.Id == x.DigitalOptionId);
                    DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                    Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                    Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                    OAMarkPrice = OAMarkPrice + Z.MCPrice(r, RNs, CVBox.Checked) * x.Quantity;
                    OADelta = OADelta + Z.MCDelta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAGamma = OAGamma + Z.MCGamma(r, RNs, CVBox.Checked) * x.Quantity;
                    OARho = OARho + Z.MCRho(r, RNs, CVBox.Checked) * x.Quantity;
                    OATheta = OATheta + Z.MCTheta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAVega = OAVega + Z.MCVega(r, RNs, CVBox.Checked) * x.Quantity;
                }
                else if(x.EuropeanOptionId != null)
                {
                    EuropeanOption Z = db.EuropeanOptions.FirstOrDefault(y => y.Id == x.EuropeanOptionId);
                    DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                    Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                    Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                    OAMarkPrice = OAMarkPrice + Z.MCPrice(r, RNs, CVBox.Checked) * x.Quantity;
                    OADelta = OADelta + Z.MCDelta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAGamma = OAGamma + Z.MCGamma(r, RNs, CVBox.Checked) * x.Quantity;
                    OARho = OARho + Z.MCRho(r, RNs, CVBox.Checked) * x.Quantity;
                    OATheta = OATheta + Z.MCTheta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAVega = OAVega + Z.MCVega(r, RNs, CVBox.Checked) * x.Quantity;
                }
                else if(x.RangeOptionId != null)
                {
                    RangeOption Z = db.RangeOptions.FirstOrDefault(y => y.Id == x.RangeOptionId);
                    DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                    Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                    Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                    OAMarkPrice = OAMarkPrice + Z.MCPrice(r, RNs, CVBox.Checked) * x.Quantity;
                    OADelta = OADelta + Z.MCDelta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAGamma = OAGamma + Z.MCGamma(r, RNs, CVBox.Checked) * x.Quantity;
                    OARho = OARho + Z.MCRho(r, RNs, CVBox.Checked) * x.Quantity;
                    OATheta = OATheta + Z.MCTheta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAVega = OAVega + Z.MCVega(r, RNs, CVBox.Checked) * x.Quantity;
                }
                else if(x.LookbackOptionId != null)
                {
                    LookbackOption Z = db.LookbackOptions.FirstOrDefault(y => y.Id == x.LookbackOptionId);
                    DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                    Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                    Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                    OAMarkPrice = OAMarkPrice + Z.MCPrice(r, RNs, CVBox.Checked) * x.Quantity;
                    OADelta = OADelta + Z.MCDelta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAGamma = OAGamma + Z.MCGamma(r, RNs, CVBox.Checked) * x.Quantity;
                    OARho = OARho + Z.MCRho(r, RNs, CVBox.Checked) * x.Quantity;
                    OATheta = OATheta + Z.MCTheta(r, RNs, CVBox.Checked) * x.Quantity;
                    OAVega = OAVega + Z.MCVega(r, RNs, CVBox.Checked) * x.Quantity;
                }
            }

            TradePriceOA.Text = Convert.ToString(OATradePrice);
            MarkPriceOA.Text = Convert.ToString(OAMarkPrice);
            PandLOA.Text = Convert.ToString(OAMarkPrice - OATradePrice);
            DeltaOA.Text = Convert.ToString(OADelta);
            GammaOA.Text = Convert.ToString(OAGamma);
            RhoOA.Text = Convert.ToString(OARho);
            ThetaOA.Text = Convert.ToString(OATheta);
            VegaOA.Text = Convert.ToString(OAVega);


            int ParticularID = Convert.ToInt32(SpecificIDL.Text);

            double OSTradePrice = 0, OSMarkPrice = 0, OSDelta = 0, OSGamma = 0, OSRho = 0, OSTheta = 0, OSVega = 0;

            var u = db.Trades.FirstOrDefault(x => x.Id == ParticularID);
            OSTradePrice = u.Price * u.Quantity;
            if (u.EquityId != null)
            {
                DateTime LastT;
                LastT = db.HistPrices.Where(y => y.EquityId == u.EquityId).Select(y => y.Date).Max();
                OSMarkPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price * u.Quantity;
                OSDelta = u.Quantity;
            }
            else if (u.AsianOptionId != null)
            {
                AsianOption Z = db.AsianOptions.FirstOrDefault(y => y.Id == u.AsianOptionId);
                DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                OSMarkPrice = Z.MCPrice(r, RNs, CVBox.Checked) * u.Quantity;
                OSDelta = Z.MCDelta(r, RNs, CVBox.Checked) * u.Quantity;
                OSGamma = Z.MCGamma(r, RNs, CVBox.Checked) * u.Quantity;
                OSRho = Z.MCRho(r, RNs, CVBox.Checked) * u.Quantity;
                OSTheta = Z.MCTheta(r, RNs, CVBox.Checked) * u.Quantity;
                OSVega = Z.MCVega(r, RNs, CVBox.Checked) * u.Quantity;
            }
            else if (u.BarrierOptionId != null)
            {
                BarrierOption Z = db.BarrierOptions.FirstOrDefault(y => y.Id == u.BarrierOptionId);
                DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                OSMarkPrice = Z.MCPrice(r, RNs, CVBox.Checked) * u.Quantity;
                OSDelta = Z.MCDelta(r, RNs, CVBox.Checked) * u.Quantity;
                OSGamma = Z.MCGamma(r, RNs, CVBox.Checked) * u.Quantity;
                OSRho = Z.MCRho(r, RNs, CVBox.Checked) * u.Quantity;
                OSTheta = Z.MCTheta(r, RNs, CVBox.Checked) * u.Quantity;
                OSVega = Z.MCVega(r, RNs, CVBox.Checked) * u.Quantity;
            }
            else if (u.DigitalOptionId != null)
            {
                DigitalOption Z = db.DigitalOptions.FirstOrDefault(y => y.Id == u.DigitalOptionId);
                DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                OSMarkPrice = Z.MCPrice(r, RNs, CVBox.Checked) * u.Quantity;
                OSDelta = Z.MCDelta(r, RNs, CVBox.Checked) * u.Quantity;
                OSGamma = Z.MCGamma(r, RNs, CVBox.Checked) * u.Quantity;
                OSRho = Z.MCRho(r, RNs, CVBox.Checked) * u.Quantity;
                OSTheta = Z.MCTheta(r, RNs, CVBox.Checked) * u.Quantity;
                OSVega = Z.MCVega(r, RNs, CVBox.Checked) * u.Quantity;
            }
            else if (u.EuropeanOptionId != null)
            {
                EuropeanOption Z = db.EuropeanOptions.FirstOrDefault(y => y.Id == u.EuropeanOptionId);
                DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                OSMarkPrice = Z.MCPrice(r, RNs, CVBox.Checked) * u.Quantity;
                OSDelta = Z.MCDelta(r, RNs, CVBox.Checked) * u.Quantity;
                OSGamma = Z.MCGamma(r, RNs, CVBox.Checked) * u.Quantity;
                OSRho = Z.MCRho(r, RNs, CVBox.Checked) * u.Quantity;
                OSTheta = Z.MCTheta(r, RNs, CVBox.Checked) * u.Quantity;
                OSVega = Z.MCVega(r, RNs, CVBox.Checked) * u.Quantity;
            }
            else if (u.RangeOptionId != null)
            {
                RangeOption Z = db.RangeOptions.FirstOrDefault(y => y.Id == u.RangeOptionId);
                DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                OSMarkPrice = Z.MCPrice(r, RNs, CVBox.Checked) * u.Quantity;
                OSDelta = Z.MCDelta(r, RNs, CVBox.Checked) * u.Quantity;
                OSGamma = Z.MCGamma(r, RNs, CVBox.Checked) * u.Quantity;
                OSRho = Z.MCRho(r, RNs, CVBox.Checked) * u.Quantity;
                OSTheta = Z.MCTheta(r, RNs, CVBox.Checked) * u.Quantity;
                OSVega = Z.MCVega(r, RNs, CVBox.Checked) * u.Quantity;
            }
            else if (u.LookbackOptionId != null)
            {
                LookbackOption Z = db.LookbackOptions.FirstOrDefault(y => y.Id == u.LookbackOptionId);
                DateTime LastT = db.HistPrices.Where(y => y.EquityId == Z.EquityId).Select(y => y.Date).Max();
                Z.uPrice = db.HistPrices.FirstOrDefault(y => y.Date == LastT).Price;
                Z.uVol = db.Equities.FirstOrDefault(y => y.Id == Z.EquityId).Volatility;
                OSMarkPrice = Z.MCPrice(r, RNs, CVBox.Checked) * u.Quantity;
                OSDelta = Z.MCDelta(r, RNs, CVBox.Checked) * u.Quantity;
                OSGamma = Z.MCGamma(r, RNs, CVBox.Checked) * u.Quantity;
                OSRho = Z.MCRho(r, RNs, CVBox.Checked) * u.Quantity;
                OSTheta = Z.MCTheta(r, RNs, CVBox.Checked) * u.Quantity;
                OSVega = Z.MCVega(r, RNs, CVBox.Checked) * u.Quantity;
            }


            TradePriceOS.Text = Convert.ToString(OSTradePrice);
            MarkPriceOS.Text = Convert.ToString(OSMarkPrice);
            PandLOS.Text = Convert.ToString(OSMarkPrice - OSTradePrice);
            DeltaOS.Text = Convert.ToString(OSDelta);
            GammaOS.Text = Convert.ToString(OSGamma);
            RhoOS.Text = Convert.ToString(OSRho);
            ThetaOS.Text = Convert.ToString(OSTheta);
            VegaOS.Text = Convert.ToString(OSVega);

        }

    }
}
