﻿namespace Final_ZYC
{
    partial class PortfolioManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Menu = new System.Windows.Forms.MenuStrip();
            this.InstruMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.HistPricesMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.TradesMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.PandLPannel = new System.Windows.Forms.Panel();
            this.InstruPanel = new System.Windows.Forms.Panel();
            this.SpecificPanel = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.fRamseyDataSet = new Final_ZYC.FRamseyDataSet();
            this.tradesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tradesTableAdapter = new Final_ZYC.FRamseyDataSetTableAdapters.TradesTableAdapter();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equityIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.asianOptionIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.barrierOptionIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.digitalOptionIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.europeanOptionIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rangeOptionIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lookbackOptionIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deltaL = new System.Windows.Forms.Label();
            this.RateL = new System.Windows.Forms.Label();
            this.VegaL = new System.Windows.Forms.Label();
            this.ThetaL = new System.Windows.Forms.Label();
            this.RhoL = new System.Windows.Forms.Label();
            this.GammaL = new System.Windows.Forms.Label();
            this.StepsL = new System.Windows.Forms.Label();
            this.TrialsL = new System.Windows.Forms.Label();
            this.AntitheticBox = new System.Windows.Forms.CheckBox();
            this.CVBox = new System.Windows.Forms.CheckBox();
            this.FaureBox = new System.Windows.Forms.CheckBox();
            this.RateBox = new System.Windows.Forms.TextBox();
            this.StepsBox = new System.Windows.Forms.TextBox();
            this.TrialsBox = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.RNGButton = new System.Windows.Forms.Button();
            this.ErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.TradePriceL = new System.Windows.Forms.Label();
            this.MarkPriceL = new System.Windows.Forms.Label();
            this.PandLL = new System.Windows.Forms.Label();
            this.PortfolioL = new System.Windows.Forms.Label();
            this.TradeIDL = new System.Windows.Forms.Label();
            this.SpecificIDL = new System.Windows.Forms.TextBox();
            this.TradePriceOA = new System.Windows.Forms.Label();
            this.MarkPriceOA = new System.Windows.Forms.Label();
            this.PandLOA = new System.Windows.Forms.Label();
            this.DeltaOA = new System.Windows.Forms.Label();
            this.GammaOA = new System.Windows.Forms.Label();
            this.RhoOA = new System.Windows.Forms.Label();
            this.ThetaOA = new System.Windows.Forms.Label();
            this.VegaOA = new System.Windows.Forms.Label();
            this.VegaOS = new System.Windows.Forms.Label();
            this.ThetaOS = new System.Windows.Forms.Label();
            this.RhoOS = new System.Windows.Forms.Label();
            this.GammaOS = new System.Windows.Forms.Label();
            this.DeltaOS = new System.Windows.Forms.Label();
            this.PandLOS = new System.Windows.Forms.Label();
            this.MarkPriceOS = new System.Windows.Forms.Label();
            this.TradePriceOS = new System.Windows.Forms.Label();
            this.Menu.SuspendLayout();
            this.PandLPannel.SuspendLayout();
            this.InstruPanel.SuspendLayout();
            this.SpecificPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fRamseyDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tradesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // Menu
            // 
            this.Menu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.InstruMenu,
            this.HistPricesMenu,
            this.TradesMenu});
            this.Menu.Location = new System.Drawing.Point(0, 0);
            this.Menu.Name = "Menu";
            this.Menu.Size = new System.Drawing.Size(1144, 30);
            this.Menu.TabIndex = 0;
            this.Menu.Text = "menuStrip1";
            // 
            // InstruMenu
            // 
            this.InstruMenu.Name = "InstruMenu";
            this.InstruMenu.Size = new System.Drawing.Size(179, 26);
            this.InstruMenu.Text = "Instrument Instantiation";
            this.InstruMenu.Click += new System.EventHandler(this.InstruMenu_Click);
            // 
            // HistPricesMenu
            // 
            this.HistPricesMenu.Name = "HistPricesMenu";
            this.HistPricesMenu.Size = new System.Drawing.Size(128, 26);
            this.HistPricesMenu.Text = "Historical Prices";
            this.HistPricesMenu.Click += new System.EventHandler(this.HistPricesMenu_Click);
            // 
            // TradesMenu
            // 
            this.TradesMenu.Name = "TradesMenu";
            this.TradesMenu.Size = new System.Drawing.Size(66, 26);
            this.TradesMenu.Text = "Trades";
            this.TradesMenu.Click += new System.EventHandler(this.TradesMenu_Click);
            // 
            // PandLPannel
            // 
            this.PandLPannel.Controls.Add(this.TrialsBox);
            this.PandLPannel.Controls.Add(this.StepsBox);
            this.PandLPannel.Controls.Add(this.RateBox);
            this.PandLPannel.Controls.Add(this.FaureBox);
            this.PandLPannel.Controls.Add(this.CVBox);
            this.PandLPannel.Controls.Add(this.AntitheticBox);
            this.PandLPannel.Controls.Add(this.TrialsL);
            this.PandLPannel.Controls.Add(this.StepsL);
            this.PandLPannel.Controls.Add(this.RateL);
            this.PandLPannel.Dock = System.Windows.Forms.DockStyle.Top;
            this.PandLPannel.Location = new System.Drawing.Point(0, 30);
            this.PandLPannel.Name = "PandLPannel";
            this.PandLPannel.Size = new System.Drawing.Size(1144, 91);
            this.PandLPannel.TabIndex = 1;
            // 
            // InstruPanel
            // 
            this.InstruPanel.Controls.Add(this.dataGridView1);
            this.InstruPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.InstruPanel.Location = new System.Drawing.Point(0, 380);
            this.InstruPanel.Name = "InstruPanel";
            this.InstruPanel.Size = new System.Drawing.Size(1144, 267);
            this.InstruPanel.TabIndex = 2;
            // 
            // SpecificPanel
            // 
            this.SpecificPanel.Controls.Add(this.VegaOS);
            this.SpecificPanel.Controls.Add(this.ThetaOS);
            this.SpecificPanel.Controls.Add(this.RhoOS);
            this.SpecificPanel.Controls.Add(this.GammaOS);
            this.SpecificPanel.Controls.Add(this.DeltaOS);
            this.SpecificPanel.Controls.Add(this.PandLOS);
            this.SpecificPanel.Controls.Add(this.MarkPriceOS);
            this.SpecificPanel.Controls.Add(this.TradePriceOS);
            this.SpecificPanel.Controls.Add(this.VegaOA);
            this.SpecificPanel.Controls.Add(this.ThetaOA);
            this.SpecificPanel.Controls.Add(this.RhoOA);
            this.SpecificPanel.Controls.Add(this.GammaOA);
            this.SpecificPanel.Controls.Add(this.DeltaOA);
            this.SpecificPanel.Controls.Add(this.PandLOA);
            this.SpecificPanel.Controls.Add(this.MarkPriceOA);
            this.SpecificPanel.Controls.Add(this.TradePriceOA);
            this.SpecificPanel.Controls.Add(this.RNGButton);
            this.SpecificPanel.Controls.Add(this.SpecificIDL);
            this.SpecificPanel.Controls.Add(this.TradeIDL);
            this.SpecificPanel.Controls.Add(this.PortfolioL);
            this.SpecificPanel.Controls.Add(this.PandLL);
            this.SpecificPanel.Controls.Add(this.MarkPriceL);
            this.SpecificPanel.Controls.Add(this.TradePriceL);
            this.SpecificPanel.Controls.Add(this.GammaL);
            this.SpecificPanel.Controls.Add(this.deltaL);
            this.SpecificPanel.Controls.Add(this.VegaL);
            this.SpecificPanel.Controls.Add(this.RhoL);
            this.SpecificPanel.Controls.Add(this.ThetaL);
            this.SpecificPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SpecificPanel.Location = new System.Drawing.Point(0, 121);
            this.SpecificPanel.Name = "SpecificPanel";
            this.SpecificPanel.Size = new System.Drawing.Size(1144, 259);
            this.SpecificPanel.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.equityIdDataGridViewTextBoxColumn,
            this.asianOptionIdDataGridViewTextBoxColumn,
            this.barrierOptionIdDataGridViewTextBoxColumn,
            this.digitalOptionIdDataGridViewTextBoxColumn,
            this.europeanOptionIdDataGridViewTextBoxColumn,
            this.rangeOptionIdDataGridViewTextBoxColumn,
            this.lookbackOptionIdDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tradesBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1144, 267);
            this.dataGridView1.TabIndex = 0;
            // 
            // fRamseyDataSet
            // 
            this.fRamseyDataSet.DataSetName = "FRamseyDataSet";
            this.fRamseyDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tradesBindingSource
            // 
            this.tradesBindingSource.DataMember = "Trades";
            this.tradesBindingSource.DataSource = this.fRamseyDataSet;
            // 
            // tradesTableAdapter
            // 
            this.tradesTableAdapter.ClearBeforeFill = true;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 125;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.Width = 125;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.Width = 125;
            // 
            // equityIdDataGridViewTextBoxColumn
            // 
            this.equityIdDataGridViewTextBoxColumn.DataPropertyName = "EquityId";
            this.equityIdDataGridViewTextBoxColumn.HeaderText = "EquityId";
            this.equityIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.equityIdDataGridViewTextBoxColumn.Name = "equityIdDataGridViewTextBoxColumn";
            this.equityIdDataGridViewTextBoxColumn.Width = 125;
            // 
            // asianOptionIdDataGridViewTextBoxColumn
            // 
            this.asianOptionIdDataGridViewTextBoxColumn.DataPropertyName = "AsianOptionId";
            this.asianOptionIdDataGridViewTextBoxColumn.HeaderText = "AsianOptionId";
            this.asianOptionIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.asianOptionIdDataGridViewTextBoxColumn.Name = "asianOptionIdDataGridViewTextBoxColumn";
            this.asianOptionIdDataGridViewTextBoxColumn.Width = 125;
            // 
            // barrierOptionIdDataGridViewTextBoxColumn
            // 
            this.barrierOptionIdDataGridViewTextBoxColumn.DataPropertyName = "BarrierOptionId";
            this.barrierOptionIdDataGridViewTextBoxColumn.HeaderText = "BarrierOptionId";
            this.barrierOptionIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.barrierOptionIdDataGridViewTextBoxColumn.Name = "barrierOptionIdDataGridViewTextBoxColumn";
            this.barrierOptionIdDataGridViewTextBoxColumn.Width = 125;
            // 
            // digitalOptionIdDataGridViewTextBoxColumn
            // 
            this.digitalOptionIdDataGridViewTextBoxColumn.DataPropertyName = "DigitalOptionId";
            this.digitalOptionIdDataGridViewTextBoxColumn.HeaderText = "DigitalOptionId";
            this.digitalOptionIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.digitalOptionIdDataGridViewTextBoxColumn.Name = "digitalOptionIdDataGridViewTextBoxColumn";
            this.digitalOptionIdDataGridViewTextBoxColumn.Width = 125;
            // 
            // europeanOptionIdDataGridViewTextBoxColumn
            // 
            this.europeanOptionIdDataGridViewTextBoxColumn.DataPropertyName = "EuropeanOptionId";
            this.europeanOptionIdDataGridViewTextBoxColumn.HeaderText = "EuropeanOptionId";
            this.europeanOptionIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.europeanOptionIdDataGridViewTextBoxColumn.Name = "europeanOptionIdDataGridViewTextBoxColumn";
            this.europeanOptionIdDataGridViewTextBoxColumn.Width = 125;
            // 
            // rangeOptionIdDataGridViewTextBoxColumn
            // 
            this.rangeOptionIdDataGridViewTextBoxColumn.DataPropertyName = "RangeOptionId";
            this.rangeOptionIdDataGridViewTextBoxColumn.HeaderText = "RangeOptionId";
            this.rangeOptionIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.rangeOptionIdDataGridViewTextBoxColumn.Name = "rangeOptionIdDataGridViewTextBoxColumn";
            this.rangeOptionIdDataGridViewTextBoxColumn.Width = 125;
            // 
            // lookbackOptionIdDataGridViewTextBoxColumn
            // 
            this.lookbackOptionIdDataGridViewTextBoxColumn.DataPropertyName = "LookbackOptionId";
            this.lookbackOptionIdDataGridViewTextBoxColumn.HeaderText = "LookbackOptionId";
            this.lookbackOptionIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lookbackOptionIdDataGridViewTextBoxColumn.Name = "lookbackOptionIdDataGridViewTextBoxColumn";
            this.lookbackOptionIdDataGridViewTextBoxColumn.Width = 125;
            // 
            // deltaL
            // 
            this.deltaL.AutoSize = true;
            this.deltaL.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deltaL.Location = new System.Drawing.Point(720, 30);
            this.deltaL.Name = "deltaL";
            this.deltaL.Size = new System.Drawing.Size(56, 26);
            this.deltaL.TabIndex = 0;
            this.deltaL.Text = "Delta";
            // 
            // RateL
            // 
            this.RateL.AutoSize = true;
            this.RateL.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RateL.Location = new System.Drawing.Point(19, 17);
            this.RateL.Name = "RateL";
            this.RateL.Size = new System.Drawing.Size(117, 23);
            this.RateL.TabIndex = 1;
            this.RateL.Text = "Risk Free Rate";
            // 
            // VegaL
            // 
            this.VegaL.AutoSize = true;
            this.VegaL.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VegaL.Location = new System.Drawing.Point(1040, 30);
            this.VegaL.Name = "VegaL";
            this.VegaL.Size = new System.Drawing.Size(53, 26);
            this.VegaL.TabIndex = 2;
            this.VegaL.Text = "Vega";
            // 
            // ThetaL
            // 
            this.ThetaL.AutoSize = true;
            this.ThetaL.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThetaL.Location = new System.Drawing.Point(960, 30);
            this.ThetaL.Name = "ThetaL";
            this.ThetaL.Size = new System.Drawing.Size(60, 26);
            this.ThetaL.TabIndex = 3;
            this.ThetaL.Text = "Theta";
            // 
            // RhoL
            // 
            this.RhoL.AutoSize = true;
            this.RhoL.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RhoL.Location = new System.Drawing.Point(880, 30);
            this.RhoL.Name = "RhoL";
            this.RhoL.Size = new System.Drawing.Size(46, 26);
            this.RhoL.TabIndex = 4;
            this.RhoL.Text = "Rho";
            // 
            // GammaL
            // 
            this.GammaL.AutoSize = true;
            this.GammaL.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GammaL.Location = new System.Drawing.Point(800, 30);
            this.GammaL.Name = "GammaL";
            this.GammaL.Size = new System.Drawing.Size(78, 26);
            this.GammaL.TabIndex = 5;
            this.GammaL.Text = "Gamma";
            // 
            // StepsL
            // 
            this.StepsL.AutoSize = true;
            this.StepsL.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StepsL.Location = new System.Drawing.Point(319, 17);
            this.StepsL.Name = "StepsL";
            this.StepsL.Size = new System.Drawing.Size(142, 23);
            this.StepsL.TabIndex = 6;
            this.StepsL.Text = "Steps / Hundreds";
            // 
            // TrialsL
            // 
            this.TrialsL.AutoSize = true;
            this.TrialsL.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrialsL.Location = new System.Drawing.Point(169, 17);
            this.TrialsL.Name = "TrialsL";
            this.TrialsL.Size = new System.Drawing.Size(145, 23);
            this.TrialsL.TabIndex = 7;
            this.TrialsL.Text = "Trials / Hundreds";
            // 
            // AntitheticBox
            // 
            this.AntitheticBox.AutoSize = true;
            this.AntitheticBox.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AntitheticBox.Location = new System.Drawing.Point(604, 34);
            this.AntitheticBox.Name = "AntitheticBox";
            this.AntitheticBox.Size = new System.Drawing.Size(116, 30);
            this.AntitheticBox.TabIndex = 8;
            this.AntitheticBox.Text = "Antithetic";
            this.AntitheticBox.UseVisualStyleBackColor = true;
            // 
            // CVBox
            // 
            this.CVBox.AutoSize = true;
            this.CVBox.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CVBox.Location = new System.Drawing.Point(757, 34);
            this.CVBox.Name = "CVBox";
            this.CVBox.Size = new System.Drawing.Size(157, 30);
            this.CVBox.TabIndex = 9;
            this.CVBox.Text = "Control Variate";
            this.CVBox.UseVisualStyleBackColor = true;
            // 
            // FaureBox
            // 
            this.FaureBox.AutoSize = true;
            this.FaureBox.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FaureBox.Location = new System.Drawing.Point(945, 34);
            this.FaureBox.Name = "FaureBox";
            this.FaureBox.Size = new System.Drawing.Size(164, 30);
            this.FaureBox.TabIndex = 10;
            this.FaureBox.Text = "Faure Sequence";
            this.FaureBox.UseVisualStyleBackColor = true;
            // 
            // RateBox
            // 
            this.RateBox.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RateBox.Location = new System.Drawing.Point(23, 45);
            this.RateBox.Name = "RateBox";
            this.RateBox.Size = new System.Drawing.Size(100, 30);
            this.RateBox.TabIndex = 11;
            this.RateBox.TextChanged += new System.EventHandler(this.RateBox_TextChanged);
            // 
            // StepsBox
            // 
            this.StepsBox.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StepsBox.Location = new System.Drawing.Point(323, 45);
            this.StepsBox.Name = "StepsBox";
            this.StepsBox.Size = new System.Drawing.Size(100, 30);
            this.StepsBox.TabIndex = 12;
            this.StepsBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.StepsBox.TextChanged += new System.EventHandler(this.StepsBox_TextChanged);
            // 
            // TrialsBox
            // 
            this.TrialsBox.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrialsBox.Location = new System.Drawing.Point(173, 45);
            this.TrialsBox.Name = "TrialsBox";
            this.TrialsBox.Size = new System.Drawing.Size(100, 30);
            this.TrialsBox.TabIndex = 13;
            this.TrialsBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TrialsBox.TextChanged += new System.EventHandler(this.TrialsBox_TextChanged);
            // 
            // RNGButton
            // 
            this.RNGButton.Font = new System.Drawing.Font("Palatino Linotype", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RNGButton.Location = new System.Drawing.Point(853, 187);
            this.RNGButton.Name = "RNGButton";
            this.RNGButton.Size = new System.Drawing.Size(270, 53);
            this.RNGButton.TabIndex = 14;
            this.RNGButton.Text = "Let\'s GO!!";
            this.RNGButton.UseVisualStyleBackColor = true;
            this.RNGButton.Click += new System.EventHandler(this.RNGButton_Click);
            // 
            // ErrorProvider
            // 
            this.ErrorProvider.ContainerControl = this;
            // 
            // TradePriceL
            // 
            this.TradePriceL.AutoSize = true;
            this.TradePriceL.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TradePriceL.Location = new System.Drawing.Point(270, 30);
            this.TradePriceL.Name = "TradePriceL";
            this.TradePriceL.Size = new System.Drawing.Size(107, 26);
            this.TradePriceL.TabIndex = 6;
            this.TradePriceL.Text = "Trade Price";
            // 
            // MarkPriceL
            // 
            this.MarkPriceL.AutoSize = true;
            this.MarkPriceL.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MarkPriceL.Location = new System.Drawing.Point(400, 30);
            this.MarkPriceL.Name = "MarkPriceL";
            this.MarkPriceL.Size = new System.Drawing.Size(102, 26);
            this.MarkPriceL.TabIndex = 7;
            this.MarkPriceL.Text = "Mark Price";
            // 
            // PandLL
            // 
            this.PandLL.AutoSize = true;
            this.PandLL.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PandLL.Location = new System.Drawing.Point(535, 30);
            this.PandLL.Name = "PandLL";
            this.PandLL.Size = new System.Drawing.Size(137, 26);
            this.PandLL.TabIndex = 8;
            this.PandLL.Text = "Profit and Loss";
            // 
            // PortfolioL
            // 
            this.PortfolioL.AutoSize = true;
            this.PortfolioL.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PortfolioL.Location = new System.Drawing.Point(50, 80);
            this.PortfolioL.Name = "PortfolioL";
            this.PortfolioL.Size = new System.Drawing.Size(121, 26);
            this.PortfolioL.TabIndex = 9;
            this.PortfolioL.Text = "The Portfolio";
            // 
            // TradeIDL
            // 
            this.TradeIDL.AutoSize = true;
            this.TradeIDL.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TradeIDL.Location = new System.Drawing.Point(50, 30);
            this.TradeIDL.Name = "TradeIDL";
            this.TradeIDL.Size = new System.Drawing.Size(88, 26);
            this.TradeIDL.TabIndex = 10;
            this.TradeIDL.Text = "Trade ID";
            // 
            // SpecificIDL
            // 
            this.SpecificIDL.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpecificIDL.Location = new System.Drawing.Point(50, 130);
            this.SpecificIDL.Name = "SpecificIDL";
            this.SpecificIDL.Size = new System.Drawing.Size(116, 30);
            this.SpecificIDL.TabIndex = 15;
            this.SpecificIDL.TextChanged += new System.EventHandler(this.SpecificIDL_TextChanged);
            // 
            // TradePriceOA
            // 
            this.TradePriceOA.AutoSize = true;
            this.TradePriceOA.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TradePriceOA.Location = new System.Drawing.Point(270, 80);
            this.TradePriceOA.Name = "TradePriceOA";
            this.TradePriceOA.Size = new System.Drawing.Size(22, 26);
            this.TradePriceOA.TabIndex = 16;
            this.TradePriceOA.Text = "0";
            // 
            // MarkPriceOA
            // 
            this.MarkPriceOA.AutoSize = true;
            this.MarkPriceOA.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MarkPriceOA.Location = new System.Drawing.Point(400, 80);
            this.MarkPriceOA.Name = "MarkPriceOA";
            this.MarkPriceOA.Size = new System.Drawing.Size(22, 26);
            this.MarkPriceOA.TabIndex = 17;
            this.MarkPriceOA.Text = "0";
            // 
            // PandLOA
            // 
            this.PandLOA.AutoSize = true;
            this.PandLOA.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PandLOA.Location = new System.Drawing.Point(535, 80);
            this.PandLOA.Name = "PandLOA";
            this.PandLOA.Size = new System.Drawing.Size(22, 26);
            this.PandLOA.TabIndex = 18;
            this.PandLOA.Text = "0";
            // 
            // DeltaOA
            // 
            this.DeltaOA.AutoSize = true;
            this.DeltaOA.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeltaOA.Location = new System.Drawing.Point(720, 80);
            this.DeltaOA.Name = "DeltaOA";
            this.DeltaOA.Size = new System.Drawing.Size(22, 26);
            this.DeltaOA.TabIndex = 19;
            this.DeltaOA.Text = "0";
            // 
            // GammaOA
            // 
            this.GammaOA.AutoSize = true;
            this.GammaOA.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GammaOA.Location = new System.Drawing.Point(800, 80);
            this.GammaOA.Name = "GammaOA";
            this.GammaOA.Size = new System.Drawing.Size(22, 26);
            this.GammaOA.TabIndex = 20;
            this.GammaOA.Text = "0";
            // 
            // RhoOA
            // 
            this.RhoOA.AutoSize = true;
            this.RhoOA.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RhoOA.Location = new System.Drawing.Point(880, 80);
            this.RhoOA.Name = "RhoOA";
            this.RhoOA.Size = new System.Drawing.Size(22, 26);
            this.RhoOA.TabIndex = 21;
            this.RhoOA.Text = "0";
            // 
            // ThetaOA
            // 
            this.ThetaOA.AutoSize = true;
            this.ThetaOA.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThetaOA.Location = new System.Drawing.Point(960, 80);
            this.ThetaOA.Name = "ThetaOA";
            this.ThetaOA.Size = new System.Drawing.Size(22, 26);
            this.ThetaOA.TabIndex = 22;
            this.ThetaOA.Text = "0";
            // 
            // VegaOA
            // 
            this.VegaOA.AutoSize = true;
            this.VegaOA.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VegaOA.Location = new System.Drawing.Point(1040, 80);
            this.VegaOA.Name = "VegaOA";
            this.VegaOA.Size = new System.Drawing.Size(22, 26);
            this.VegaOA.TabIndex = 23;
            this.VegaOA.Text = "0";
            // 
            // VegaOS
            // 
            this.VegaOS.AutoSize = true;
            this.VegaOS.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VegaOS.Location = new System.Drawing.Point(1040, 132);
            this.VegaOS.Name = "VegaOS";
            this.VegaOS.Size = new System.Drawing.Size(22, 26);
            this.VegaOS.TabIndex = 31;
            this.VegaOS.Text = "0";
            // 
            // ThetaOS
            // 
            this.ThetaOS.AutoSize = true;
            this.ThetaOS.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThetaOS.Location = new System.Drawing.Point(960, 132);
            this.ThetaOS.Name = "ThetaOS";
            this.ThetaOS.Size = new System.Drawing.Size(22, 26);
            this.ThetaOS.TabIndex = 30;
            this.ThetaOS.Text = "0";
            // 
            // RhoOS
            // 
            this.RhoOS.AutoSize = true;
            this.RhoOS.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RhoOS.Location = new System.Drawing.Point(880, 132);
            this.RhoOS.Name = "RhoOS";
            this.RhoOS.Size = new System.Drawing.Size(22, 26);
            this.RhoOS.TabIndex = 29;
            this.RhoOS.Text = "0";
            // 
            // GammaOS
            // 
            this.GammaOS.AutoSize = true;
            this.GammaOS.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GammaOS.Location = new System.Drawing.Point(800, 132);
            this.GammaOS.Name = "GammaOS";
            this.GammaOS.Size = new System.Drawing.Size(22, 26);
            this.GammaOS.TabIndex = 28;
            this.GammaOS.Text = "0";
            // 
            // DeltaOS
            // 
            this.DeltaOS.AutoSize = true;
            this.DeltaOS.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeltaOS.Location = new System.Drawing.Point(720, 132);
            this.DeltaOS.Name = "DeltaOS";
            this.DeltaOS.Size = new System.Drawing.Size(22, 26);
            this.DeltaOS.TabIndex = 27;
            this.DeltaOS.Text = "0";
            // 
            // PandLOS
            // 
            this.PandLOS.AutoSize = true;
            this.PandLOS.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PandLOS.Location = new System.Drawing.Point(535, 132);
            this.PandLOS.Name = "PandLOS";
            this.PandLOS.Size = new System.Drawing.Size(22, 26);
            this.PandLOS.TabIndex = 26;
            this.PandLOS.Text = "0";
            // 
            // MarkPriceOS
            // 
            this.MarkPriceOS.AutoSize = true;
            this.MarkPriceOS.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MarkPriceOS.Location = new System.Drawing.Point(400, 132);
            this.MarkPriceOS.Name = "MarkPriceOS";
            this.MarkPriceOS.Size = new System.Drawing.Size(22, 26);
            this.MarkPriceOS.TabIndex = 25;
            this.MarkPriceOS.Text = "0";
            // 
            // TradePriceOS
            // 
            this.TradePriceOS.AutoSize = true;
            this.TradePriceOS.Font = new System.Drawing.Font("Palatino Linotype", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TradePriceOS.Location = new System.Drawing.Point(270, 132);
            this.TradePriceOS.Name = "TradePriceOS";
            this.TradePriceOS.Size = new System.Drawing.Size(22, 26);
            this.TradePriceOS.TabIndex = 24;
            this.TradePriceOS.Text = "0";
            // 
            // PortfolioManager
            // 
            this.AccessibleName = "";
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1144, 647);
            this.Controls.Add(this.SpecificPanel);
            this.Controls.Add(this.InstruPanel);
            this.Controls.Add(this.PandLPannel);
            this.Controls.Add(this.Menu);
            this.Font = new System.Drawing.Font("Palatino Linotype", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "PortfolioManager";
            this.Text = "Portfolio Manager#";
            this.Load += new System.EventHandler(this.PortfolioManager_Load);
            this.Menu.ResumeLayout(false);
            this.Menu.PerformLayout();
            this.PandLPannel.ResumeLayout(false);
            this.PandLPannel.PerformLayout();
            this.InstruPanel.ResumeLayout(false);
            this.SpecificPanel.ResumeLayout(false);
            this.SpecificPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fRamseyDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tradesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip Menu;
        private System.Windows.Forms.ToolStripMenuItem InstruMenu;
        private System.Windows.Forms.ToolStripMenuItem HistPricesMenu;
        private System.Windows.Forms.ToolStripMenuItem TradesMenu;
        private System.Windows.Forms.Panel PandLPannel;
        private System.Windows.Forms.Panel InstruPanel;
        private System.Windows.Forms.Panel SpecificPanel;
        private System.Windows.Forms.DataGridView dataGridView1;
        private FRamseyDataSet fRamseyDataSet;
        private System.Windows.Forms.BindingSource tradesBindingSource;
        private FRamseyDataSetTableAdapters.TradesTableAdapter tradesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn equityIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn asianOptionIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn barrierOptionIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn digitalOptionIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn europeanOptionIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rangeOptionIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lookbackOptionIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label GammaL;
        private System.Windows.Forms.Label RhoL;
        private System.Windows.Forms.Label ThetaL;
        private System.Windows.Forms.Label VegaL;
        private System.Windows.Forms.Label RateL;
        private System.Windows.Forms.Label deltaL;
        private System.Windows.Forms.Label TrialsL;
        private System.Windows.Forms.Label StepsL;
        private System.Windows.Forms.CheckBox AntitheticBox;
        private System.Windows.Forms.CheckBox CVBox;
        private System.Windows.Forms.CheckBox FaureBox;
        private System.Windows.Forms.TextBox TrialsBox;
        private System.Windows.Forms.TextBox StepsBox;
        private System.Windows.Forms.TextBox RateBox;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button RNGButton;
        private System.Windows.Forms.ErrorProvider ErrorProvider;
        private System.Windows.Forms.Label TradePriceL;
        private System.Windows.Forms.Label MarkPriceL;
        private System.Windows.Forms.Label PandLL;
        private System.Windows.Forms.Label PortfolioL;
        private System.Windows.Forms.Label TradeIDL;
        private System.Windows.Forms.TextBox SpecificIDL;
        private System.Windows.Forms.Label TradePriceOA;
        private System.Windows.Forms.Label MarkPriceOA;
        private System.Windows.Forms.Label PandLOA;
        private System.Windows.Forms.Label DeltaOA;
        private System.Windows.Forms.Label GammaOA;
        private System.Windows.Forms.Label RhoOA;
        private System.Windows.Forms.Label ThetaOA;
        private System.Windows.Forms.Label VegaOA;
        private System.Windows.Forms.Label VegaOS;
        private System.Windows.Forms.Label ThetaOS;
        private System.Windows.Forms.Label RhoOS;
        private System.Windows.Forms.Label GammaOS;
        private System.Windows.Forms.Label DeltaOS;
        private System.Windows.Forms.Label PandLOS;
        private System.Windows.Forms.Label MarkPriceOS;
        private System.Windows.Forms.Label TradePriceOS;
    }
}

