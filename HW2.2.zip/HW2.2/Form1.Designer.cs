﻿namespace HW2._2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Underlying = new System.Windows.Forms.TextBox();
            this.StrikePrice = new System.Windows.Forms.TextBox();
            this.Volatility = new System.Windows.Forms.TextBox();
            this.Tenor = new System.Windows.Forms.TextBox();
            this.Row = new System.Windows.Forms.TextBox();
            this.Col = new System.Windows.Forms.TextBox();
            this.UnverlyingL = new System.Windows.Forms.Label();
            this.StrikePriceL = new System.Windows.Forms.Label();
            this.VolatilityL = new System.Windows.Forms.Label();
            this.TenorL = new System.Windows.Forms.Label();
            this.RowL = new System.Windows.Forms.Label();
            this.ColL = new System.Windows.Forms.Label();
            this.IsCall = new System.Windows.Forms.CheckBox();
            this.Antithetic = new System.Windows.Forms.CheckBox();
            this.PriceL = new System.Windows.Forms.Label();
            this.DeltaL = new System.Windows.Forms.Label();
            this.RhoL = new System.Windows.Forms.Label();
            this.ThetaL = new System.Windows.Forms.Label();
            this.GammaL = new System.Windows.Forms.Label();
            this.StdErrorL = new System.Windows.Forms.Label();
            this.Price = new System.Windows.Forms.TextBox();
            this.Delta = new System.Windows.Forms.TextBox();
            this.Gamma = new System.Windows.Forms.TextBox();
            this.Theta = new System.Windows.Forms.TextBox();
            this.Rho = new System.Windows.Forms.TextBox();
            this.StdError = new System.Windows.Forms.TextBox();
            this.Calculate = new System.Windows.Forms.Button();
            this.Rate = new System.Windows.Forms.TextBox();
            this.RateL = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // Underlying
            // 
            this.Underlying.Location = new System.Drawing.Point(211, 51);
            this.Underlying.Name = "Underlying";
            this.Underlying.Size = new System.Drawing.Size(238, 35);
            this.Underlying.TabIndex = 0;
            this.Underlying.TextChanged += new System.EventHandler(this.Underlying_TextChanged);
            // 
            // StrikePrice
            // 
            this.StrikePrice.Location = new System.Drawing.Point(211, 141);
            this.StrikePrice.Name = "StrikePrice";
            this.StrikePrice.Size = new System.Drawing.Size(238, 35);
            this.StrikePrice.TabIndex = 1;
            this.StrikePrice.TextChanged += new System.EventHandler(this.StrikePrice_TextChanged);
            // 
            // Volatility
            // 
            this.Volatility.Location = new System.Drawing.Point(211, 231);
            this.Volatility.Name = "Volatility";
            this.Volatility.Size = new System.Drawing.Size(238, 35);
            this.Volatility.TabIndex = 2;
            this.Volatility.TextChanged += new System.EventHandler(this.Volatility_TextChanged);
            // 
            // Tenor
            // 
            this.Tenor.Location = new System.Drawing.Point(211, 321);
            this.Tenor.Name = "Tenor";
            this.Tenor.Size = new System.Drawing.Size(238, 35);
            this.Tenor.TabIndex = 3;
            this.Tenor.TextChanged += new System.EventHandler(this.Tenor_TextChanged);
            // 
            // Row
            // 
            this.Row.Location = new System.Drawing.Point(211, 411);
            this.Row.Name = "Row";
            this.Row.Size = new System.Drawing.Size(238, 35);
            this.Row.TabIndex = 4;
            this.Row.TextChanged += new System.EventHandler(this.Row_TextChanged);
            // 
            // Col
            // 
            this.Col.Location = new System.Drawing.Point(211, 501);
            this.Col.Name = "Col";
            this.Col.Size = new System.Drawing.Size(238, 35);
            this.Col.TabIndex = 5;
            this.Col.TextChanged += new System.EventHandler(this.Col_TextChanged);
            // 
            // UnverlyingL
            // 
            this.UnverlyingL.AutoSize = true;
            this.UnverlyingL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UnverlyingL.Location = new System.Drawing.Point(40, 50);
            this.UnverlyingL.Name = "UnverlyingL";
            this.UnverlyingL.Size = new System.Drawing.Size(133, 32);
            this.UnverlyingL.TabIndex = 6;
            this.UnverlyingL.Text = "Underlying";
            // 
            // StrikePriceL
            // 
            this.StrikePriceL.AutoSize = true;
            this.StrikePriceL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StrikePriceL.Location = new System.Drawing.Point(40, 140);
            this.StrikePriceL.Name = "StrikePriceL";
            this.StrikePriceL.Size = new System.Drawing.Size(134, 32);
            this.StrikePriceL.TabIndex = 7;
            this.StrikePriceL.Text = "Strike Price";
            // 
            // VolatilityL
            // 
            this.VolatilityL.AutoSize = true;
            this.VolatilityL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VolatilityL.Location = new System.Drawing.Point(40, 230);
            this.VolatilityL.Name = "VolatilityL";
            this.VolatilityL.Size = new System.Drawing.Size(109, 32);
            this.VolatilityL.TabIndex = 8;
            this.VolatilityL.Text = "Volatility";
            // 
            // TenorL
            // 
            this.TenorL.AutoSize = true;
            this.TenorL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TenorL.Location = new System.Drawing.Point(40, 320);
            this.TenorL.Name = "TenorL";
            this.TenorL.Size = new System.Drawing.Size(75, 32);
            this.TenorL.TabIndex = 9;
            this.TenorL.Text = "Tenor";
            // 
            // RowL
            // 
            this.RowL.AutoSize = true;
            this.RowL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RowL.Location = new System.Drawing.Point(40, 410);
            this.RowL.Name = "RowL";
            this.RowL.Size = new System.Drawing.Size(72, 32);
            this.RowL.TabIndex = 10;
            this.RowL.Text = "Trials";
            // 
            // ColL
            // 
            this.ColL.AutoSize = true;
            this.ColL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ColL.Location = new System.Drawing.Point(40, 500);
            this.ColL.Name = "ColL";
            this.ColL.Size = new System.Drawing.Size(72, 32);
            this.ColL.TabIndex = 11;
            this.ColL.Text = "Steps";
            // 
            // IsCall
            // 
            this.IsCall.AutoSize = true;
            this.IsCall.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IsCall.Location = new System.Drawing.Point(46, 656);
            this.IsCall.Name = "IsCall";
            this.IsCall.Size = new System.Drawing.Size(88, 36);
            this.IsCall.TabIndex = 12;
            this.IsCall.Text = "Call";
            this.IsCall.UseVisualStyleBackColor = true;
            this.IsCall.CheckedChanged += new System.EventHandler(this.IsCall_CheckedChanged);
            // 
            // Antithetic
            // 
            this.Antithetic.AutoSize = true;
            this.Antithetic.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Antithetic.Location = new System.Drawing.Point(296, 656);
            this.Antithetic.Name = "Antithetic";
            this.Antithetic.Size = new System.Drawing.Size(153, 36);
            this.Antithetic.TabIndex = 13;
            this.Antithetic.Text = "Antithetic";
            this.Antithetic.UseVisualStyleBackColor = true;
            this.Antithetic.CheckedChanged += new System.EventHandler(this.Antithetic_CheckedChanged);
            // 
            // PriceL
            // 
            this.PriceL.AutoSize = true;
            this.PriceL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceL.Location = new System.Drawing.Point(610, 50);
            this.PriceL.Name = "PriceL";
            this.PriceL.Size = new System.Drawing.Size(68, 32);
            this.PriceL.TabIndex = 14;
            this.PriceL.Text = "Price";
            // 
            // DeltaL
            // 
            this.DeltaL.AutoSize = true;
            this.DeltaL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeltaL.Location = new System.Drawing.Point(610, 150);
            this.DeltaL.Name = "DeltaL";
            this.DeltaL.Size = new System.Drawing.Size(72, 32);
            this.DeltaL.TabIndex = 15;
            this.DeltaL.Text = "Delta";
            // 
            // RhoL
            // 
            this.RhoL.AutoSize = true;
            this.RhoL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RhoL.Location = new System.Drawing.Point(610, 450);
            this.RhoL.Name = "RhoL";
            this.RhoL.Size = new System.Drawing.Size(58, 32);
            this.RhoL.TabIndex = 16;
            this.RhoL.Text = "Rho";
            // 
            // ThetaL
            // 
            this.ThetaL.AutoSize = true;
            this.ThetaL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThetaL.Location = new System.Drawing.Point(610, 350);
            this.ThetaL.Name = "ThetaL";
            this.ThetaL.Size = new System.Drawing.Size(75, 32);
            this.ThetaL.TabIndex = 17;
            this.ThetaL.Text = "Theta";
            // 
            // GammaL
            // 
            this.GammaL.AutoSize = true;
            this.GammaL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GammaL.Location = new System.Drawing.Point(610, 250);
            this.GammaL.Name = "GammaL";
            this.GammaL.Size = new System.Drawing.Size(98, 32);
            this.GammaL.TabIndex = 18;
            this.GammaL.Text = "Gamma";
            // 
            // StdErrorL
            // 
            this.StdErrorL.AutoSize = true;
            this.StdErrorL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StdErrorL.Location = new System.Drawing.Point(610, 550);
            this.StdErrorL.Name = "StdErrorL";
            this.StdErrorL.Size = new System.Drawing.Size(172, 32);
            this.StdErrorL.TabIndex = 19;
            this.StdErrorL.Text = "Standard Error";
            // 
            // Price
            // 
            this.Price.Location = new System.Drawing.Point(799, 51);
            this.Price.Name = "Price";
            this.Price.Size = new System.Drawing.Size(354, 35);
            this.Price.TabIndex = 20;
            // 
            // Delta
            // 
            this.Delta.Location = new System.Drawing.Point(799, 151);
            this.Delta.Name = "Delta";
            this.Delta.Size = new System.Drawing.Size(354, 35);
            this.Delta.TabIndex = 21;
            // 
            // Gamma
            // 
            this.Gamma.Location = new System.Drawing.Point(799, 251);
            this.Gamma.Name = "Gamma";
            this.Gamma.Size = new System.Drawing.Size(354, 35);
            this.Gamma.TabIndex = 22;
            // 
            // Theta
            // 
            this.Theta.Location = new System.Drawing.Point(799, 350);
            this.Theta.Name = "Theta";
            this.Theta.Size = new System.Drawing.Size(354, 35);
            this.Theta.TabIndex = 23;
            // 
            // Rho
            // 
            this.Rho.Location = new System.Drawing.Point(799, 450);
            this.Rho.Name = "Rho";
            this.Rho.Size = new System.Drawing.Size(354, 35);
            this.Rho.TabIndex = 24;
            // 
            // StdError
            // 
            this.StdError.Location = new System.Drawing.Point(799, 550);
            this.StdError.Name = "StdError";
            this.StdError.Size = new System.Drawing.Size(354, 35);
            this.StdError.TabIndex = 25;
            // 
            // Calculate
            // 
            this.Calculate.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calculate.Location = new System.Drawing.Point(799, 648);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(354, 50);
            this.Calculate.TabIndex = 26;
            this.Calculate.Text = "Calculate";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // Rate
            // 
            this.Rate.Location = new System.Drawing.Point(211, 590);
            this.Rate.Name = "Rate";
            this.Rate.Size = new System.Drawing.Size(238, 35);
            this.Rate.TabIndex = 27;
            this.Rate.TextChanged += new System.EventHandler(this.Rate_TextChanged);
            // 
            // RateL
            // 
            this.RateL.AutoSize = true;
            this.RateL.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RateL.Location = new System.Drawing.Point(40, 589);
            this.RateL.Name = "RateL";
            this.RateL.Size = new System.Drawing.Size(165, 32);
            this.RateL.TabIndex = 28;
            this.RateL.Text = "Risk Free Rate";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1260, 738);
            this.Controls.Add(this.RateL);
            this.Controls.Add(this.Rate);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.StdError);
            this.Controls.Add(this.Rho);
            this.Controls.Add(this.Theta);
            this.Controls.Add(this.Gamma);
            this.Controls.Add(this.Delta);
            this.Controls.Add(this.Price);
            this.Controls.Add(this.StdErrorL);
            this.Controls.Add(this.GammaL);
            this.Controls.Add(this.ThetaL);
            this.Controls.Add(this.RhoL);
            this.Controls.Add(this.DeltaL);
            this.Controls.Add(this.PriceL);
            this.Controls.Add(this.Antithetic);
            this.Controls.Add(this.IsCall);
            this.Controls.Add(this.ColL);
            this.Controls.Add(this.RowL);
            this.Controls.Add(this.TenorL);
            this.Controls.Add(this.VolatilityL);
            this.Controls.Add(this.StrikePriceL);
            this.Controls.Add(this.UnverlyingL);
            this.Controls.Add(this.Col);
            this.Controls.Add(this.Row);
            this.Controls.Add(this.Tenor);
            this.Controls.Add(this.Volatility);
            this.Controls.Add(this.StrikePrice);
            this.Controls.Add(this.Underlying);
            this.Name = "Form1";
            this.Text = "MS Calculator";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Underlying;
        private System.Windows.Forms.TextBox StrikePrice;
        private System.Windows.Forms.TextBox Volatility;
        private System.Windows.Forms.TextBox Tenor;
        private System.Windows.Forms.TextBox Row;
        private System.Windows.Forms.TextBox Col;
        private System.Windows.Forms.Label UnverlyingL;
        private System.Windows.Forms.Label StrikePriceL;
        private System.Windows.Forms.Label VolatilityL;
        private System.Windows.Forms.Label TenorL;
        private System.Windows.Forms.Label RowL;
        private System.Windows.Forms.Label ColL;
        private System.Windows.Forms.CheckBox IsCall;
        private System.Windows.Forms.CheckBox Antithetic;
        private System.Windows.Forms.Label PriceL;
        private System.Windows.Forms.Label DeltaL;
        private System.Windows.Forms.Label RhoL;
        private System.Windows.Forms.Label ThetaL;
        private System.Windows.Forms.Label GammaL;
        private System.Windows.Forms.Label StdErrorL;
        private System.Windows.Forms.TextBox Price;
        private System.Windows.Forms.TextBox Delta;
        private System.Windows.Forms.TextBox Gamma;
        private System.Windows.Forms.TextBox Theta;
        private System.Windows.Forms.TextBox Rho;
        private System.Windows.Forms.TextBox StdError;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.TextBox Rate;
        private System.Windows.Forms.Label RateL;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}

