﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW2._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public double S;
        public double K;
        public static double riskFreeRate;
        public double vol;
        public double T;
        public int rows;
        public int cols;
        public Boolean isCall;
        public Boolean anti;
        private void Form1_Load(object sender, EventArgs e)
        {
            errorProvider1.SetIconAlignment(Underlying, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(Underlying, 3);
            errorProvider1.SetIconAlignment(StrikePrice, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(StrikePrice, 3);
            errorProvider1.SetIconAlignment(Volatility, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(Volatility, 3);
            errorProvider1.SetIconAlignment(Tenor, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(Tenor, 3);
            errorProvider1.SetIconAlignment(Row, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(Row, 3);
            errorProvider1.SetIconAlignment(Col, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(Col, 3);

        }
        private void Underlying_TextChanged(object sender, EventArgs e)
        {
            double num;
            if (!double.TryParse(Underlying.Text, out num))
                errorProvider1.SetError(Underlying, "Please enter a number!");
            else
                errorProvider1.SetError(Underlying, string.Empty);
        }

        private void StrikePrice_TextChanged(object sender, EventArgs e)
        {
            double num;
            if (!double.TryParse(StrikePrice.Text, out num))
                errorProvider1.SetError(StrikePrice, "Please enter a number!");
            else
                errorProvider1.SetError(StrikePrice, string.Empty);
        }
        private void Volatility_TextChanged(object sender, EventArgs e)
        {
            double num;
            if (!double.TryParse(Volatility.Text, out num))
                errorProvider1.SetError(Volatility, "Please enter a number!");
            else
                errorProvider1.SetError(Volatility, string.Empty);
        }
        private void Tenor_TextChanged(object sender, EventArgs e)
        {
            double num;
            if (!double.TryParse(Tenor.Text, out num))
                errorProvider1.SetError(Tenor, "Please enter a number!");
            else
                errorProvider1.SetError(Tenor, string.Empty);
        }
        private void Row_TextChanged(object sender, EventArgs e)
        {
            int num;
            if (!int.TryParse(Row.Text, out num))
                errorProvider1.SetError(Row, "Please enter a natural number!");
            else
                errorProvider1.SetError(Row, string.Empty);
        }

        private void Col_TextChanged(object sender, EventArgs e)
        {
            int num;
            if (!int.TryParse(Col.Text, out num))
                errorProvider1.SetError(Col, "Please enter a natural number!");
            else
                errorProvider1.SetError(Col, string.Empty);
        }

        private void IsCall_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void Antithetic_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void Rate_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void Calculate_Click(object sender, EventArgs e)
        {
            S = Convert.ToDouble(Underlying.Text);
            K = Convert.ToDouble(StrikePrice.Text);
            vol = Convert.ToDouble(Volatility.Text);
            T = Convert.ToDouble(Tenor.Text);
            rows = Convert.ToInt16(Row.Text);
            cols = Convert.ToInt16(Col.Text);
            isCall = IsCall.Checked;
            anti = Antithetic.Checked;
            riskFreeRate = Convert.ToDouble(Rate.Text);
            Equity Q = new Equity(S, vol);
            EuropeanOption R = new EuropeanOption(Q, K, T, isCall, rows, cols, anti);
            Price.Text = R.Price.ToString();
            Delta.Text = R.Delta.ToString();
            Gamma.Text = R.Gamma.ToString();
            Theta.Text = R.Theta.ToString();
            Rho.Text = R.Rho.ToString();
            StdError.Text = R.StdError.ToString();
        }
    }
    class Instrument
    {
        protected double price;
        protected double volatility;
        protected string name;
        protected string marketTraded;
        protected string jurisdiction;
        protected string currency;
        protected DateTime issuance;
        protected DateTime expiration;
        protected Instrument underlying;
        public double Price { get { return price; } set { price = value; } }
        public double Volatility { get { return volatility; } set { volatility = value; } }
        public string Name { get { return name; } set { name = value; } }
        public string MarketTraded { get { return marketTraded; } set { marketTraded = value; } }
        public string Jurisdiction { get { return jurisdiction; } set { jurisdiction = value; } }
        public string Currency { get { return currency; } set { currency = value; } }
        public DateTime Issuance { get { return issuance; } set { issuance = value; } }
        public DateTime Expiration { get { return expiration; } set { expiration = value; } }
        public Instrument Underlying { get { return underlying; } set { underlying = value; } }
    }
    class Equity : Instrument
    {
        public Equity(double p, double vol)
        {
            price = p;
            volatility = vol;
        }
    }
    class Option : Instrument
    {
        protected Boolean isCall;
        protected double tenor;
        protected double strike;
        protected double underlyingPrice;
        protected double underlyingVolatility;
        protected int simTrials;
        protected int simSteps;
        protected double delta;
        protected double gamma;
        protected double vega;
        protected double theta;
        protected double rho;
        protected double se;
        protected Boolean antithetic;
        public Boolean IsCall { get { return isCall; } set { isCall = value; } }
        public double Tenor { get { return tenor; } set { tenor = value; } }
        public double Strike { get { return strike; } set { strike = value; } }
        public int SimTrials { get { return simTrials; } set { simTrials = value; } }
        public int SimSteps { get { return simSteps; } set { simSteps = value; } }
        public double Delta { get { return delta; } set { delta = value; } }
        public double Gamma { get { return gamma; } set { gamma = value; } }
        public double Vega { get { return vega; } set { vega = value; } }
        public double Theta { get { return theta; } set { theta = value; } }
        public double Rho { get { return rho; } set { rho = value; } }
        public double StdError { get { return se; } set { se = value; } }
        public Boolean Antithetic { get { return antithetic; } set { antithetic = value; } }
        public Option(Instrument U, double K, double T, Boolean tf, int steps, int trials, Boolean anti)
        {
            Underlying = U;
            underlyingPrice = U.Price;
            underlyingVolatility = U.Volatility;
            strike = K;
            tenor = T;
            simSteps = steps;
            simTrials = trials;
            isCall = tf;
        }
    }
    class EuropeanOption : Option
    {
        double dx = 0.0001;
        double[,] Datalla;
        public EuropeanOption(Instrument U, double k, double t, Boolean isC, int steps, int trials, Boolean anti) : base(U, k, t, isC, steps, trials, anti)
        {
            Datalla = NormDist.DefaultMatrixBoxMuller(simTrials, simSteps, anti);
            price = estPrice(Form1.riskFreeRate, underlyingVolatility, underlyingPrice, tenor);
            delta = (estPrice(Form1.riskFreeRate, underlyingVolatility, (1 + dx) * underlyingPrice, tenor) - estPrice(Form1.riskFreeRate, underlyingVolatility, underlyingPrice, tenor)) / dx;
            gamma = (estPrice(Form1.riskFreeRate, underlyingVolatility, (1 + dx) * underlyingPrice, tenor) + estPrice(Form1.riskFreeRate, underlyingVolatility, (1 - dx) * underlyingPrice, tenor) - 2 * estPrice(Form1.riskFreeRate, underlyingVolatility, underlyingPrice, tenor)) / (dx * dx);
            vega = (estPrice(Form1.riskFreeRate, (1 + dx) * underlyingVolatility, underlyingPrice, tenor) - estPrice(Form1.riskFreeRate, underlyingVolatility, underlyingPrice, tenor)) / dx;
            theta = (estPrice(Form1.riskFreeRate, underlyingVolatility, underlyingPrice, (1 + dx) * tenor) - estPrice(Form1.riskFreeRate, underlyingVolatility, underlyingPrice, tenor)) / dx;
            rho = (estPrice((1 + dx) * Form1.riskFreeRate, underlyingVolatility, underlyingPrice, tenor) - estPrice(Form1.riskFreeRate, underlyingVolatility, underlyingPrice, tenor)) / dx;
            se = NormDist.SD(Brownian.ItoZ(Form1.riskFreeRate, underlyingVolatility, underlyingPrice, tenor, simTrials, simSteps, Datalla)) / Math.Sqrt(simTrials);
        }
        private double estPrice(double drift, double vol, double S, double T)
        {
            double[] sim = Brownian.ItoZ(drift, vol, S, T, simTrials, simSteps, Datalla);
            double output = 0;
            if (isCall)
                for (int i = 0; i < simTrials; i++)
                {
                    output = output + Math.Max(sim[i] - strike, 0);
                }
            else
                for (int i = 0; i < simTrials; i++)
                {
                    output = output + Math.Max(strike - sim[i], 0);
                }
            output = output / simTrials * Math.Exp(-Form1.riskFreeRate * tenor);
            return output;
        }
    }
    class NormDist
    {
        static public double DefaultBoxMuller()
        {
            Random rnd = new Random();
            double x1 = rnd.NextDouble();
            double x2 = rnd.NextDouble();
            double z1 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Cos(2 * Math.PI * x2));
            double z2 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Sin(2 * Math.PI * x2));
            return z1;
        }
        static public double BoxMuller(double mean, double vol)
        {
            Random rnd = new Random();
            double x1 = rnd.NextDouble();
            double x2 = rnd.NextDouble();
            double z1 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Cos(2 * Math.PI * x2)) * Math.Sqrt(vol) + mean;
            double z2 = (Math.Sqrt(-2 * Math.Log(x1)) * Math.Sin(2 * Math.PI * x2)) * Math.Sqrt(vol) + mean;
            return z1;
        }
        static public double[,] DefaultMatrixBoxMuller(int rows, int cols, Boolean anti)
        {
            double[,] output = new double[rows, cols];
            if (anti)
            {
                for (int a = 0; a < rows / 2; a++)
                {
                    for (int b = 0; b < cols; b++)
                    {
                        output[a, b] = DefaultBoxMuller();
                        output[a + rows / 2, b] = -DefaultBoxMuller();
                    }
                }
            }
            else
            {
                for (int a = 0; a < rows; a++)
                {
                    for (int b = 0; b < cols; b++)
                    {
                        output[a, b] = DefaultBoxMuller();
                    }
                }
            }
            return output;
        }
        static public double[,] MatrixBoxMuller(double mean, double vol, int rows, int cols)
        {
            double[,] output = new double[rows, cols];
            for (int a = 0; a < rows; a++)
            {
                for (int b = 0; b < cols; b++)
                {
                    output[a, b] = BoxMuller(mean, vol);
                }
            }
            return output;
        }
        static public double SD(double[] input)
        {
            double z1 = 0;
            double z2 = 0;
            int m = 0;
            foreach (double x in input)
            {
                z1 = z1 + x;
                z2 = z2 + Math.Pow(x, 2);
                m = m + 1;
            }
            double output = z2 / m - Math.Pow(z1 / m, 2);
            return output;
        }
    }
    class Brownian
    {
        static public double Ito(double Drift, double Vol, double Pre, double DeltaT, double RndN)
        {
            double Seq = Pre * Math.Exp((Drift - Math.Pow(Vol, 2) / 2) * DeltaT + Vol * Math.Sqrt(DeltaT) * RndN);
            return Seq;
        }
        static public double[] ItoZ(double Drift, double Vol, double S0, double Tenor, int Trials, int Steps, double[,] RndN)
        {
            double[] output = new double[Trials];
            double DeltaT = Tenor / Steps;
            for (int a = 0; a < Trials; a++)
            {
                output[a] = S0;
                for (int b = 0; b < Steps; b++)
                {
                    output[a] = Ito(Drift, Vol, output[a], DeltaT, RndN[a, b]);
                }
            }
            return output;
        }
    }
}